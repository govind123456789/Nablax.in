"use client"

import Link from "next/link"
import { Card } from "@/components/ui/card"

export default function ServicesPage() {
  return (
    <div className="min-h-screen bg-black text-white antialiased">

      {/* Header */}
      <header className="fixed top-0 left-0 right-0 z-40 border-b border-white/6 bg-black/80 backdrop-blur">
        <nav className="container mx-auto px-6 py-4 flex justify-between items-center">
          <Link href="/" className="text-2xl font-light text-[#60a5fa]">
            ∇<sup className="text-sm">x</sup>
          </Link>

          <div className="hidden md:flex gap-8 text-sm">
            <Link href="/about" className="hover:text-[#60a5fa] transition">About</Link>
            <Link href="/services" className="text-[#60a5fa]">Services</Link>
            <Link href="/contact" className="hover:text-[#60a5fa] transition">Contact</Link>
          </div>
        </nav>
      </header>

      {/* Hero */}
      <section className="pt-32 pb-12">
        <div className="container mx-auto px-6 text-center">
          <h1 className="text-4xl md:text-5xl font-light leading-tight mb-4">
            How Organizations Engage with <span className="text-[#60a5fa]">Nabla-X</span>
          </h1>

          <p className="max-w-3xl mx-auto text-lg text-gray-300 leading-relaxed">
            Our work begins where complexity, risk, or scale exceed the limits of off-the-shelf tools.
            We engage selectively, delivering governed intelligence systems built for correctness,
            explainability, and long-term impact.
          </p>
        </div>
      </section>

      {/* Engagement spine + cards */}
      <section className="py-16">
        <div className="container mx-auto px-6 max-w-5xl relative">

          {/* Vertical spine: decorative SVG line + nodes */}
          <div className="hidden lg:block absolute -left-16 top-8 bottom-8 w-28">
            <svg width="56" height="100%" viewBox="0 0 56 1000" className="h-full">
              {/* long dotted line */}
              <line x1="28" y1="24" x2="28" y2="920" stroke="#1f2937" strokeWidth="2" strokeDasharray="6 10" />
              {/* node circles (positions align visually) */}
              <circle cx="28" cy="72" r="16" fill="#0b1220" stroke="#60a5fa" strokeWidth="1.6" />
              <text x="28" y="78" textAnchor="middle" fill="#60a5fa" fontSize="11" fontFamily="Inter, ui-sans-serif">1</text>

              <circle cx="28" cy="280" r="16" fill="#0b1220" stroke="#60a5fa" strokeWidth="1.6" />
              <text x="28" y="286" textAnchor="middle" fill="#60a5fa" fontSize="11" fontFamily="Inter, ui-sans-serif">2</text>

              <circle cx="28" cy="490" r="16" fill="#0b1220" stroke="#60a5fa" strokeWidth="1.6" />
              <text x="28" y="496" textAnchor="middle" fill="#60a5fa" fontSize="11" fontFamily="Inter, ui-sans-serif">3</text>

              <circle cx="28" cy="700" r="14" fill="#071021" stroke="#f59e0b" strokeWidth="1.4" />
              <text x="28" y="704" textAnchor="middle" fill="#f59e0b" fontSize="11" fontFamily="Inter, ui-sans-serif">•</text>
            </svg>
          </div>

          {/* Cards column */}
          <div className="space-y-12 lg:pl-24">
            {/* 1 */}
            <Card className="bg-[#071021] border-white/6 p-8 rounded-lg">
              <div className="flex items-start gap-6">
                <div className="hidden lg:block w-10 text-[#60a5fa] font-medium text-lg">01</div>
                <div>
                  <h3 className="text-xl text-[#60a5fa] font-medium mb-2">Intelligence Architecture & Diagnosis</h3>
                  <p className="text-gray-300 leading-relaxed">
                    We map how decisions are currently made — where data, semantics, incentives and risk intersect.
                    This phase delivers a concrete intelligence blueprint (semantics, lineage, decision flows)
                    before any code is written.
                  </p>
                </div>
              </div>
            </Card>

            {/* 2 */}
            <Card className="bg-[#071021] border-white/6 p-8 rounded-lg">
              <div className="flex items-start gap-6">
                <div className="hidden lg:block w-10 text-[#60a5fa] font-medium text-lg">02</div>
                <div>
                  <h3 className="text-xl text-[#60a5fa] font-medium mb-2">Platform & Product Deployment</h3>
                  <p className="text-gray-300 leading-relaxed">
                    We deploy and integrate Nabla-X products — QueryMind, DataSentinel, and RootSense — into your
                    data estate with guarded execution, observability, and semantic alignment. Integrations include
                    semantic layer tuning, access controls, and audit pipelines.
                  </p>
                </div>
              </div>
            </Card>

            {/* 3 */}
            <Card className="bg-[#071021] border-white/6 p-8 rounded-lg">
              <div className="flex items-start gap-6">
                <div className="hidden lg:block w-10 text-[#60a5fa] font-medium text-lg">03</div>
                <div>
                  <h3 className="text-xl text-[#60a5fa] font-medium mb-2">Decision System Hardening</h3>
                  <p className="text-gray-300 leading-relaxed">
                    For regulated or high-impact environments we codify guardrails: explainability, audit trails,
                    failure-mode analysis, and controlled learning. We ensure that analytical outputs are traceable,
                    testable and defensible.
                  </p>
                </div>
              </div>
            </Card>

            {/* 4 - selective */}
            <Card className="bg-[#06101a] border-white/8 p-8 rounded-lg ring-1 ring-white/3">
              <div className="flex items-start gap-6">
                <div className="hidden lg:block w-10 text-[#f59e0b] font-medium text-lg">•</div>
                <div>
                  <div className="inline-flex items-center gap-3 mb-2">
                    <h3 className="text-xl text-[#f59e0b] font-medium">Strategic Partnership</h3>
                    <span className="text-xs text-[#f59e0b] bg-[#1a1409] px-2 py-1 rounded">Selective</span>
                  </div>
                  <p className="text-gray-350 text-gray-300 leading-relaxed">
                    We partner with a small number of leadership teams on long-term intelligence strategy,
                    platform evolution, and organizational readiness. This engagement is selective and advisory-first.
                  </p>
                </div>
              </div>
            </Card>
          </div>
        </div>
      </section>

      {/* What we don't do (qualifier) */}
      <section className="py-12 border-t border-white/6">
        <div className="container mx-auto px-6 max-w-3xl text-center text-gray-300">
          <h4 className="text-lg font-medium mb-3">What we do not do</h4>
          <p className="text-sm mb-4">
            We do not provide one-off dashboards, generic AI experiments without production intent, or black-box
            systems without explainability and governance.
          </p>

          <Link href="/contact" className="inline-block mt-3 border border-[#60a5fa] text-[#60a5fa] px-6 py-3 rounded hover:bg-[#60a5fa]/6 transition">
            Contact Nabla-X
          </Link>
        </div>
      </section>

      {/* Footer */}
      <footer className="py-12 border-t border-white/8">
        <div className="container mx-auto px-6 text-center text-gray-400">
          <p className="text-sm">© 2025 Nabla-X. Intelligence for complex systems.</p>
        </div>
      </footer>

      {/* Scoped styles */}
      <style jsx>{`
        /* small color normalization for gray copy */
        :root {
          --muted: #93a1b2;
        }

        .text-gray-350 { color: #cbd5e1; }

        @media (min-width: 1024px) {
          /* subtle spacing tweak so spine aligns nicely */
          .container { max-width: 1180px; }
        }
      `}</style>
    </div>
  )
}
