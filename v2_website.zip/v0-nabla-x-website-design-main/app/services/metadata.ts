import type { Metadata } from "next"

export const metadata: Metadata = {
  title: "AI Observability Services for Regulated Environments | Nabla-X",
  description:
    "Production-grade AI observability for fintechs and AI platforms. Prevent $2M+ in incidents annually with explainable, auditable decision systems. SOC 2 compliant.",
  keywords: [
    "AI observability",
    "production AI monitoring",
    "AI governance",
    "explainable AI",
    "AI auditability",
    "regulated AI environments",
    "SOC 2 AI compliance",
    "QueryMind",
    "DataSentinel",
    "RootSense",
    "AI decision systems",
    "enterprise AI services",
    "fintech AI solutions",
    "AI platform observability",
    "root cause analysis AI",
    "AI failure prevention",
  ],
  openGraph: {
    title: "AI Observability Services for Regulated Environments | Nabla-X",
    description:
      "Production-grade AI observability for fintechs & AI platforms. Prevent failures before they compound with explainable, auditable systems. $2.4M avg. incidents prevented annually.",
    url: "https://nabla-x.ai/services",
    siteName: "Nabla-X",
    type: "website",
    images: [
      {
        url: "/og-image-services.png",
        width: 1200,
        height: 630,
        alt: "Nabla-X AI Observability Services - Prevent Failures, Ensure Compliance",
      },
    ],
  },
  twitter: {
    card: "summary_large_image",
    title: "AI Observability for Regulated Environments | Nabla-X",
    description:
      "Production-grade observability for fintechs & AI platforms. $2.4M avg. incidents prevented annually. Explainable, auditable, SOC 2 compliant.",
    images: ["/og-image-services.png"],
  },
}
