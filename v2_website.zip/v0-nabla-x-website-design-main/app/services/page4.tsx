"use client"

import Link from "next/link"
import { Card } from "@/components/ui/card"

export default function ServicesPage() {
  return (
    <div className="min-h-screen bg-black text-white antialiased">

      {/* HEADER */}
      <header className="fixed top-0 left-0 right-0 z-50 border-b border-white/10 bg-black/80 backdrop-blur">
        <nav className="container mx-auto px-6 py-4 flex items-center justify-between">
          <Link href="/" className="text-2xl font-light text-[#60a5fa]">
            ∇<sup className="text-sm">x</sup>
          </Link>
          <div className="flex gap-8 text-sm">
            <Link href="/about" className="hover:text-[#60a5fa]">About</Link>
            <Link href="/services" className="text-[#60a5fa]">Services</Link>
            <Link href="/contact" className="hover:text-[#60a5fa]">Contact</Link>
          </div>
        </nav>
      </header>

      {/* HERO */}
      <section className="pt-32 pb-20 border-b border-white/10">
        <div className="container mx-auto px-6 grid lg:grid-cols-12 gap-12 items-center">
          <div className="lg:col-span-7">
            <h1 className="text-4xl md:text-5xl font-light leading-tight mb-6">
              Engagement models for{" "}
              <span className="text-[#60a5fa]">complex intelligence systems</span>
            </h1>

            <p className="text-gray-300 max-w-2xl mb-8 leading-relaxed">
              Nabla-X partners with organizations where decisions are constrained by
              risk, regulation, and scale. We design, deploy, and harden governed
              intelligence systems that prioritize correctness, explainability,
              and lasting operational impact.
            </p>

            <div className="flex items-center gap-4 mb-4">
              <Link
                href="/contact"
                className="bg-[#60a5fa] text-black px-6 py-3 rounded-md font-medium"
              >
                Discuss Your Environment
              </Link>
            </div>

            <div className="flex gap-4 text-xs text-gray-400">
              <Link href="/products/querymind" className="underline">QueryMind</Link>
              <Link href="/products/datasentinel" className="underline">DataSentinel</Link>
              <Link href="/products/rootsense" className="underline">RootSense</Link>
            </div>
          </div>

          {/* SCHEMATIC */}
          <div className="lg:col-span-5 flex justify-center">
            <svg width="360" height="240" viewBox="0 0 360 240">
              <rect x="6" y="6" width="348" height="228" rx="12" fill="#071021" stroke="#0b1220" />
              <rect x="28" y="28" width="84" height="56" rx="8" fill="#0f1622" stroke="#1f3b55" />
              <rect x="148" y="28" width="184" height="56" rx="8" fill="#0f1622" stroke="#1f3b55" />
              <rect x="28" y="110" width="120" height="72" rx="8" fill="#0f1622" stroke="#1f3b55" />
              <rect x="164" y="110" width="168" height="72" rx="8" fill="#08121a" stroke="#163241" />
              <path d="M112 56 L148 56" stroke="#274f6f" strokeWidth="2" />
              <path d="M76 84 L76 110" stroke="#274f6f" strokeWidth="2" />
              <path d="M148 56 L164 146" stroke="#274f6f" strokeWidth="2" strokeDasharray="4 6" />
            </svg>
          </div>
        </div>
      </section>

      {/* SERVICES */}
      <section className="py-20">
        <div className="container mx-auto px-6 max-w-6xl">
          <h2 className="text-3xl font-light mb-12 text-center">
            What we build
          </h2>

          <div className="grid md:grid-cols-3 gap-8">
            <Card className="bg-[#071021] border-white/10 p-6">
              <h3 className="text-[#60a5fa] text-lg mb-2">Intelligence Architecture</h3>
              <p className="text-gray-300 text-sm">
                Semantic modeling, lineage, decision-flow mapping, and system design
                for AI operating under real constraints.
              </p>
            </Card>

            <Card className="bg-[#071021] border-white/10 p-6">
              <h3 className="text-[#60a5fa] text-lg mb-2">Deployment & MLOps</h3>
              <p className="text-gray-300 text-sm">
                Controlled rollout, CI/CD, versioning, cost ceilings, and execution
                safety for production AI systems.
              </p>
            </Card>

            <Card className="bg-[#071021] border-white/10 p-6">
              <h3 className="text-[#60a5fa] text-lg mb-2">Governance & Control</h3>
              <p className="text-gray-300 text-sm">
                Audit trails, permissioned learning, explainability guarantees,
                and regulatory alignment.
              </p>
            </Card>
          </div>
        </div>
      </section>

      {/* PRODUCTS */}
      <section className="py-20 border-t border-white/10">
        <div className="container mx-auto px-6 max-w-6xl">
          <h2 className="text-3xl font-light mb-12 text-center">
            Product-led engagements
          </h2>

          <div className="grid md:grid-cols-3 gap-8">
            <Card className="bg-[#071021] border-white/10 p-6">
              <h3 className="text-lg text-[#60a5fa] mb-1">QueryMind</h3>
              <p className="text-sm text-gray-300 mb-3">
                Intent → semantics → safe execution → explanation.
              </p>
              <Link href="/products/querymind" className="text-xs underline text-[#60a5fa]">
                Explore →
              </Link>
            </Card>

            <Card className="bg-[#071021] border-white/10 p-6">
              <h3 className="text-lg text-[#60a5fa] mb-1">DataSentinel</h3>
              <p className="text-sm text-gray-300 mb-3">
                Real-time data reliability, anomaly detection, and trust scoring.
              </p>
              <Link href="/products/datasentinel" className="text-xs underline text-[#60a5fa]">
                Explore →
              </Link>
            </Card>

            <Card className="bg-[#071021] border-white/10 p-6">
              <h3 className="text-lg text-[#60a5fa] mb-1">RootSense</h3>
              <p className="text-sm text-gray-300 mb-3">
                Root-cause analysis and similarity intelligence for failures and churn.
              </p>
              <Link href="/products/rootsense" className="text-xs underline text-[#60a5fa]">
                Explore →
              </Link>
            </Card>
          </div>
        </div>
      </section>

      {/* CASE STUDIES */}
      <section className="py-20 border-t border-white/10">
        <div className="container mx-auto px-6 max-w-6xl">
          <h2 className="text-3xl font-light mb-12 text-center">
            Case studies & solutions
          </h2>

          <div className="grid md:grid-cols-3 gap-8">
            <Card className="bg-[#071021] border-white/10 p-6">
              <h4 className="text-lg mb-2">Revenue Drift Diagnosis – Healthcare</h4>
              <p className="text-sm text-gray-400 mb-3">
                Identified hidden revenue loss drivers across hospital networks.
              </p>
              <Link
                href="/case-studies/revenue-drift-healthcare"
                className="text-xs underline text-[#60a5fa]"
              >
                Read more →
              </Link>
            </Card>

            <Card className="bg-[#071021] border-white/10 p-6">
              <h4 className="text-lg mb-2">Anomaly Protection – Financial Services</h4>
              <p className="text-sm text-gray-400 mb-3">
                Prevented high-cost incidents with real-time data monitoring.
              </p>
              <Link
                href="/case-studies/anomaly-protection-finserv"
                className="text-xs underline text-[#60a5fa]"
              >
                Read more →
              </Link>
            </Card>

            <Card className="bg-[#071021] border-white/10 p-6">
              <h4 className="text-lg mb-2">Explainability Platform – Telco</h4>
              <p className="text-sm text-gray-400 mb-3">
                Delivered causal explanations for churn and network incidents.
              </p>
              <Link
                href="/case-studies/explainability-platform-telco"
                className="text-xs underline text-[#60a5fa]"
              >
                Read more →
              </Link>
            </Card>
          </div>
        </div>
      </section>

      {/* WHAT THIS IS NOT */}
      <section className="py-16 border-t border-white/10 text-center">
        <div className="container mx-auto px-6 max-w-3xl">
          <h3 className="text-xl mb-4">What this is not</h3>
          <p className="text-gray-400 mb-6">
            Not a chatbot on top of SQL. Not ungoverned auto-SQL.
            Not one-off dashboards. We build systems with operational guarantees.
          </p>
          <Link
            href="/contact"
            className="border border-[#60a5fa] text-[#60a5fa] px-6 py-3 rounded"
          >
            Start a Conversation
          </Link>
        </div>
      </section>

      {/* FOOTER */}
      <footer className="py-12 border-t border-white/10 text-center text-gray-500">
        © 2025 Nabla-X
      </footer>
    </div>
  )
}
