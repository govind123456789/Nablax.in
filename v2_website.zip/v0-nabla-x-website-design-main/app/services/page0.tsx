"use client"

import Link from "next/link"
import { Card } from "@/components/ui/card"

export default function ServicesPage() {
  return (
    <div className="min-h-screen bg-black text-white antialiased">

      {/* Header */}
      <header className="fixed top-0 left-0 right-0 z-50 border-b border-white/6 bg-black/85 backdrop-blur">
        <nav className="container mx-auto px-6 py-4 flex items-center justify-between">
          <Link href="/" className="text-2xl font-light text-[#60a5fa]">
            ∇<sup className="text-sm">x</sup>
          </Link>

          <div className="hidden md:flex gap-8 text-sm">
            <Link href="/about" className="hover:text-[#60a5fa] transition">About</Link>
            <Link href="/services" className="text-[#60a5fa]">Services</Link>
            <Link href="/contact" className="hover:text-[#60a5fa] transition">Contact</Link>
          </div>
        </nav>
      </header>

      {/* Hero */}
      <section className="pt-32 pb-14">
        <div className="container mx-auto px-6 grid grid-cols-1 lg:grid-cols-12 gap-12 items-center">
          <div className="lg:col-span-7 text-center lg:text-left">
            <h1 className="text-4xl md:text-5xl font-light leading-tight mb-4">
              Engagement models for <span className="text-[#60a5fa]">complex intelligence systems</span>
            </h1>

            <p className="max-w-3xl text-gray-300 mb-6">
              Nabla-X partners with organizations where decisions are constrained by risk, regulation, and scale.
              We design, deploy, and harden governed intelligence systems that prioritize correctness, explainability,
              and lasting operational impact.
            </p>

            <div className="flex items-center gap-3 justify-center lg:justify-start mb-4">
              <Link
                href="/contact"
                className="inline-block bg-[#60a5fa] text-black px-6 py-3 rounded-md font-medium hover:opacity-95 transition"
              >
                Discuss Your Environment
              </Link>

              <Link
                href="/products/querymind"
                className="inline-block border border-white/10 text-gray-300 px-5 py-3 rounded-md hover:bg-white/2 transition text-sm"
              >
                Explore QueryMind
              </Link>
            </div>

            {/* small product links so hero doesn't bias */}
            <div className="flex gap-3 text-xs text-gray-300 justify-center lg:justify-start">
              <Link href="/products/querymind" className="underline">QueryMind</Link>
              <span className="opacity-30">•</span>
              <Link href="/products/datasentinel" className="underline">DataSentinel</Link>
              <span className="opacity-30">•</span>
              <Link href="/products/rootsense" className="underline">RootSense</Link>
            </div>
          </div>

          <div className="lg:col-span-5 flex justify-center lg:justify-end">
            {/* schematic SVG visual */}
            <svg
              width="360"
              height="240"
              viewBox="0 0 360 240"
              fill="none"
              xmlns="http://www.w3.org/2000/svg"
              aria-hidden="true"
            >
              <rect x="6" y="6" width="348" height="228" rx="12" fill="#071021" stroke="#0b1220" />
              <rect x="28" y="28" width="84" height="56" rx="8" fill="#0f1622" stroke="#1f3b55" />
              <rect x="148" y="28" width="184" height="56" rx="8" fill="#0f1622" stroke="#1f3b55" />
              <rect x="28" y="110" width="120" height="72" rx="8" fill="#0f1622" stroke="#1f3b55" />
              <rect x="164" y="110" width="168" height="72" rx="8" fill="#08121a" stroke="#163241" />
              <path d="M112 56 L148 56" stroke="#274f6f" strokeWidth="2" />
              <path d="M76 84 L76 110" stroke="#274f6f" strokeWidth="2" />
              <path d="M148 56 L164 146" stroke="#274f6f" strokeWidth="2" strokeDasharray="4 6" />
              <circle cx="46" cy="46" r="4" fill="#60a5fa" />
              <circle cx="330" cy="46" r="4" fill="#d4af37" />
              <circle cx="330" cy="146" r="4" fill="#60a5fa" />
              <text x="40" y="104" fill="#9fb3c6" fontSize="10">Schema</text>
              <text x="180" y="20" fill="#9fb3c6" fontSize="10">Intent Graph</text>
              <text x="180" y="220" fill="#9fb3c6" fontSize="10">Observability</text>
            </svg>
          </div>
        </div>
      </section>

      {/* WHAT WE ENABLE */}
      <section className="py-12 border-t border-white/6">
        <div className="container mx-auto px-6 max-w-6xl">
          <div className="text-center mb-8">
            <div className="text-xs uppercase tracking-widest text-[#60a5fa] inline-block mb-3">What we enable</div>
            <h2 className="text-2xl font-light">Outcomes, not features</h2>
            <p className="text-gray-400 max-w-2xl mx-auto mt-3">
              We frame outcomes: the things organizations must achieve to rely on automated intelligence in production.
            </p>
          </div>

          <div className="grid md:grid-cols-3 gap-6 mt-8">
            <Card className="bg-[#071021] border-white/6 p-6">
              <h3 className="text-lg text-[#60a5fa] mb-2 font-medium">Explainable Decisions</h3>
              <p className="text-gray-300 text-sm leading-relaxed">
                Context-rich explanations: assumptions, exclusions and alternative interpretations generated from the execution context.
              </p>
            </Card>

            <Card className="bg-[#071021] border-white/6 p-6">
              <h3 className="text-lg text-[#60a5fa] mb-2 font-medium">Safe Execution at Scale</h3>
              <p className="text-gray-300 text-sm leading-relaxed">
                Execute analytics under constraints: timeouts, row limits and blast-radius estimation so systems remain safe and auditable.
              </p>
            </Card>

            <Card className="bg-[#071021] border-white/6 p-6">
              <h3 className="text-lg text-[#60a5fa] mb-2 font-medium">Operational Semantics</h3>
              <p className="text-gray-300 text-sm leading-relaxed">
                Map intent to authoritative schemas, lineage and a business glossary—prevent ambiguity and silent failures.
              </p>
            </Card>
          </div>
        </div>
      </section>

      {/* ENGAGEMENT MODELS */}
      <section className="py-16">
        <div className="container mx-auto px-6 max-w-6xl relative">

          {/* left spine for large screens */}
          <div className="hidden lg:block absolute left-6 top-6 bottom-6 w-20">
            <svg width="64" height="100%" viewBox="0 0 64 1000" className="h-full">
              <line x1="32" y1="40" x2="32" y2="920" stroke="#0f1720" strokeWidth="2" strokeDasharray="4 8" />
              <circle cx="32" cy="80" r="16" fill="#071021" stroke="#60a5fa" strokeWidth="1.6" />
              <text x="32" y="86" textAnchor="middle" fill="#60a5fa" fontSize="11">1</text>

              <circle cx="32" cy="300" r="16" fill="#071021" stroke="#60a5fa" strokeWidth="1.6" />
              <text x="32" y="306" textAnchor="middle" fill="#60a5fa" fontSize="11">2</text>

              <circle cx="32" cy="520" r="16" fill="#071021" stroke="#60a5fa" strokeWidth="1.6" />
              <text x="32" y="526" textAnchor="middle" fill="#60a5fa" fontSize="11">3</text>

              <circle cx="32" cy="740" r="14" fill="#071021" stroke="#d4af37" strokeWidth="1.4" />
              <text x="32" y="744" textAnchor="middle" fill="#d4af37" fontSize="11">•</text>
            </svg>
          </div>

          <div className="lg:pl-28 space-y-10">
            <Card className="bg-[#071021] border-white/6 p-8 rounded-lg">
              <div className="flex gap-6 items-start">
                <div className="hidden lg:block w-12 text-[#60a5fa] font-medium text-lg">01</div>
                <div>
                  <h3 className="text-xl text-[#60a5fa] font-medium mb-2">Intelligence Architecture & Diagnosis</h3>
                  <p className="text-gray-300">
                    We map decision flows, data sources, and incentives to expose blind spots and risk. Deliverables:
                    semantic models, lineage maps, and a concrete intelligence blueprint before implementation.
                  </p>
                </div>
              </div>
            </Card>

            <Card className="bg-[#071021] border-white/6 p-8 rounded-lg">
              <div className="flex gap-6 items-start">
                <div className="hidden lg:block w-12 text-[#60a5fa] font-medium text-lg">02</div>
                <div>
                  <h3 className="text-xl text-[#60a5fa] font-medium mb-2">Platform & Product Deployment</h3>
                  <p className="text-gray-300 mb-3">
                    Deploy and integrate Nabla-X products into your estate with guarded execution, observability and governance.
                  </p>

                  <div className="grid md:grid-cols-3 gap-3 mt-2 text-sm text-gray-300">
                    <div>
                      <strong>QueryMind</strong>
                      <div className="text-xs text-gray-400 mt-1">Intent → safe SQL → explainable results</div>
                      <Link href="/products/querymind" className="text-xs text-[#60a5fa] underline mt-1 inline-block">Open →</Link>
                    </div>

                    <div>
                      <strong>DataSentinel</strong>
                      <div className="text-xs text-gray-400 mt-1">Real-time data reliability, anomaly detection, trust scoring</div>
                      <Link href="/products/datasentinel" className="text-xs text-[#60a5fa] underline mt-1 inline-block">Open →</Link>
                    </div>

                    <div>
                      <strong>RootSense</strong>
                      <div className="text-xs text-gray-400 mt-1">Root-cause explainability and similarity search</div>
                      <Link href="/products/rootsense" className="text-xs text-[#60a5fa] underline mt-1 inline-block">Open →</Link>
                    </div>
                  </div>
                </div>
              </div>
            </Card>

            <Card className="bg-[#071021] border-white/6 p-8 rounded-lg">
              <div className="flex gap-6 items-start">
                <div className="hidden lg:block w-12 text-[#60a5fa] font-medium text-lg">03</div>
                <div>
                  <h3 className="text-xl text-[#60a5fa] font-medium mb-2">Decision System Hardening</h3>
                  <p className="text-gray-300 mb-3">
                    For regulated and high-risk environments we codify guardrails: explainability, audit trails,
                    failure-mode analysis, and permissioned learning. Outputs are testable and defensible.
                  </p>
                  <div className="flex gap-3 mt-2 text-sm text-gray-300">
                    <div className="px-3 py-1 rounded bg-white/3">Explainability</div>
                    <div className="px-3 py-1 rounded bg-white/3">Audit readiness</div>
                    <div className="px-3 py-1 rounded bg-white/3">Failure-mode analysis</div>
                  </div>
                </div>
              </div>
            </Card>

            <Card className="bg-[#06121a] border-white/8 p-8 rounded-lg ring-1 ring-white/3">
              <div className="flex gap-6 items-start">
                <div className="hidden lg:block w-12 text-[#f59e0b] font-medium text-lg">•</div>
                <div>
                  <div className="flex items-center gap-3 mb-2">
                    <h3 className="text-xl text-[#f59e0b] font-medium">Strategic Partnership</h3>
                    <span className="text-xs text-[#f59e0b] bg-[#1a1409] px-2 py-1 rounded">Selective</span>
                  </div>
                  <p className="text-gray-300">
                    We partner with a small number of leadership teams on long-term intelligence strategy, platform
                    evolution and organizational readiness. Advisory-first and intentionally limited.
                  </p>
                  <div className="mt-3">
                    <Link
                      href="/contact"
                      className="inline-block text-sm border border-[#f59e0b] text-[#f59e0b] px-4 py-2 rounded hover:bg-[#f59e0b]/6 transition"
                    >
                      Enquire about Partnership
                    </Link>
                  </div>
                </div>
              </div>
            </Card>
          </div>
        </div>
      </section>

      {/* CASE STUDIES */}
      <section className="py-14 border-t border-white/6">
        <div className="container mx-auto px-6 max-w-6xl">
          <div className="text-center mb-8">
            <div className="text-xs uppercase tracking-widest text-[#60a5fa] inline-block mb-3">Representative engagements</div>
            <h2 className="text-2xl font-light">Case studies & solutions</h2>
            <p className="text-gray-400 max-w-2xl mx-auto mt-3">
              Selected engagements that demonstrate our approach to correctness, safety, and operationalization.
            </p>
          </div>

          <div className="grid md:grid-cols-3 gap-6 mt-8">
            <Card className="bg-[#071021] border-white/6 p-4">
              <div className="h-40 bg-gradient-to-b from-[#071a2e] to-[#05202a] rounded-md mb-4 flex items-center justify-center text-[#60a5fa]">
                {/* schematic */}
                <svg width="84" height="60" viewBox="0 0 84 60" xmlns="http://www.w3.org/2000/svg" aria-hidden>
                  <rect x="4" y="4" width="36" height="36" rx="6" fill="#092234" stroke="#184e6d"/>
                  <rect x="44" y="6" width="36" height="20" rx="4" fill="#092234" stroke="#184e6d"/>
                </svg>
              </div>
              <h4 className="text-lg text-white mb-1">Revenue Drift Diagnosis – Healthcare</h4>
              <p className="text-xs text-gray-400 mb-3">
                Diagnosed drivers of revenue volatility across hospital networks while guarding against incomplete sources.
              </p>
              <Link href="/case-studies/revenue-drift-healthcare" className="text-xs text-[#60a5fa] underline">Read more →</Link>
            </Card>

            <Card className="bg-[#071021] border-white/6 p-4">
              <div className="h-40 bg-gradient-to-b from-[#071a2e] to-[#05202a] rounded-md mb-4 flex items-center justify-center text-[#60a5fa]">
                <svg width="84" height="60" viewBox="0 0 84 60" xmlns="http://www.w3.org/2000/svg" aria-hidden>
                  <circle cx="26" cy="30" r="18" fill="#092234" stroke="#184e6d"/>
                  <rect x="46" y="18" width="30" height="24" rx="4" fill="#092234" stroke="#184e6d"/>
                </svg>
              </div>
              <h4 className="text-lg text-white mb-1">Anomaly Protection – Financial Services</h4>
              <p className="text-xs text-gray-400 mb-3">
                Real-time data sentinel for trade and settlement pipelines; prevented high-cost reconciliation incidents.
              </p>
              <Link href="/case-studies/anomaly-protection-finserv" className="text-xs text-[#60a5fa] underline">Read more →</Link>
            </Card>

            <Card className="bg-[#071021] border-white/6 p-4">
              <div className="h-40 bg-gradient-to-b from-[#071a2e] to-[#05202a] rounded-md mb-4 flex items-center justify-center text-[#60a5fa]">
                <svg width="84" height="60" viewBox="0 0 84 60" xmlns="http://www.w3.org/2000/svg" aria-hidden>
                  <rect x="6" y="10" width="72" height="36" rx="6" fill="#092234" stroke="#184e6d"/>
                </svg>
              </div>
              <h4 className="text-lg text-white mb-1">Explainability Platform – Telco</h4>
              <p className="text-xs text-gray-400 mb-3">
                Built a RootSense layer to surface causal signals and analogues for churn and incident triage.
              </p>
              <Link href="/case-studies/explainability-platform-telco" className="text-xs text-[#60a5fa] underline">Read more →</Link>
            </Card>
          </div>
        </div>
      </section>

      {/* WHAT THIS IS NOT */}
      <section className="py-12 border-t border-white/6">
        <div className="container mx-auto px-6 max-w-3xl text-center">
          <h4 className="text-lg font-medium mb-3">What this is not</h4>
          <p className="text-gray-400 mb-4">
            Not a chatbot on top of SQL. Not ungoverned auto-SQL. Not one-off dashboards. We build governed systems with
            operational guarantees and explainable outputs.
          </p>

          <Link href="/contact" className="inline-block mt-2 border border-[#60a5fa] text-[#60a5fa] px-6 py-3 rounded hover:bg-[#60a5fa]/6 transition">
            Start a Conversation
          </Link>
        </div>
      </section>

      {/* CTA band */}
      <section className="py-12 bg-gradient-to-r from-[#041223] to-[#081525] border-t border-white/6">
        <div className="container mx-auto px-6 max-w-5xl flex flex-col md:flex-row items-center justify-between gap-4">
          <div>
            <h5 className="text-lg font-medium">Discuss your environment</h5>
            <p className="text-gray-400 text-sm">If your systems carry decision risk, we should talk. We prioritize selective, durable engagements.</p>
          </div>

          <div>
            <Link href="/contact" className="inline-block bg-[#60a5fa] text-black px-6 py-3 rounded-md font-medium hover:opacity-95 transition">
              Contact Nabla-X
            </Link>
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="py-12 border-t border-white/8">
        <div className="container mx-auto px-6 text-center text-gray-400">
          <p className="text-sm">© 2025 Nabla-X. Intelligence for complex systems.</p>
        </div>
      </footer>

      <style jsx>{`
        .text-gray-350 { color: #cbd5e1; }
        @media (min-width: 1024px) {
          .container { max-width: 1180px; }
        }
      `}</style>
    </div>
  )
}
