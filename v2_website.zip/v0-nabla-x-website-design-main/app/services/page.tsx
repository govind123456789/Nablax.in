"use client"

import Link from "next/link"
import { motion } from "framer-motion"
import { Button } from "@/components/ui/button"
import { Card } from "@/components/ui/card"
import {
  Shield,
  Sparkles,
  CheckCircle2,
  XCircle,
  TrendingUp,
  Zap,
  Lock,
  FileText,
  Database,
  Key,
  AlertTriangle,
  ArrowRight,
  Code,
  Cpu,
} from "lucide-react"

export default function ServicesPage() {
  return (
    <div className="min-h-screen bg-gradient-to-br from-[#0a0a0a] via-[#1a1a1a] to-[#0f0f0f] text-[#e8e8e8]">
      {/* Header */}
      <header className="fixed top-0 w-full z-40 border-b border-[#d4af37]/20 bg-[#0a0a0a]/80 backdrop-blur-md">
        <nav className="container mx-auto px-6 py-4 flex items-center justify-between">
          <Link href="/" className="flex items-center gap-2 md:gap-3 hover:opacity-80 transition-opacity group">
            <span className="text-2xl md:text-3xl font-light text-[#d4af37] tracking-wider">
              ∇<sup className="text-base md:text-xl animate-x-rotate inline-block">x</sup>
            </span>
            <span className="text-lg md:text-2xl font-light tracking-wide">
              <span className="text-[#e8e8e8]">Nabla-</span>
              <span className="bg-gradient-to-r from-[#d4af37] via-[#f4cf47] to-[#d4af37] bg-clip-text text-transparent font-medium">
                X
              </span>
            </span>
          </Link>
          <div className="hidden md:flex items-center gap-8">
            <Link href="/about" className="text-sm tracking-wide hover:text-[#d4af37] transition-colors">
              About
            </Link>
            <Link href="/services" className="text-sm tracking-wide text-[#d4af37]">
              Services
            </Link>
            <Link href="/contact" className="text-sm tracking-wide hover:text-[#d4af37] transition-colors">
              Contact
            </Link>
          </div>
        </nav>
      </header>

      <section className="pt-32 pb-20 container mx-auto px-6">
        <div className="max-w-5xl mx-auto">
          {/* ICP Badge - More explicit */}
          <div className="flex flex-wrap items-center justify-center gap-3 mb-6">
            <div className="inline-flex items-center gap-2 px-4 py-2 rounded-full bg-[#d4af37]/10 border border-[#d4af37]/20">
              <Sparkles className="w-4 h-4 text-[#d4af37]" />
              <span className="text-sm text-[#d4af37] font-medium">For Fintechs & AI Platforms</span>
            </div>
            <div className="inline-flex items-center gap-2 px-4 py-2 rounded-full bg-[#d4af37]/10 border border-[#d4af37]/20">
              <Shield className="w-4 h-4 text-[#d4af37]" />
              <span className="text-sm text-[#d4af37] font-medium">SOC 2 Compliant • Auditable</span>
            </div>
          </div>

          {/* Sharp Positioning Line */}
          <h1 className="text-5xl md:text-6xl font-light leading-tight mb-6 text-balance text-center">
            <span className="text-[#d4af37]">Production-grade AI observability</span> <br />
            that prevents failures before they compound
          </h1>

          {/* Differentiation Statement */}
          <p className="text-xl text-center text-[#b8b8b8] mb-4 leading-relaxed max-w-4xl mx-auto">
            Unlike ungoverned auto-SQL tools, Nabla-X builds{" "}
            <span className="text-[#d4af37]">explainable, auditable decision systems</span> with operational
            guarantees—so you can trust your AI in regulated, high-stakes environments.
          </p>

          {/* Business Results */}
          <div className="flex flex-wrap justify-center gap-6 mb-8 text-center">
            {[
              { metric: "99.9%", label: "Uptime SLA" },
              { metric: "$2.4M", label: "Avg. Incidents Prevented/Year" },
              { metric: "68%", label: "Faster Root-Cause Analysis" },
            ].map((stat, i) => (
              <div key={i} className="flex flex-col items-center">
                <div className="text-2xl font-semibold text-[#d4af37]">{stat.metric}</div>
                <div className="text-sm text-[#b8b8b8]">{stat.label}</div>
              </div>
            ))}
          </div>

          {/* Multi-level CTAs */}
          <div className="flex flex-col sm:flex-row items-center gap-4 justify-center mb-8">
            <Link href="/demo">
              <Button className="bg-[#d4af37] text-[#0a0a0a] hover:bg-[#c4a037] px-8 py-6 text-base font-medium">
                Try Interactive Demo
              </Button>
            </Link>
            <Link href="/contact">
              <Button
                variant="outline"
                className="border-[#d4af37] text-[#d4af37] hover:bg-[#d4af37]/10 bg-transparent"
              >
                Book Architecture Review
              </Button>
            </Link>
          </div>

          {/* Who should/shouldn't contact us */}
          <div className="grid md:grid-cols-2 gap-4 max-w-3xl mx-auto mt-12">
            <Card className="bg-emerald-950/20 border-emerald-500/30 p-6">
              <div className="flex items-start gap-3 mb-3">
                <CheckCircle2 className="w-5 h-5 text-emerald-400 flex-shrink-0 mt-1" />
                <div>
                  <h4 className="font-medium text-emerald-400 mb-2">You're a great fit if:</h4>
                  <ul className="text-sm text-[#b8b8b8] space-y-1">
                    <li>• Operating in regulated environments (HIPAA, SOC 2)</li>
                    <li>• AI/ML decisions require auditability</li>
                    <li>• Data volumes exceed 10M+ rows</li>
                    <li>• Decision latency is business-critical</li>
                  </ul>
                </div>
              </div>
            </Card>

            <Card className="bg-rose-950/20 border-rose-500/30 p-6">
              <div className="flex items-start gap-3 mb-3">
                <XCircle className="w-5 h-5 text-rose-400 flex-shrink-0 mt-1" />
                <div>
                  <h4 className="font-medium text-rose-400 mb-2">Not the right fit if:</h4>
                  <ul className="text-sm text-[#b8b8b8] space-y-1">
                    <li>• You need one-off dashboards</li>
                    <li>• Budget under $50K annual</li>
                    <li>• No dedicated data team</li>
                    <li>• Looking for quick chatbot layer</li>
                  </ul>
                </div>
              </div>
            </Card>
          </div>
        </div>
      </section>

      <section className="py-20 border-t border-[#d4af37]/20 bg-[#0a0a0a]/30">
        <div className="container mx-auto px-6 max-w-6xl">
          <div className="text-center mb-16">
            <div className="inline-flex items-center gap-2 px-4 py-2 rounded-full bg-[#d4af37]/10 border border-[#d4af37]/20 mb-4">
              <TrendingUp className="w-4 h-4 text-[#d4af37]" />
              <span className="text-sm text-[#d4af37] font-medium">Proven Impact</span>
            </div>
            <h2 className="text-4xl font-light mb-4">
              Quantified <span className="text-[#d4af37]">outcomes</span>
            </h2>
            <p className="text-[#b8b8b8] max-w-2xl mx-auto">
              Real results from regulated environments where failures are expensive and trust is non-negotiable.
            </p>
          </div>

          <div className="grid sm:grid-cols-2 md:grid-cols-3 gap-6">
            {[
              {
                title: "Revenue Drift Diagnosis",
                industry: "Healthcare • Series B",
                metrics: ["$1.8M revenue leakage identified", "42% faster anomaly detection", "8-week deployment"],
                desc: "Diagnosed drivers of revenue volatility across 12 hospital networks while guarding against incomplete data sources.",
                link: "/case-studies/revenue-drift-healthcare",
              },
              {
                title: "Anomaly Protection System",
                industry: "Financial Services • Public",
                metrics: ["$2.4M incidents prevented annually", "99.97% detection accuracy", "6-week deployment"],
                desc: "Real-time data sentinel for trade and settlement pipelines with full auditability and compliance tracking.",
                link: "/case-studies/anomaly-protection-finserv",
              },
              {
                title: "Explainability Platform",
                industry: "Telecommunications • Enterprise",
                metrics: ["68% faster root-cause analysis", "3.2x improvement in MTTR", "12-week deployment"],
                desc: "Production-grade explainability for network operations and customer analytics with regulatory compliance.",
                link: "/case-studies/explainability-platform-telco",
              },
            ].map((study, i) => (
              <motion.div
                key={i}
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ delay: i * 0.1 }}
                whileHover={{ y: -8 }}
              >
                <Link href={study.link}>
                  <Card className="bg-[#1a1a1a]/50 border-[#d4af37]/30 hover:border-[#d4af37] p-8 h-full transition-all duration-300 group cursor-pointer">
                    <div className="inline-block text-xs px-3 py-1 rounded-full mb-4 bg-[#d4af37]/10 text-[#d4af37] border border-[#d4af37]/20">
                      {study.industry}
                    </div>
                    <h4 className="text-xl font-medium mb-3 text-[#d4af37] group-hover:text-[#f4cf47] transition-colors">
                      {study.title}
                    </h4>

                    {/* Quantified Metrics */}
                    <div className="space-y-2 mb-4 p-4 bg-[#0a0a0a]/50 rounded-lg border border-[#d4af37]/10">
                      {study.metrics.map((metric, idx) => (
                        <div key={idx} className="flex items-start gap-2">
                          <CheckCircle2 className="w-4 h-4 text-[#d4af37] flex-shrink-0 mt-0.5" />
                          <span className="text-sm text-[#d4af37]">{metric}</span>
                        </div>
                      ))}
                    </div>

                    <p className="text-[#b8b8b8] leading-relaxed text-sm mb-4">{study.desc}</p>
                    <div className="inline-flex items-center gap-2 text-sm text-[#d4af37] group-hover:gap-3 transition-all">
                      <span>Read full case study</span>
                      <span>→</span>
                    </div>
                  </Card>
                </Link>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      <section className="py-20 border-t border-[#d4af37]/20">
        <div className="container mx-auto px-6 max-w-6xl">
          <div className="text-center mb-16">
            <div className="inline-flex items-center gap-2 px-4 py-2 rounded-full bg-[#d4af37]/10 border border-[#d4af37]/20 mb-4">
              <Shield className="w-4 h-4 text-[#d4af37]" />
              <span className="text-sm text-[#d4af37] font-medium">What We Enable</span>
            </div>
            <h2 className="text-4xl font-light mb-4">
              Business outcomes, not <span className="text-[#d4af37]">feature lists</span>
            </h2>
            <p className="text-[#b8b8b8] max-w-2xl mx-auto">
              Real, measurable improvements to reliability, compliance, and operational efficiency.
            </p>
          </div>

          <div className="grid sm:grid-cols-2 md:grid-cols-3 gap-6">
            {[
              {
                title: "Prevent Costly Failures",
                businessResult: "Average $2.4M in incidents prevented annually",
                desc: "Context-rich explanations with assumptions, exclusions, and alternative interpretations from execution context.",
                icon: Sparkles,
              },
              {
                title: "Ensure Regulatory Compliance",
                businessResult: "100% audit-ready with full decision lineage",
                desc: "Execute analytics under constraints with timeouts, row limits, and blast-radius estimation for safety and auditability.",
                icon: Shield,
              },
              {
                title: "Accelerate Root-Cause Analysis",
                businessResult: "68% faster mean time to resolution (MTTR)",
                desc: "Map intent to authoritative schemas and business glossaries—prevent ambiguity and silent failures at scale.",
                icon: Zap,
              },
            ].map((item, i) => (
              <motion.div
                key={i}
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ delay: i * 0.1 }}
                whileHover={{ y: -5 }}
              >
                <Card className="bg-[#1a1a1a]/50 border-[#d4af37]/30 hover:border-[#d4af37] p-8 h-full transition-all duration-300">
                  <div className="p-3 rounded-xl bg-[#d4af37]/10 w-fit mb-4">
                    <item.icon className="w-6 h-6 text-[#d4af37]" />
                  </div>
                  <h3 className="text-xl text-[#d4af37] mb-3 font-medium">{item.title}</h3>
                  <div className="text-sm font-semibold text-emerald-400 mb-3">{item.businessResult}</div>
                  <p className="text-[#b8b8b8] leading-relaxed text-sm">{item.desc}</p>
                </Card>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* Engineering Services */}
      <section className="py-20 border-t border-[#d4af37]/20 bg-gradient-to-b from-[#0a0a0a] to-[#1a1a1a]">
        <div className="container mx-auto px-6 max-w-6xl">
          <div className="text-center mb-16">
            <div className="inline-flex items-center gap-2 px-4 py-2 rounded-full bg-[#d4af37]/10 border border-[#d4af37]/20 mb-4">
              <Code className="w-4 h-4 text-[#d4af37]" />
              <span className="text-sm text-[#d4af37] font-medium">Custom Development</span>
            </div>
            <h2 className="text-4xl font-light mb-4">
              Engineering <span className="text-[#d4af37]">Services</span>
            </h2>
            <p className="text-[#b8b8b8] max-w-2xl mx-auto">
              AI/ML engineering, data science, and data engineering—turning complex data into intelligent solutions
            </p>
          </div>

          <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-6">
            {[
              {
                title: "AI/ML Engineering",
                icon: Cpu,
                desc: "Custom machine learning models, LLM integrations, and intelligent automation solutions tailored to your needs.",
                features: [
                  "Custom ML model development",
                  "LLM & RAG systems",
                  "Data pipeline engineering",
                  "Model deployment & MLOps",
                ],
                href: "/engineering/ai-ml",
              },
              {
                title: "Data Engineering",
                icon: Database,
                desc: "Build robust data pipelines, warehouses, and analytics platforms that turn raw data into actionable insights.",
                features: [
                  "ETL/ELT pipeline development",
                  "Data warehouse design",
                  "Real-time data processing",
                  "Analytics dashboards",
                ],
                href: "/engineering/data-engineering",
              },
              {
                title: "Data Analysis & Data Science",
                icon: TrendingUp,
                desc: "Advanced statistical analysis, predictive modeling, and business intelligence to drive data-informed decisions.",
                features: [
                  "Exploratory data analysis",
                  "Statistical modeling & forecasting",
                  "Business intelligence dashboards",
                  "A/B testing & experimentation",
                ],
                href: "/engineering/data-science",
              },
            ].map((service, i) => (
              <motion.div
                key={i}
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ delay: i * 0.1 }}
                whileHover={{ y: -5 }}
              >
                <Link href={service.href}>
                  <Card className="bg-[#1a1a1a]/50 border-[#d4af37]/30 hover:border-[#d4af37] p-8 h-full transition-all duration-300 group cursor-pointer">
                    <div className="p-3 rounded-xl bg-[#d4af37]/10 w-fit mb-4 group-hover:bg-[#d4af37]/20 transition-colors">
                      <service.icon className="w-6 h-6 text-[#d4af37]" />
                    </div>
                    <h3 className="text-xl text-[#d4af37] mb-3 font-medium group-hover:text-[#f4cf47] transition-colors">
                      {service.title}
                    </h3>
                    <p className="text-[#b8b8b8] leading-relaxed text-sm mb-4">{service.desc}</p>

                    <div className="space-y-2 pt-4 border-t border-[#d4af37]/20">
                      {service.features.map((feature, idx) => (
                        <div key={idx} className="flex items-start gap-2">
                          <CheckCircle2 className="w-4 h-4 text-[#d4af37] flex-shrink-0 mt-0.5" />
                          <span className="text-xs text-[#b8b8b8]">{feature}</span>
                        </div>
                      ))}
                    </div>

                    <div className="flex items-center gap-2 mt-6 text-[#d4af37] text-sm font-medium group-hover:gap-3 transition-all">
                      <span>Learn More</span>
                      <ArrowRight className="w-4 h-4" />
                    </div>
                  </Card>
                </Link>
              </motion.div>
            ))}
          </div>

          <div className="mt-12 text-center">
            <p className="text-[#b8b8b8] mb-6 max-w-2xl mx-auto">
              Whether you need a dedicated team or specialized expertise for a specific project, we deliver
              production-ready solutions with clean code, comprehensive documentation, and ongoing support.
            </p>
            <Link href="/contact">
              <Button className="bg-[#d4af37] text-[#0a0a0a] hover:bg-[#c4a037] px-8 py-6 text-base font-medium">
                Discuss Your Project
                <ArrowRight className="w-4 h-4 ml-2" />
              </Button>
            </Link>
          </div>
        </div>
      </section>

      {/* Compliance & Standards */}
      <section className="py-16 bg-black/30">
        <div className="container mx-auto px-6 max-w-6xl">
          <div className="text-center mb-12">
            <h2 className="text-3xl md:text-4xl font-medium mb-4">Compliance-First Architecture</h2>
            <p className="text-[#b8b8b8] text-lg max-w-3xl mx-auto">
              Built for regulated industries where every decision must be explainable, auditable, and defensible.
            </p>
          </div>

          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
            <div className="bg-[#1a1a1a]/50 border border-[#d4af37]/30 rounded-xl p-6">
              <Shield className="w-8 h-8 text-[#d4af37] mb-4" />
              <h3 className="font-medium text-lg mb-2">HIPAA Ready</h3>
              <p className="text-sm text-[#b8b8b8]">
                Patient data encryption, access logging, BAA-compliant infrastructure
              </p>
            </div>

            <div className="bg-[#1a1a1a]/50 border border-[#d4af37]/30 rounded-xl p-6">
              <Lock className="w-8 h-8 text-[#d4af37] mb-4" />
              <h3 className="font-medium text-lg mb-2">SOC 2 Type II</h3>
              <p className="text-sm text-[#b8b8b8]">
                Security, availability, processing integrity controls audited annually
              </p>
            </div>

            <div className="bg-[#1a1a1a]/50 border border-[#d4af37]/30 rounded-xl p-6">
              <FileText className="w-8 h-8 text-[#d4af37] mb-4" />
              <h3 className="font-medium text-lg mb-2">Audit Trail</h3>
              <p className="text-sm text-[#b8b8b8]">Every AI decision logged with human-readable justifications</p>
            </div>

            <div className="bg-[#1a1a1a]/50 border border-[#d4af37]/30 rounded-xl p-6">
              <Database className="w-8 h-8 text-[#d4af37] mb-4" />
              <h3 className="font-medium text-lg mb-2">Data Residency</h3>
              <p className="text-sm text-[#b8b8b8]">Deploy in your VPC or cloud region for compliance</p>
            </div>

            <div className="bg-[#1a1a1a]/50 border border-[#d4af37]/30 rounded-xl p-6">
              <Key className="w-8 h-8 text-[#d4af37] mb-4" />
              <h3 className="font-medium text-lg mb-2">Role-Based Access</h3>
              <p className="text-sm text-[#b8b8b8]">Granular permissions, SSO integration, MFA enforcement</p>
            </div>

            <div className="bg-[#1a1a1a]/50 border border-[#d4af37]/30 rounded-xl p-6">
              <AlertTriangle className="w-8 h-8 text-[#d4af37] mb-4" />
              <h3 className="font-medium text-lg mb-2">Incident Response</h3>
              <p className="text-sm text-[#b8b8b8]">24/7 monitoring, escalation runbooks, rollback mechanisms</p>
            </div>
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-24 bg-gradient-to-b from-black/50 to-black">
        <div className="container mx-auto px-6 max-w-6xl text-center">
          <h2 className="text-4xl font-light mb-4 text-[#e8e8e8]">Ready to take the next step?</h2>
          <p className="text-lg text-[#b8b8b8] mb-8">Let's discuss how Nabla-X can enhance your AI initiatives.</p>
          <Link href="/contact">
            <Button className="bg-[#d4af37] text-[#0a0a0a] hover:bg-[#c4a037] px-8 py-6 text-base font-medium">
              Contact Us
            </Button>
          </Link>
        </div>
      </section>

      {/* Footer */}
      <footer className="py-12 border-t border-[#d4af37]/20">
        <div className="container mx-auto px-6 text-center text-[#b8b8b8]">
          <p className="text-sm">&copy; 2025 Nabla-X. Intelligence for complex systems.</p>
        </div>
      </footer>
    </div>
  )
}
