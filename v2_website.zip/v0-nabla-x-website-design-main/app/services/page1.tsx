"use client"

import Link from "next/link"
import { Database, Sparkles, TrendingUp, Bot, LineChart } from "lucide-react"
import { Card } from "@/components/ui/card"

export default function ServicesPage() {
  return (
    <div className="min-h-screen bg-gradient-to-br from-[#0d0d0d] via-[#1a1a1a] to-[#0f0f0f] text-[#f0f0f0]">
      {/* Header */}
      <header className="fixed top-0 w-full z-40 border-b border-[#00ffff]/20 bg-[#0d0d0d]/80 backdrop-blur-md">
        <nav className="container mx-auto px-6 py-4 flex items-center justify-between">
          <Link href="/" className="flex items-center gap-2 md:gap-3 hover:opacity-80 transition-opacity group">
            <span className="text-2xl md:text-3xl font-light text-[#00ffff] tracking-wider">
              ∇<sup className="text-base md:text-xl animate-x-glitch inline-block">x</sup>
            </span>
            <span className="text-lg md:text-2xl font-light tracking-wide">
              <span className="text-[#f0f0f0]">Nabla-</span>
              <span className="bg-gradient-to-r from-[#00ffff] via-[#4dffff] to-[#00ffff] bg-clip-text text-transparent font-medium">
                X
              </span>
            </span>
          </Link>
          <div className="hidden md:flex items-center gap-8">
            <Link href="/about" className="text-sm tracking-wide hover:text-[#00ffff] transition-colors">
              About
            </Link>
            <Link href="/services" className="text-sm tracking-wide text-[#00ffff]">
              Services
            </Link>
            <Link href="/contact" className="text-sm tracking-wide hover:text-[#00ffff] transition-colors">
              Contact
            </Link>
          </div>
        </nav>
      </header>

      {/* Cybernetic Grid Background */}
      <div className="cyber-grid"></div>

      {/* Hero Section */}
      <section className="pt-32 pb-20 container mx-auto px-6 relative">
        <div className="max-w-4xl mx-auto text-center">
          <h1 className="text-5xl md:text-6xl font-light mb-6 tracking-tight">
            <span className="text-[#00ffff]">Services</span>
          </h1>
          <p className="text-xl text-[#b0b0b0] leading-relaxed text-pretty">
            AI. Data. Intelligence. Delivered with precision.
          </p>
          <p className="text-base text-[#808080] mt-4 leading-relaxed max-w-3xl mx-auto">
            Nabla-X provides end-to-end AI and data engineering services designed for enterprises, startups, and
            educational institutions ready to scale with intelligence.
          </p>
        </div>
      </section>

      {/* AI & Machine Learning Services */}
      <section className="py-20 container mx-auto px-6">
        <div className="max-w-6xl mx-auto">
          <div className="mb-20">
            <h2 className="text-4xl font-light mb-4 text-[#00ffff] flex items-center gap-3">
              <Bot className="w-10 h-10" />
              AI & Machine Learning Services
            </h2>
            <p className="text-lg text-[#b0b0b0] mb-10">Build AI systems that understand, predict, and act.</p>

            <div className="grid md:grid-cols-2 gap-8">
              <Card className="bg-[#1a1a1a] border-[#00ffff]/30 hover:border-[#00ffff] transition-all p-8">
                <h3 className="text-2xl font-light mb-4 text-[#00ffff]">Custom AI Development</h3>
                <ul className="space-y-3 text-[#b0b0b0]">
                  <li className="flex items-start gap-2">
                    <span className="text-[#00ffff] mt-1">→</span>
                    <span>LLM-powered copilots, agents & chatbots</span>
                  </li>
                  <li className="flex items-start gap-2">
                    <span className="text-[#00ffff] mt-1">→</span>
                    <span>Domain-specific AI models</span>
                  </li>
                  <li className="flex items-start gap-2">
                    <span className="text-[#00ffff] mt-1">→</span>
                    <span>AI workflow automation</span>
                  </li>
                  <li className="flex items-start gap-2">
                    <span className="text-[#00ffff] mt-1">→</span>
                    <span>Knowledge graph & semantic intelligence development</span>
                  </li>
                </ul>
              </Card>

              <Card className="bg-[#1a1a1a] border-[#00ffff]/30 hover:border-[#00ffff] transition-all p-8">
                <h3 className="text-2xl font-light mb-4 text-[#00ffff]">Machine Learning Engineering</h3>
                <ul className="space-y-3 text-[#b0b0b0]">
                  <li className="flex items-start gap-2">
                    <span className="text-[#00ffff] mt-1">→</span>
                    <span>Feature engineering & model development</span>
                  </li>
                  <li className="flex items-start gap-2">
                    <span className="text-[#00ffff] mt-1">→</span>
                    <span>Model training, tuning & deployment (MLOps)</span>
                  </li>
                  <li className="flex items-start gap-2">
                    <span className="text-[#00ffff] mt-1">→</span>
                    <span>Explainability, fairness & governance</span>
                  </li>
                  <li className="flex items-start gap-2">
                    <span className="text-[#00ffff] mt-1">→</span>
                    <span>Model drift monitoring and improvement</span>
                  </li>
                </ul>
              </Card>
            </div>
          </div>

          {/* Data Engineering & Cloud Architecture */}
          <div className="mb-20">
            <h2 className="text-4xl font-light mb-4 text-[#00ffff] flex items-center gap-3">
              <Database className="w-10 h-10" />
              Data Engineering & Cloud Architecture
            </h2>
            <p className="text-lg text-[#b0b0b0] mb-10">Modern data stacks built the right way.</p>

            <div className="grid md:grid-cols-2 gap-8">
              <Card className="bg-[#1a1a1a] border-[#00ffff]/30 hover:border-[#00ffff] transition-all p-8">
                <h3 className="text-2xl font-light mb-4 text-[#00ffff]">Data Platform Engineering</h3>
                <ul className="space-y-3 text-[#b0b0b0]">
                  <li className="flex items-start gap-2">
                    <span className="text-[#00ffff] mt-1">→</span>
                    <span>Cloud data warehouse design (Snowflake, BigQuery, Redshift)</span>
                  </li>
                  <li className="flex items-start gap-2">
                    <span className="text-[#00ffff] mt-1">→</span>
                    <span>ETL/ELT pipelines & orchestration</span>
                  </li>
                  <li className="flex items-start gap-2">
                    <span className="text-[#00ffff] mt-1">→</span>
                    <span>Real-time & streaming architectures</span>
                  </li>
                  <li className="flex items-start gap-2">
                    <span className="text-[#00ffff] mt-1">→</span>
                    <span>Data modeling (Kimball, Data Vault, semantic layers)</span>
                  </li>
                </ul>
              </Card>

              <Card className="bg-[#1a1a1a] border-[#00ffff]/30 hover:border-[#00ffff] transition-all p-8">
                <h3 className="text-2xl font-light mb-4 text-[#00ffff]">Data Reliability & Quality</h3>
                <ul className="space-y-3 text-[#b0b0b0]">
                  <li className="flex items-start gap-2">
                    <span className="text-[#00ffff] mt-1">→</span>
                    <span>Automated anomaly detection</span>
                  </li>
                  <li className="flex items-start gap-2">
                    <span className="text-[#00ffff] mt-1">→</span>
                    <span>Rule-less DQ frameworks</span>
                  </li>
                  <li className="flex items-start gap-2">
                    <span className="text-[#00ffff] mt-1">→</span>
                    <span>Data contracts & schema governance</span>
                  </li>
                  <li className="flex items-start gap-2">
                    <span className="text-[#00ffff] mt-1">→</span>
                    <span>Lineage, cataloging & metadata intelligence</span>
                  </li>
                </ul>
              </Card>
            </div>
          </div>

          {/* Analytics Modernization */}
          <div className="mb-20">
            <h2 className="text-4xl font-light mb-4 text-[#00ffff] flex items-center gap-3">
              <TrendingUp className="w-10 h-10" />
              Analytics Modernization
            </h2>
            <p className="text-lg text-[#b0b0b0] mb-10">Turn raw data into decisions. Automatically.</p>

            <div className="grid md:grid-cols-2 gap-8">
              <Card className="bg-[#1a1a1a] border-[#00ffff]/30 hover:border-[#00ffff] transition-all p-8">
                <h3 className="text-2xl font-light mb-4 text-[#00ffff]">Business Intelligence & Insights</h3>
                <ul className="space-y-3 text-[#b0b0b0]">
                  <li className="flex items-start gap-2">
                    <span className="text-[#00ffff] mt-1">→</span>
                    <span>Dashboard modernization</span>
                  </li>
                  <li className="flex items-start gap-2">
                    <span className="text-[#00ffff] mt-1">→</span>
                    <span>Automated insights & RCA</span>
                  </li>
                  <li className="flex items-start gap-2">
                    <span className="text-[#00ffff] mt-1">→</span>
                    <span>KPI standardization & governance</span>
                  </li>
                  <li className="flex items-start gap-2">
                    <span className="text-[#00ffff] mt-1">→</span>
                    <span>Self-service analytics frameworks</span>
                  </li>
                </ul>
              </Card>

              <Card className="bg-[#1a1a1a] border-[#00ffff]/30 hover:border-[#00ffff] transition-all p-8">
                <h3 className="text-2xl font-light mb-4 text-[#00ffff]">Predictive & Prescriptive Intelligence</h3>
                <ul className="space-y-3 text-[#b0b0b0]">
                  <li className="flex items-start gap-2">
                    <span className="text-[#00ffff] mt-1">→</span>
                    <span>Forecasting systems</span>
                  </li>
                  <li className="flex items-start gap-2">
                    <span className="text-[#00ffff] mt-1">→</span>
                    <span>Optimization & scenario simulation</span>
                  </li>
                  <li className="flex items-start gap-2">
                    <span className="text-[#00ffff] mt-1">→</span>
                    <span>Decision systems powered by AI</span>
                  </li>
                </ul>
              </Card>
            </div>
          </div>

          {/* Product-Led Implementations */}
          <div className="mb-20">
            <h2 className="text-4xl font-light mb-4 text-[#00ffff] flex items-center gap-3">
              <Sparkles className="w-10 h-10" />
              Product-Led Implementations
            </h2>
            <p className="text-lg text-[#b0b0b0] mb-10">Powered by Nabla-X Intelligence Suite</p>

            <div className="grid md:grid-cols-2 gap-6">
              <Card className="bg-[#1a1a1a] border-[#00ffff]/30 hover:border-[#00ffff] transition-all p-6">
                <h3 className="text-xl font-light mb-2 text-[#00ffff]">QueryMind Deployment</h3>
                <p className="text-[#b0b0b0] text-sm">
                  Natural-language analytics for your team. Ask a question → Get SQL → Get insights.
                </p>
              </Card>

              <Card className="bg-[#1a1a1a] border-[#00ffff]/30 hover:border-[#00ffff] transition-all p-6">
                <h3 className="text-xl font-light mb-2 text-[#00ffff]">DataSentinel Setup</h3>
                <p className="text-[#b0b0b0] text-sm">Continuous monitoring for anomalies, reliability, and trust.</p>
              </Card>

              <Card className="bg-[#1a1a1a] border-[#00ffff]/30 hover:border-[#00ffff] transition-all p-6">
                <h3 className="text-xl font-light mb-2 text-[#00ffff]">RootSense Integration</h3>
                <p className="text-[#b0b0b0] text-sm">
                  Explainability + similarity discovery for KPI drops & operational issues.
                </p>
              </Card>

              <Card className="bg-[#1a1a1a] border-[#00ffff]/30 hover:border-[#00ffff] transition-all p-6">
                <h3 className="text-xl font-light mb-2 text-[#00ffff]">EduVerse Onboarding</h3>
                <p className="text-[#b0b0b0] text-sm">
                  Personalized explainer video generation for schools & EdTech platforms.
                </p>
              </Card>
            </div>
          </div>

          {/* Strategic AI Advisory */}
          <div>
            <h2 className="text-4xl font-light mb-4 text-[#00ffff] flex items-center gap-3">
              <LineChart className="w-10 h-10" />
              Strategic AI Advisory
            </h2>
            <p className="text-lg text-[#b0b0b0] mb-10">Not just implementation — real AI roadmap creation.</p>

            <Card className="bg-[#1a1a1a] border-[#00ffff]/30 p-8">
              <div className="grid md:grid-cols-3 gap-6">
                <div>
                  <h4 className="font-light text-[#00ffff] mb-2">AI Transformation Strategy</h4>
                  <p className="text-sm text-[#b0b0b0]">End-to-end roadmaps aligned with business goals</p>
                </div>
                <div>
                  <h4 className="font-light text-[#00ffff] mb-2">Data Maturity Assessments</h4>
                  <p className="text-sm text-[#b0b0b0]">Gap analysis and capability building</p>
                </div>
                <div>
                  <h4 className="font-light text-[#00ffff] mb-2">Use-Case Prioritization</h4>
                  <p className="text-sm text-[#b0b0b0]">ROI-driven project selection</p>
                </div>
                <div>
                  <h4 className="font-light text-[#00ffff] mb-2">Architecture Advisory</h4>
                  <p className="text-sm text-[#b0b0b0]">CoE setup and technical guidance</p>
                </div>
                <div>
                  <h4 className="font-light text-[#00ffff] mb-2">AI Readiness Audits</h4>
                  <p className="text-sm text-[#b0b0b0]">Infrastructure and team capability review</p>
                </div>
                <div>
                  <h4 className="font-light text-[#00ffff] mb-2">Governance Frameworks</h4>
                  <p className="text-sm text-[#b0b0b0]">Ethics, compliance, and risk management</p>
                </div>
              </div>
            </Card>
          </div>
        </div>
      </section>
      {/* </CHANGE> */}

      {/* Our Approach Section */}
      <section className="py-20 bg-[#0a0a0a] border-y border-[#00ffff]/20">
        <div className="container mx-auto px-6">
          <div className="max-w-5xl mx-auto">
            <h2 className="text-4xl font-light mb-6 text-center text-[#00ffff]">Our Approach</h2>
            <p className="text-center text-[#b0b0b0] mb-12 text-lg max-w-3xl mx-auto">
              A disciplined, engineering-first methodology that combines human insight with machine intelligence.
            </p>

            <div className="grid md:grid-cols-2 gap-8">
              <Card className="bg-[#1a1a1a] border-[#00ffff]/30 p-6">
                <div className="text-3xl font-light text-[#00ffff] mb-3">01</div>
                <h3 className="text-xl font-light mb-2 text-[#00ffff]">Discovery With Precision</h3>
                <p className="text-[#b0b0b0] text-sm leading-relaxed">
                  We start by understanding the real problem, not just the stated requirement. Our team assesses data
                  readiness, constraints, business processes, and measurable impact areas.
                </p>
              </Card>

              <Card className="bg-[#1a1a1a] border-[#00ffff]/30 p-6">
                <div className="text-3xl font-light text-[#00ffff] mb-3">02</div>
                <h3 className="text-xl font-light mb-2 text-[#00ffff]">Data-Driven Scoping</h3>
                <p className="text-[#b0b0b0] text-sm leading-relaxed">
                  Every engagement begins with a quantifiable blueprint: success metrics, timelines, architectural fit,
                  complexity score, and dependency analysis. No guesswork — only clarity.
                </p>
              </Card>

              <Card className="bg-[#1a1a1a] border-[#00ffff]/30 p-6">
                <div className="text-3xl font-light text-[#00ffff] mb-3">03</div>
                <h3 className="text-xl font-light mb-2 text-[#00ffff]">Rapid PoC, Real Results</h3>
                <p className="text-[#b0b0b0] text-sm leading-relaxed">
                  Using the Nabla-X AI Suite, we deliver functional prototypes in 7–14 days, enabling fast validation
                  and iteration. This builds trust and accelerates adoption.
                </p>
              </Card>

              <Card className="bg-[#1a1a1a] border-[#00ffff]/30 p-6">
                <div className="text-3xl font-light text-[#00ffff] mb-3">04</div>
                <h3 className="text-xl font-light mb-2 text-[#00ffff]">Human-AI Co-Design</h3>
                <p className="text-[#b0b0b0] text-sm leading-relaxed">
                  We bring together your domain expertise and our AI capabilities. Every solution is co-designed to
                  ensure usability, interpretability, operational fit, and long-term scalability.
                </p>
              </Card>

              <Card className="bg-[#1a1a1a] border-[#00ffff]/30 p-6">
                <div className="text-3xl font-light text-[#00ffff] mb-3">05</div>
                <h3 className="text-xl font-light mb-2 text-[#00ffff]">Engineering for Scale</h3>
                <p className="text-[#b0b0b0] text-sm leading-relaxed">
                  All systems are built on cloud-native, modular, API-driven architecture from day one. This ensures
                  smooth expansion from PoC → pilot → full enterprise deployment.
                </p>
              </Card>

              <Card className="bg-[#1a1a1a] border-[#00ffff]/30 p-6">
                <div className="text-3xl font-light text-[#00ffff] mb-3">06</div>
                <h3 className="text-xl font-light mb-2 text-[#00ffff]">Responsible AI at the Core</h3>
                <p className="text-[#b0b0b0] text-sm leading-relaxed">
                  Every model follows principles of transparency, fairness, auditability, governance, and privacy
                  protection. Trust and ethics are not optional — they are engineered into the product.
                </p>
              </Card>

              <Card className="bg-[#1a1a1a] border-[#00ffff]/30 p-6">
                <div className="text-3xl font-light text-[#00ffff] mb-3">07</div>
                <h3 className="text-xl font-light mb-2 text-[#00ffff]">Continuous Optimization</h3>
                <p className="text-[#b0b0b0] text-sm leading-relaxed">
                  Our work doesn't end at deployment. We monitor model drift, data quality changes, KPI fluctuations,
                  and system performance. Your AI gets smarter over time.
                </p>
              </Card>

              <Card className="bg-[#1a1a1a] border-[#00ffff]/30 p-6">
                <div className="text-3xl font-light text-[#00ffff] mb-3">08</div>
                <h3 className="text-xl font-light mb-2 text-[#00ffff]">Partnership, Not Just Delivery</h3>
                <p className="text-[#b0b0b0] text-sm leading-relaxed">
                  Clients stay with Nabla-X because we operate as a long-term intelligence partner — not an agency, not
                  a vendor, but an AI extension of their team.
                </p>
              </Card>
              {/* </CHANGE> */}
            </div>
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="py-12 border-t border-[#00ffff]/20">
        <div className="container mx-auto px-6 text-center text-[#b0b0b0]">
          <p className="text-sm">&copy; 2025 Nabla-X. Let's build something meaningful.</p>
        </div>
      </footer>

      <style jsx>{`
        .cyber-grid {
          position: fixed;
          top: 0;
          left: 0;
          width: 100%;
          height: 100%;
          background-image: linear-gradient(rgba(0, 255, 255, 0.05) 1px, transparent 1px),
            linear-gradient(90deg, rgba(0, 255, 255, 0.05) 1px, transparent 1px);
          background-size: 40px 40px;
          pointer-events: none;
          z-index: 0;
          animation: gridPulse 4s ease-in-out infinite;
        }

        @keyframes gridPulse {
          0%,
          100% {
            opacity: 0.3;
          }
          50% {
            opacity: 0.6;
          }
        }

        @keyframes x-glitch {
          0%,
          90%,
          100% {
            transform: translate(0, 0);
          }
          92% {
            transform: translate(-2px, 2px);
          }
          94% {
            transform: translate(2px, -2px);
          }
          96% {
            transform: translate(-1px, 1px);
          }
          98% {
            transform: translate(1px, -1px);
          }
        }

        .animate-x-glitch {
          animation: x-glitch 5s ease-in-out infinite;
          display: inline-block;
        }
      `}</style>
    </div>
  )
}
