"use client"

import { useEffect, useState } from "react"
import Link from "next/link"
import { motion } from "framer-motion"
import { ArrowRight, Database, LineChart, Activity, MessageSquare, Shield, Search, GraduationCap } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Card } from "@/components/ui/card"
import { CheckCircle2 } from "lucide-react"
import { trackEvent, AnalyticsEvents } from "@/lib/analytics"

const sectionFadeIn = {
  hidden: { opacity: 0, y: 24 },
  show: {
    opacity: 1,
    y: 0,
    transition: { duration: 0.7, ease: "easeOut" },
  },
}

const staggerContainer = {
  hidden: {},
  show: {
    transition: {
      staggerChildren: 0.12,
    },
  },
}

const cardFadeUp = {
  hidden: {
    opacity: 0,
    y: 16,
  },
  show: {
    opacity: 1,
    y: 0,
    transition: {
      duration: 0.45,
      ease: "easeOut",
    },
  },
}

export default function HomePage() {
  const [showLogo, setShowLogo] = useState(false)
  const [logoAnimationComplete, setLogoAnimationComplete] = useState(false)

  useEffect(() => {
    const hasSeenAnimation = sessionStorage.getItem("nabla-x-intro-seen")

    if (!hasSeenAnimation) {
      setShowLogo(true)
      const timer = setTimeout(() => {
        setLogoAnimationComplete(true)
        sessionStorage.setItem("nabla-x-intro-seen", "true")
      }, 3000)
      return () => clearTimeout(timer)
    } else {
      setLogoAnimationComplete(true)
    }
  }, [])

  if (showLogo && !logoAnimationComplete) {
    return (
      <div className="fixed inset-0 z-50 flex items-center justify-center bg-[#0a0a0a]">
        <div className="logo-intro">
          <div className="text-8xl font-light text-[#d4af37] tracking-wider">
            ∇<sup className="text-5xl animate-x-pulse">x</sup>
          </div>
        </div>
      </div>
    )
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-[#0a0a0a] via-[#1a1a1a] to-[#0f0f0f] text-[#e8e8e8]">
      {/* Header */}
      <header className="fixed top-0 w-full z-40 border-b border-[#d4af37]/20 bg-[#0a0a0a]/80 backdrop-blur-md">
        <nav className="container mx-auto px-6 py-4 flex items-center justify-between">
          <Link href="/" className="flex items-center gap-2 md:gap-3 hover:opacity-80 transition-opacity group">
            <span className="text-2xl md:text-3xl font-light text-[#d4af37] tracking-wider">
              ∇<sup className="text-base md:text-xl animate-x-rotate inline-block">x</sup>
            </span>
            <span className="text-lg md:text-2xl font-light tracking-wide">
              <span className="text-[#e8e8e8]">Nabla-</span>
              <span className="bg-gradient-to-r from-[#d4af37] via-[#f4cf47] to-[#d4af37] bg-clip-text text-transparent font-medium">
                X
              </span>
            </span>
          </Link>
          <div className="hidden md:flex items-center gap-8">
            <Link
              href="/about"
              className="text-sm tracking-wide hover:text-[#d4af37] transition-colors"
              onClick={() => trackEvent(AnalyticsEvents.NAV_ABOUT_CLICKED)}
            >
              About
            </Link>
            <Link
              href="/services"
              className="text-sm tracking-wide hover:text-[#d4af37] transition-colors"
              onClick={() => trackEvent(AnalyticsEvents.NAV_SERVICES_CLICKED)}
            >
              Services
            </Link>
            <Link
              href="/contact"
              className="text-sm tracking-wide hover:text-[#d4af37] transition-colors"
              onClick={() => trackEvent(AnalyticsEvents.NAV_CONTACT_CLICKED)}
            >
              Contact
            </Link>
          </div>
        </nav>
      </header>

      {/* Hero Section */}
      <motion.section className="pt-28 pb-12 container mx-auto px-6">
        <div className="max-w-4xl mx-auto text-center">
          <div className="inline-flex items-center gap-2 mb-6 px-4 py-2 rounded-full border border-[#d4af37]/30 bg-[#d4af37]/5">
            <CheckCircle2 className="w-4 h-4 text-[#d4af37]" />
            <p className="text-sm text-[#d4af37] font-medium">AI Intelligence for Regulated Environments</p>
          </div>

          <h1 className="text-5xl md:text-7xl font-light mb-6 tracking-tight text-balance">
            Systems You Can Trust
            <span className="block text-[#d4af37] mt-2"> Even Under Regulation </span>
          </h1>
          <div className="flex flex-col sm:flex-row gap-4 justify-center mb-12">
            <Link href="/demo" onClick={() => trackEvent(AnalyticsEvents.HERO_DEMO_CLICKED)}>
              <Button className="bg-[#d4af37] text-[#0a0a0a] hover:bg-[#c4a037] px-8 py-6 text-base font-medium w-full sm:w-auto">
                Try Interactive Demo
              </Button>
            </Link>
            <Link href="/contact" onClick={() => trackEvent(AnalyticsEvents.HERO_SALES_CLICKED)}>
              <Button
                variant="outline"
                className="border-[#d4af37] text-[#d4af37] hover:bg-[#d4af37]/10 px-8 py-6 text-base bg-transparent w-full sm:w-auto"
              >
                Talk to Sales
              </Button>
            </Link>
          </div>

          <div className="flex flex-col sm:flex-row items-center justify-center gap-6 sm:gap-12 text-sm text-[#8a8a8a] border-t border-[#d4af37]/20 pt-8">
            <div className="flex items-center gap-2">
              <CheckCircle2 className="w-4 h-4 text-[#d4af37]" />
              <span>HIPAA & SOC 2 Compliant</span>
            </div>
            <div className="flex items-center gap-2">
              <CheckCircle2 className="w-4 h-4 text-[#d4af37]" />
              <span>99.9% Uptime SLA</span>
            </div>
            <div className="flex items-center gap-2">
              <CheckCircle2 className="w-4 h-4 text-[#d4af37]" />
              <span>Enterprise-Grade Security</span>
            </div>
          </div>

          <div className="relative max-w-3xl mx-auto mt-10">
            {/* Static text */}
            <p className="text-sm text-[#8a8a8a] text-center">
              Real-time observability and explainability for AI systems in healthcare, finance, and research. Detect data
            shifts, model drift, and pipeline faults with production-grade intelligence.
            </p>

            
            {/* subtle baseline */}
            <div className="h-px bg-[#d4af37]/30 mt-2 mx-auto w-full" />
          </div>
        </div>

        {/* Data Visualization */}
        <div className="mt-6 relative">
          <div className="grid-background absolute inset-0 opacity-20"></div>
          <div className="relative h-24 flex items-center justify-center">
            <div className="data-flow-animation">
              {[...Array(5)].map((_, i) => (
                <div key={i} className="data-particle" style={{ animationDelay: `${i * 0.3}s` }}></div>
              ))}
            </div>
          </div>
        </div>
        
      </motion.section>
      {/* Nabla-X Intelligence Suite Section */}
      <motion.section
        variants={sectionFadeIn}
        initial="hidden"
        whileInView="show"
        viewport={{ once: true, margin: "-80px" }}
        className="py-12 pb-20 container mx-auto px-6 border-y border-[#d4af37]/20" >
        
        <div className="text-center mb-16">
          <h2 className="text-5xl font-light mb-4 tracking-tight">
            Nabla-X <span className="text-[#d4af37]">Intelligence Suite</span>
          </h2>
          <p className="text-[#b8b8b8] text-lg max-w-2xl mx-auto text-pretty">
            Our native solutions for analytics, reliability, explainability, and learning intelligence
          </p>
        </div>

        <motion.div
            variants={staggerContainer}
            initial="hidden"
            whileInView="show"
            viewport={{ once: true }}
            className="grid md:grid-cols-2 gap-8 max-w-6xl mx-auto">
 
          {/* QueryMind */}
          <motion.div variants={cardFadeUp}>
            <Card className="group bg-gradient-to-br from-[#1a1a1a] to-[#0f1622] border-[#3b82f6]/40 hover:border-[#3b82f6] transition-all duration-300 p-8 h-full">
              <div className="mb-6 p-4 rounded-full bg-[#3b82f6]/10 w-fit">
                <MessageSquare className="w-8 h-8 text-[#3b82f6]" />
              </div>
              <h3 className="text-2xl font-light mb-2 text-[#3b82f6]">Nabla-X QueryMind</h3>
              <p className="text-sm text-[#3b82f6]/80 mb-4 italic">Ask. Analyze. Understand.</p>
              <p className="text-[#b8b8b8] mb-6 leading-relaxed">
                The AI Analytics Copilot. Ask questions in plain English, get SQL, charts, and instant insights. Analytics
                at the speed of a question.
              </p>
              <div className="flex gap-3 mt-auto">
                <Link
                  href="/products/querymind"
                  className="flex-1"
                  onClick={() => trackEvent(AnalyticsEvents.PRODUCT_LEARN_MORE, { product: "QueryMind" })}
                >
                  <Button
                    variant="outline"
                    className="w-full border-[#3b82f6] text-[#3b82f6] hover:bg-[#3b82f6]/10 bg-transparent"
                  >
                    Learn more
                  </Button>
                </Link>
                <Link
                  href="/contact"
                  className="flex-1"
                  onClick={() => trackEvent(AnalyticsEvents.PRODUCT_REQUEST_DEMO, { product: "QueryMind" })}
                >
                  <Button className="w-full bg-[#3b82f6] text-white hover:bg-[#3b82f6]/90">Request Demo</Button>
                </Link>
              </div>
            </Card>
          </motion.div>

          {/* DataSentinel */}
          <motion.div variants={cardFadeUp}>
            <Card className="group bg-gradient-to-br from-[#1a1a1a] to-[#0f1f0f] border-[#10b981]/40 hover:border-[#10b981] transition-all duration-300 p-8 h-full">
              <div className="mb-6 p-4 rounded-full bg-[#10b981]/10 w-fit">
                <Shield className="w-8 h-8 text-[#10b981]" />
              </div>
              <h3 className="text-2xl font-light mb-2 text-[#10b981]">Nabla-X DataSentinel</h3>
              <p className="text-sm text-[#10b981]/80 mb-4 italic">Your data's first line of defense.</p>
              <p className="text-[#b8b8b8] mb-6 leading-relaxed">
                AI that watches your data before it breaks. Anomaly detection, reliability monitoring, and automated data
                quality assurance.
              </p>
              <div className="flex gap-3 mt-auto">
                <Link
                  href="/products/datasentinel"
                  className="flex-1"
                  onClick={() => trackEvent(AnalyticsEvents.PRODUCT_LEARN_MORE, { product: "DataSentinel" })}
                >
                  <Button
                    variant="outline"
                    className="w-full border-[#10b981] text-[#10b981] hover:bg-[#10b981]/10 bg-transparent"
                  >
                    Learn more
                  </Button>
                </Link>
                <Link
                  href="/contact"
                  className="flex-1"
                  onClick={() => trackEvent(AnalyticsEvents.PRODUCT_REQUEST_DEMO, { product: "DataSentinel" })}
                >
                  <Button className="w-full bg-[#10b981] text-white hover:bg-[#10b981]/90">Request Demo</Button>
                </Link>
              </div>
            </Card>
          </motion.div>

          {/* RootSense */}
          <motion.div variants={cardFadeUp}>
            <Card className="group bg-gradient-to-br from-[#1a1a1a] to-[#221a0f] border-[#f97316]/40 hover:border-[#f97316] transition-all duration-300 p-8 h-full">
              <div className="mb-6 p-4 rounded-full bg-[#f97316]/10 w-fit">
                <Search className="w-8 h-8 text-[#f97316]" />
              </div>
              <h3 className="text-2xl font-light mb-2 text-[#f97316]">Nabla-X RootSense</h3>
              <p className="text-sm text-[#f97316]/80 mb-4 italic">Know the 'why' behind every outcome.</p>
              <p className="text-[#b8b8b8] mb-6 leading-relaxed">
                AI-powered root-cause intelligence. Deep explainability, feature importance, and similarity analysis to
                solve problems faster.
              </p>
              <div className="flex gap-3 mt-auto">
                <Link
                  href="/products/rootsense"
                  className="flex-1"
                  onClick={() => trackEvent(AnalyticsEvents.PRODUCT_LEARN_MORE, { product: "RootSense" })}
                >
                  <Button
                    variant="outline"
                    className="w-full border-[#f97316] text-[#f97316] hover:bg-[#f97316]/10 bg-transparent"
                  >
                    Learn more
                  </Button>
                </Link>
                <Link
                  href="/contact"
                  className="flex-1"
                  onClick={() => trackEvent(AnalyticsEvents.PRODUCT_REQUEST_DEMO, { product: "RootSense" })}
                >
                  <Button className="w-full bg-[#f97316] text-white hover:bg-[#f97316]/90">Request Demo</Button>
                </Link>
              </div>
            </Card>
          </motion.div>

          {/* EduVerse */}
          <motion.div variants={cardFadeUp}>
            <Card className="group bg-gradient-to-br from-[#1a1a1a] to-[#1a0f22] border-[#a855f7]/40 hover:border-[#a855f7] transition-all duration-300 p-8 h-full">
              <div className="mb-6 p-4 rounded-full bg-[#a855f7]/10 w-fit">
                <GraduationCap className="w-8 h-8 text-[#a855f7]" />
              </div>
              <h3 className="text-2xl font-light mb-2 text-[#a855f7]">Nabla-X EduVerse</h3>
              <p className="text-sm text-[#a855f7]/80 mb-4 italic">Personalized learning, one video at a time.</p>
              <p className="text-[#b8b8b8] mb-6 leading-relaxed">
                AI-generated explainer videos tailored to every learner. Adaptive content that understands age,
                difficulty, and learning style.
              </p>
              <div className="flex gap-3 mt-auto">
                <Link
                  href="/products/eduverse"
                  className="flex-1"
                  onClick={() => trackEvent(AnalyticsEvents.PRODUCT_LEARN_MORE, { product: "EduVerse" })}
                >
                  <Button
                    variant="outline"
                    className="w-full border-[#a855f7] text-[#a855f7] hover:bg-[#a855f7]/10 bg-transparent"
                  >
                    Learn more
                  </Button>
                </Link>
                <Link
                  href="/contact"
                  className="flex-1"
                  onClick={() => trackEvent(AnalyticsEvents.PRODUCT_REQUEST_DEMO, { product: "EduVerse" })}
                >
                  <Button className="w-full bg-[#a855f7] text-white hover:bg-[#a855f7]/90">Request Demo</Button>
                </Link>
              </div>
            </Card>
          </motion.div>
        </motion.div>
      </motion.section>

      {/* Industries Section */}
      <section className="py-20 container mx-auto px-6">
        <div className="text-center mb-16">
          <h2 className="text-4xl font-light mb-4 tracking-tight">Industries We Serve</h2>
          <p className="text-[#b8b8b8] text-lg">Precision intelligence for regulated environments</p>
        </div>

        <div className="grid md:grid-cols-3 gap-8 max-w-5xl mx-auto">
          <Link
            href="/industries/healthcare"
            onClick={() => trackEvent(AnalyticsEvents.INDUSTRY_EXPLORED, { industry: "Healthcare" })}
          >
            <Card className="group bg-[#1a1a1a] border-[#d4af37]/30 hover:border-[#d4af37] transition-all duration-300 p-8 cursor-pointer hover:transform hover:scale-105">
              <div className="mb-6 p-4 rounded-full bg-[#d4af37]/10 w-fit">
                <Activity className="w-8 h-8 text-[#d4af37]" />
              </div>
              <h3 className="text-2xl font-light mb-3 text-[#d4af37]">Healthcare</h3>
              <p className="text-[#b8b8b8] mb-4 leading-relaxed">
                Clinical decision support, predictive analytics, and operational intelligence for healthcare systems.
              </p>
              <div className="flex items-center text-[#d4af37] group-hover:translate-x-2 transition-transform">
                Explore <ArrowRight className="ml-2 w-4 h-4" />
              </div>
            </Card>
          </Link>

          <Link
            href="/industries/finance"
            onClick={() => trackEvent(AnalyticsEvents.INDUSTRY_EXPLORED, { industry: "Finance" })}
          >
            <Card className="group bg-[#1a1a1a] border-[#d4af37]/30 hover:border-[#d4af37] transition-all duration-300 p-8 cursor-pointer hover:transform hover:scale-105">
              <div className="mb-6 p-4 rounded-full bg-[#d4af37]/10 w-fit">
                <LineChart className="w-8 h-8 text-[#d4af37]" />
              </div>
              <h3 className="text-2xl font-light mb-3 text-[#d4af37]">Finance</h3>
              <p className="text-[#b8b8b8] mb-4 leading-relaxed">
                Risk modeling, fraud detection, and portfolio analytics built for regulatory compliance.
              </p>
              <div className="flex items-center text-[#d4af37] group-hover:translate-x-2 transition-transform">
                Explore <ArrowRight className="ml-2 w-4 h-4" />
              </div>
            </Card>
          </Link>

          <Link
            href="/industries/research"
            onClick={() => trackEvent(AnalyticsEvents.INDUSTRY_EXPLORED, { industry: "Research" })}
          >
            <Card className="group bg-[#1a1a1a] border-[#d4af37]/30 hover:border-[#d4af37] transition-all duration-300 p-8 cursor-pointer hover:transform hover:scale-105">
              <div className="mb-6 p-4 rounded-full bg-[#d4af37]/10 w-fit">
                <Database className="w-8 h-8 text-[#d4af37]" />
              </div>
              <h3 className="text-2xl font-light mb-3 text-[#d4af37]">Research</h3>
              <p className="text-[#b8b8b8] mb-4 leading-relaxed">
                Experimental systems, reproducible modeling, and computational frameworks for discovery.
              </p>
              <div className="flex items-center text-[#d4af37] group-hover:translate-x-2 transition-transform">
                Explore <ArrowRight className="ml-2 w-4 h-4" />
              </div>
            </Card>
          </Link>
        </div>
      </section>

      {/* Philosophy Section */}
      <section id="approach-section" className="py-20 bg-[#0f0f0f] border-y border-[#d4af37]/20">
        <div className="container mx-auto px-6">
          <div className="max-w-3xl mx-auto text-center">
            <div className="text-5xl font-light mb-6 text-[#d4af37]">
              ∇<sup className="text-3xl">x</sup>
            </div>
            <p className="text-2xl font-light mb-4">Direction of Greatest Change</p>
            <p className="text-[#b8b8b8] leading-relaxed text-lg">
              ∇ denotes the direction of greatest change. x represents the unknown. At Nabla-X, we build intelligence
              that understands how complex systems move.
            </p>
          </div>
        </div>
      </section>

      {/* Mobile-only quick navigation section */}
      <section className="md:hidden py-16 bg-gradient-to-b from-[#0a0a0a] to-[#1a1a1a]">
        <div className="container mx-auto px-6">
          <h2 className="text-3xl font-light text-center mb-10 text-[#d4af37]">Explore More</h2>
          <div className="grid gap-4 max-w-md mx-auto">
            <Link href="/about">
              <Card className="group bg-gradient-to-r from-[#1a1a1a] to-[#2a1a2a] border-[#d4af37]/30 hover:border-[#d4af37] transition-all duration-300 p-6 cursor-pointer">
                <div className="flex items-center justify-between">
                  <div>
                    <h3 className="text-xl font-light mb-1 text-[#d4af37]">About Us</h3>
                    <p className="text-sm text-[#b8b8b8]">Learn our story and vision</p>
                  </div>
                  <ArrowRight className="w-5 h-5 text-[#d4af37] group-hover:translate-x-1 transition-transform" />
                </div>
              </Card>
            </Link>

            <Link href="/services">
              <Card className="group bg-gradient-to-r from-[#1a1a1a] to-[#1a2a2a] border-[#d4af37]/30 hover:border-[#d4af37] transition-all duration-300 p-6 cursor-pointer">
                <div className="flex items-center justify-between">
                  <div>
                    <h3 className="text-xl font-light mb-1 text-[#d4af37]">Services</h3>
                    <p className="text-sm text-[#b8b8b8]">Discover what we offer</p>
                  </div>
                  <ArrowRight className="w-5 h-5 text-[#d4af37] group-hover:translate-x-1 transition-transform" />
                </div>
              </Card>
            </Link>

            <Link href="/contact">
              <Card className="group bg-gradient-to-r from-[#1a1a1a] to-[#2a2a1a] border-[#d4af37]/30 hover:border-[#d4af37] transition-all duration-300 p-6 cursor-pointer">
                <div className="flex items-center justify-between">
                  <div>
                    <h3 className="text-xl font-light mb-1 text-[#d4af37]">Contact</h3>
                    <p className="text-sm text-[#b8b8b8]">Get in touch with us</p>
                  </div>
                  <ArrowRight className="w-5 h-5 text-[#d4af37] group-hover:translate-x-1 transition-transform" />
                </div>
              </Card>
            </Link>
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="py-12 border-t border-[#d4af37]/20">
        <div className="container mx-auto px-6 text-center text-[#b8b8b8]">
          <p className="text-sm">&copy; 2025 Nabla-X. Let's build something meaningful.</p>
        </div>
      </footer>

      <style jsx>{`
        @keyframes x-pulse {
          0%, 100% { opacity: 1; transform: scale(1); }
          50% { opacity: 0.7; transform: scale(1.1); }
        }

        @keyframes x-rotate {
          0%, 100% { transform: rotate(0deg); }
          25% { transform: rotate(90deg); }
          50% { transform: rotate(180deg); }
          75% { transform: rotate(270deg); }
        }

        .animate-x-pulse {
          animation: x-pulse 2s ease-in-out infinite;
        }

        .animate-x-rotate {
          animation: x-rotate 8s linear infinite;
          display: inline-block;
          transform-origin: center;
        }

        .logo-intro {
          animation: logoScale 2s ease-in-out forwards;
        }

        @keyframes logoScale {
          0% { transform: scale(0.5); opacity: 0; }
          50% { transform: scale(1.2); opacity: 1; }
          80% { transform: scale(1); }
          100% { transform: scale(1); opacity: 1; }
        }

        .grid-background {
          background-image: 
            linear-gradient(rgba(212, 175, 55, 0.1) 1px, transparent 1px),
            linear-gradient(90deg, rgba(212, 175, 55, 0.1) 1px, transparent 1px);
          background-size: 50px 50px;
        }

        .data-flow-animation {
          position: relative;
          width: 100%;
          height: 100%;
        }

        .data-particle {
          position: absolute;
          width: 4px;
          height: 4px;
          background: #d4af37;
          border-radius: 50%;
          box-shadow: 0 0 10px #d4af37;
          animation: flowData 3s ease-in-out infinite;
          left: 10%;
          top: 50%;
        }

        @keyframes flowData {
          0% { left: 10%; opacity: 0; }
          20% { opacity: 1; }
          80% { opacity: 1; }
          100% { left: 90%; opacity: 0; }
        }
      `}</style>
    </div>
  )
}
