import type React from "react"
import type { Metadata } from "next"
import { Geist, Geist_Mono } from "next/font/google"
import { Analytics } from "@vercel/analytics/next"
import AIChatbot from "@/components/AIChatbot"
import "./globals.css"

const _geist = Geist({ subsets: ["latin"] })
const _geistMono = Geist_Mono({ subsets: ["latin"] })

export const metadata: Metadata = {
  title: {
    default: "Nabla-X | AI Intelligence for Complex Systems",
    template: "%s | Nabla-X",
  },
  description:
    "Applied intelligence for healthcare, finance, and research. We build AI systems that understand how complex systems move — explainable, reliable, and production-ready.",
  keywords: [
    "AI intelligence",
    "complex systems",
    "healthcare AI",
    "financial AI",
    "research AI",
    "explainable AI",
    "AI observability",
    "production AI",
    "QueryMind",
    "DataSentinel",
    "RootSense",
  ],
  authors: [{ name: "Govind Tiwari" }, { name: "Nabla-X" }],
  creator: "Nabla-X",
  publisher: "Nabla-X",
  robots: {
    index: true,
    follow: true,
    googleBot: {
      index: true,
      follow: true,
      "max-video-preview": -1,
      "max-image-preview": "large",
      "max-snippet": -1,
    },
  },
  openGraph: {
    type: "website",
    locale: "en_US",
    url: "https://nabla-x.ai",
    siteName: "Nabla-X",
    title: "Nabla-X | AI Intelligence for Complex Systems",
    description:
      "Applied intelligence for healthcare, finance, and research. We build AI systems that understand how complex systems move — explainable, reliable, and production-ready.",
    images: [
      {
        url: "/og-image.png",
        width: 1200,
        height: 630,
        alt: "Nabla-X - Intelligence for Complex Systems",
      },
    ],
  },
  twitter: {
    card: "summary_large_image",
    title: "Nabla-X | AI Intelligence for Complex Systems",
    description:
      "Applied intelligence for healthcare, finance, and research. We build AI systems that understand how complex systems move.",
    creator: "@nablax_ai",
    images: ["/og-image.png"],
  },
  verification: {
    google: "your-google-site-verification-code",
  },
  alternates: {
    canonical: "https://nabla-x.ai",
  },
  generator: "v0.app",
  icons: {
    icon: [
      {
        url: "/icon-light-32x32.png",
        media: "(prefers-color-scheme: light)",
      },
      {
        url: "/icon-dark-32x32.png",
        media: "(prefers-color-scheme: dark)",
      },
      {
        url: "/icon.svg",
        type: "image/svg+xml",
      },
    ],
    apple: "/apple-icon.png",
  },
}

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode
}>) {
  return (
    <html lang="en">
      <head>
        <script
          type="application/ld+json"
          dangerouslySetInnerHTML={{
            __html: JSON.stringify({
              "@context": "https://schema.org",
              "@type": "Organization",
              name: "Nabla-X",
              url: "https://nabla-x.ai",
              logo: "https://nabla-x.ai/logo.png",
              description:
                "Applied intelligence for healthcare, finance, and research. We build AI systems that understand how complex systems move.",
              founder: {
                "@type": "Person",
                name: "Govind Tiwari",
              },
              sameAs: ["https://www.linkedin.com/company/nablax/", "https://www.instagram.com/nablax.ai/"],
              contactPoint: {
                "@type": "ContactPoint",
                email: "ask.nabla.ai@gmail.com",
                contactType: "Customer Service",
              },
            }),
          }}
        />
      </head>
      <body className={`font-sans antialiased`}>
        {children}
        <AIChatbot />
        <Analytics />
      </body>
    </html>
  )
}
