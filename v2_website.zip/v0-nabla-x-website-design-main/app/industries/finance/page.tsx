"use client"

import Link from "next/link"
import { TrendingUp, Shield, BarChart3, AlertTriangle, DollarSign, PieChart } from "lucide-react"
import { Card } from "@/components/ui/card"

export default function FinancePage() {
  return (
    <div className="min-h-screen bg-gradient-to-br from-[#0a1a0a] via-[#0f2d0f] to-[#0a1a0a] text-[#e8f8e8]">
      {/* Header */}
      <header className="fixed top-0 w-full z-40 border-b border-[#4ade80]/20 bg-[#0a1a0a]/80 backdrop-blur-md">
        <nav className="container mx-auto px-6 py-4 flex items-center justify-between">
          <Link
            href="/"
            className="text-3xl font-light text-[#4ade80] tracking-wider hover:opacity-80 transition-opacity"
          >
            ∇<sup className="text-xl animate-x-ticker inline-block">x</sup>
          </Link>
          <div className="flex items-center gap-8">
            <Link href="/" className="text-sm tracking-wide hover:text-[#4ade80] transition-colors">
              Home
            </Link>
            <Link href="/about" className="text-sm tracking-wide hover:text-[#4ade80] transition-colors">
              About
            </Link>
            <Link href="/services" className="text-sm tracking-wide hover:text-[#4ade80] transition-colors">
              Services
            </Link>
            <Link href="/contact" className="text-sm tracking-wide hover:text-[#4ade80] transition-colors">
              Contact
            </Link>
          </div>
        </nav>
      </header>

      {/* Financial Chart Background */}
      <div className="finance-background">
        {[...Array(6)].map((_, i) => (
          <div key={i} className="chart-bar" style={{ left: `${15 + i * 12}%`, animationDelay: `${i * 0.2}s` }} />
        ))}
        <svg className="market-line" viewBox="0 0 1000 200" preserveAspectRatio="none">
          <path
            d="M0,100 Q250,50 500,100 T1000,100"
            fill="none"
            stroke="rgba(74, 222, 128, 0.2)"
            strokeWidth="2"
            className="line-animate"
          />
        </svg>
      </div>

      {/* Hero Section */}
      <section className="pt-32 pb-20 container mx-auto px-6 relative">
        <div className="max-w-4xl mx-auto text-center">
          <div className="mb-6 flex justify-center">
            <div className="p-4 rounded-full bg-[#4ade80]/10 border border-[#4ade80]/30">
              <TrendingUp className="w-12 h-12 text-[#4ade80]" />
            </div>
          </div>
          <h1 className="text-5xl md:text-6xl font-light mb-6 tracking-tight">
            Finance <span className="text-[#4ade80]">Intelligence</span>
          </h1>
          <p className="text-xl text-[#b8d8b8] leading-relaxed text-pretty">
            Applied intelligence for financial systems where decisions are constrained by risk, regulation, and
            uncertainty
          </p>
        </div>
      </section>

      {/* Use Cases Grid */}
      <section className="py-20 container mx-auto px-6">
        <div className="max-w-6xl mx-auto">
          <h2 className="text-4xl font-light mb-12 text-center text-[#4ade80]">Finance Intelligence Solutions</h2>

          <div className="grid md:grid-cols-2 gap-8">
            <Card className="bg-[#0f2d0f]/50 border-[#4ade80]/30 hover:border-[#4ade80] transition-all p-8 backdrop-blur-sm">
              <div className="mb-4 p-3 rounded-full bg-[#4ade80]/10 w-fit">
                <Shield className="w-6 h-6 text-[#4ade80]" />
              </div>
              <h3 className="text-2xl font-light mb-4 text-[#4ade80]">Credit Risk & Default Modeling</h3>
              <ul className="space-y-2 text-[#b8d8b8]">
                <li>• Probability of default (PD) models</li>
                <li>• Loss given default (LGD) estimation</li>
                <li>• Exposure at default (EAD) modeling</li>
                <li>• Portfolio-level risk aggregation</li>
              </ul>
              <div className="mt-6 text-sm font-light text-[#4ade80]">→ More accurate risk pricing</div>
            </Card>

            <Card className="bg-[#0f2d0f]/50 border-[#4ade80]/30 hover:border-[#4ade80] transition-all p-8 backdrop-blur-sm">
              <div className="mb-4 p-3 rounded-full bg-[#4ade80]/10 w-fit">
                <AlertTriangle className="w-6 h-6 text-[#4ade80]" />
              </div>
              <h3 className="text-2xl font-light mb-4 text-[#4ade80]">Fraud & Anomaly Detection</h3>
              <ul className="space-y-2 text-[#b8d8b8]">
                <li>• Transaction-level anomaly detection</li>
                <li>• Behavioral profiling</li>
                <li>• Real-time fraud scoring</li>
                <li>• Adaptive fraud models</li>
              </ul>
              <div className="mt-6 text-sm font-light text-[#4ade80]">→ Lower fraud losses & faster response</div>
            </Card>

            <Card className="bg-[#0f2d0f]/50 border-[#4ade80]/30 hover:border-[#4ade80] transition-all p-8 backdrop-blur-sm">
              <div className="mb-4 p-3 rounded-full bg-[#4ade80]/10 w-fit">
                <BarChart3 className="w-6 h-6 text-[#4ade80]" />
              </div>
              <h3 className="text-2xl font-light mb-4 text-[#4ade80]">Financial Forecasting</h3>
              <ul className="space-y-2 text-[#b8d8b8]">
                <li>• Cash flow forecasting</li>
                <li>• Revenue & liquidity modeling</li>
                <li>• Scenario-based stress testing</li>
                <li>• Macroeconomic sensitivity analysis</li>
              </ul>
              <div className="mt-6 text-sm font-light text-[#4ade80]">→ Better capital planning</div>
            </Card>

            <Card className="bg-[#0f2d0f]/50 border-[#4ade80]/30 hover:border-[#4ade80] transition-all p-8 backdrop-blur-sm">
              <div className="mb-4 p-3 rounded-full bg-[#4ade80]/10 w-fit">
                <PieChart className="w-6 h-6 text-[#4ade80]" />
              </div>
              <h3 className="text-2xl font-light mb-4 text-[#4ade80]">Portfolio & Exposure Analytics</h3>
              <ul className="space-y-2 text-[#b8d8b8]">
                <li>• Portfolio risk decomposition</li>
                <li>• Correlation & dependency modeling</li>
                <li>• Concentration risk analysis</li>
                <li>• Performance attribution models</li>
              </ul>
              <div className="mt-6 text-sm font-light text-[#4ade80]">→ Clear visibility into risk</div>
            </Card>

            <Card className="bg-[#0f2d0f]/50 border-[#4ade80]/30 hover:border-[#4ade80] transition-all p-8 backdrop-blur-sm">
              <div className="mb-4 p-3 rounded-full bg-[#4ade80]/10 w-fit">
                <Shield className="w-6 h-6 text-[#4ade80]" />
              </div>
              <h3 className="text-2xl font-light mb-4 text-[#4ade80]">AML & Compliance</h3>
              <ul className="space-y-2 text-[#b8d8b8]">
                <li>• Transaction monitoring analytics</li>
                <li>• Risk-based customer segmentation</li>
                <li>• Alert prioritization models</li>
                <li>• Audit-ready reporting pipelines</li>
              </ul>
              <div className="mt-6 text-sm font-light text-[#4ade80]">→ Reduced compliance workload</div>
            </Card>

            <Card className="bg-[#0f2d0f]/50 border-[#4ade80]/30 hover:border-[#4ade80] transition-all p-8 backdrop-blur-sm">
              <div className="mb-4 p-3 rounded-full bg-[#4ade80]/10 w-fit">
                <DollarSign className="w-6 h-6 text-[#4ade80]" />
              </div>
              <h3 className="text-2xl font-light mb-4 text-[#4ade80]">Revenue Leakage Analytics</h3>
              <ul className="space-y-2 text-[#b8d8b8]">
                <li>• Revenue reconciliation models</li>
                <li>• Fee & pricing anomaly detection</li>
                <li>• Underpayment analysis</li>
                <li>• Operational KPI monitoring</li>
              </ul>
              <div className="mt-6 text-sm font-light text-[#4ade80]">→ Improved margins</div>
            </Card>
          </div>
        </div>
      </section>

      {/* Compliance Section */}
      <section className="py-20 bg-[#0a1a0a] border-y border-[#4ade80]/20">
        <div className="container mx-auto px-6">
          <div className="max-w-4xl mx-auto text-center">
            <h2 className="text-4xl font-light mb-8 text-[#4ade80]">Compliance & Governance</h2>
            <p className="text-xl text-[#b8d8b8] mb-8 leading-relaxed">
              Our financial systems are built with governance in mind. We support model documentation, audit trails,
              bias monitoring, and regulatory reporting readiness.
            </p>
            <div className="grid md:grid-cols-4 gap-6 mt-12">
              <div className="text-center">
                <div className="text-3xl font-light text-[#4ade80] mb-2">Explainable</div>
                <p className="text-sm text-[#b8d8b8]">Models</p>
              </div>
              <div className="text-center">
                <div className="text-3xl font-light text-[#4ade80] mb-2">Auditable</div>
                <p className="text-sm text-[#b8d8b8]">Pipelines</p>
              </div>
              <div className="text-center">
                <div className="text-3xl font-light text-[#4ade80] mb-2">Regulatory</div>
                <p className="text-sm text-[#b8d8b8]">Ready</p>
              </div>
              <div className="text-center">
                <div className="text-3xl font-light text-[#4ade80] mb-2">Stress</div>
                <p className="text-sm text-[#b8d8b8]">Tested</p>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="py-12 border-t border-[#4ade80]/20">
        <div className="container mx-auto px-6 text-center text-[#b8d8b8]">
          <p className="text-sm">&copy; 2025 Nabla-X. Let's build something meaningful.</p>
        </div>
      </footer>

      <style jsx>{`
        .finance-background {
          position: fixed;
          top: 0;
          left: 0;
          width: 100%;
          height: 100%;
          pointer-events: none;
          z-index: 0;
          overflow: hidden;
        }

        .chart-bar {
          position: absolute;
          bottom: 20%;
          width: 40px;
          height: 100px;
          background: linear-gradient(to top, #4ade80, transparent);
          opacity: 0.1;
          animation: bar-grow 2s ease-in-out infinite;
        }

        @keyframes bar-grow {
          0%, 100% { transform: scaleY(0.5); opacity: 0.1; }
          50% { transform: scaleY(1.5); opacity: 0.3; }
        }

        .market-line {
          position: absolute;
          bottom: 30%;
          left: 0;
          width: 100%;
          height: 200px;
          opacity: 0.3;
        }

        .line-animate {
          stroke-dasharray: 1000;
          stroke-dashoffset: 1000;
          animation: line-draw 3s ease-in-out infinite;
        }

        @keyframes line-draw {
          to { stroke-dashoffset: 0; }
        }

        @keyframes x-ticker {
          0%, 100% { transform: translateX(0); }
          25% { transform: translateX(-2px); }
          50% { transform: translateX(2px); }
          75% { transform: translateX(-1px); }
        }

        .animate-x-ticker {
          animation: x-ticker 1s ease-in-out infinite;
          display: inline-block;
        }
      `}</style>
    </div>
  )
}
