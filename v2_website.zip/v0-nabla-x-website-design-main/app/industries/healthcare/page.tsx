"use client"

import Link from "next/link"
import { Activity, Heart, Users, TrendingUp, Database, FileText, DollarSign } from "lucide-react"
import { Card } from "@/components/ui/card"

export default function HealthcarePage() {
  return (
    <div className="min-h-screen bg-gradient-to-br from-[#0a1628] via-[#0f2742] to-[#0a1628] text-[#e8f4f8]">
      {/* Header */}
      <header className="fixed top-0 w-full z-40 border-b border-[#4fc3f7]/20 bg-[#0a1628]/80 backdrop-blur-md">
        <nav className="container mx-auto px-6 py-4 flex items-center justify-between">
          <Link
            href="/"
            className="text-3xl font-light text-[#4fc3f7] tracking-wider hover:opacity-80 transition-opacity"
          >
            ∇<sup className="text-xl animate-x-pulse inline-block">x</sup>
          </Link>
          <div className="flex items-center gap-8">
            <Link href="/" className="text-sm tracking-wide hover:text-[#4fc3f7] transition-colors">
              Home
            </Link>
            <Link href="/about" className="text-sm tracking-wide hover:text-[#4fc3f7] transition-colors">
              About
            </Link>
            <Link href="/services" className="text-sm tracking-wide hover:text-[#4fc3f7] transition-colors">
              Services
            </Link>
            <Link href="/contact" className="text-sm tracking-wide hover:text-[#4fc3f7] transition-colors">
              Contact
            </Link>
          </div>
        </nav>
      </header>

      {/* Medical Animation Background */}
      <div className="medical-background">
        <div className="heartbeat-line"></div>
        {[...Array(10)].map((_, i) => (
          <div key={i} className="data-pulse" style={{ animationDelay: `${i * 0.5}s`, left: `${10 + i * 10}%` }} />
        ))}
      </div>

      {/* Hero Section */}
      <section className="pt-32 pb-20 container mx-auto px-6 relative">
        <div className="max-w-4xl mx-auto text-center">
          <div className="mb-6 flex justify-center">
            <div className="p-4 rounded-full bg-[#4fc3f7]/10 border border-[#4fc3f7]/30">
              <Activity className="w-12 h-12 text-[#4fc3f7] animate-pulse-slow" />
            </div>
          </div>
          <h1 className="text-5xl md:text-6xl font-light mb-6 tracking-tight">
            Healthcare <span className="text-[#4fc3f7]">Intelligence</span>
          </h1>
          <p className="text-xl text-[#b8d4e8] leading-relaxed text-pretty">
            Clinically reliable, compliant AI systems that improve patient outcomes and reduce operational costs
          </p>
        </div>
      </section>

      {/* Use Cases Grid */}
      <section className="py-20 container mx-auto px-6">
        <div className="max-w-6xl mx-auto">
          <h2 className="text-4xl font-light mb-12 text-center text-[#4fc3f7]">Healthcare AI Solutions</h2>

          <div className="grid md:grid-cols-2 gap-8">
            <Card className="bg-[#0f2742]/50 border-[#4fc3f7]/30 hover:border-[#4fc3f7] transition-all p-8 backdrop-blur-sm">
              <div className="mb-4 p-3 rounded-full bg-[#4fc3f7]/10 w-fit">
                <Database className="w-6 h-6 text-[#4fc3f7]" />
              </div>
              <h3 className="text-2xl font-light mb-4 text-[#4fc3f7]">Data Engineering & Interoperability</h3>
              <ul className="space-y-2 text-[#b8d4e8]">
                <li>• EHR, LIS, RIS, PACS integration</li>
                <li>• HL7 / FHIR compliant pipelines</li>
                <li>• Real-time clinical data processing</li>
                <li>• Secure data anonymization</li>
              </ul>
              <div className="mt-6 text-sm font-light text-[#4fc3f7]">→ Unified patient data foundation</div>
            </Card>

            <Card className="bg-[#0f2742]/50 border-[#4fc3f7]/30 hover:border-[#4fc3f7] transition-all p-8 backdrop-blur-sm">
              <div className="mb-4 p-3 rounded-full bg-[#4fc3f7]/10 w-fit">
                <TrendingUp className="w-6 h-6 text-[#4fc3f7]" />
              </div>
              <h3 className="text-2xl font-light mb-4 text-[#4fc3f7]">Predictive Analytics</h3>
              <ul className="space-y-2 text-[#b8d4e8]">
                <li>• Patient admission forecasting</li>
                <li>• Bed occupancy prediction</li>
                <li>• Length-of-stay modeling</li>
                <li>• Resource optimization</li>
              </ul>
              <div className="mt-6 text-sm font-light text-[#4fc3f7]">→ Improved patient flow & reduced costs</div>
            </Card>

            <Card className="bg-[#0f2742]/50 border-[#4fc3f7]/30 hover:border-[#4fc3f7] transition-all p-8 backdrop-blur-sm">
              <div className="mb-4 p-3 rounded-full bg-[#4fc3f7]/10 w-fit">
                <Heart className="w-6 h-6 text-[#4fc3f7]" />
              </div>
              <h3 className="text-2xl font-light mb-4 text-[#4fc3f7]">Clinical Decision Support</h3>
              <ul className="space-y-2 text-[#b8d4e8]">
                <li>• Readmission risk prediction</li>
                <li>• Sepsis & deterioration alerts</li>
                <li>• Chronic disease stratification</li>
                <li>• Explainable AI models</li>
              </ul>
              <div className="mt-6 text-sm font-light text-[#4fc3f7]">→ Earlier interventions & better outcomes</div>
            </Card>

            <Card className="bg-[#0f2742]/50 border-[#4fc3f7]/30 hover:border-[#4fc3f7] transition-all p-8 backdrop-blur-sm">
              <div className="mb-4 p-3 rounded-full bg-[#4fc3f7]/10 w-fit">
                <FileText className="w-6 h-6 text-[#4fc3f7]" />
              </div>
              <h3 className="text-2xl font-light mb-4 text-[#4fc3f7]">Medical NLP</h3>
              <ul className="space-y-2 text-[#b8d4e8]">
                <li>• Clinical notes processing</li>
                <li>• Automated ICD-10 / CPT coding</li>
                <li>• Medical report classification</li>
                <li>• Prior authorization automation</li>
              </ul>
              <div className="mt-6 text-sm font-light text-[#4fc3f7]">→ Reduced administrative workload</div>
            </Card>

            <Card className="bg-[#0f2742]/50 border-[#4fc3f7]/30 hover:border-[#4fc3f7] transition-all p-8 backdrop-blur-sm">
              <div className="mb-4 p-3 rounded-full bg-[#4fc3f7]/10 w-fit">
                <DollarSign className="w-6 h-6 text-[#4fc3f7]" />
              </div>
              <h3 className="text-2xl font-light mb-4 text-[#4fc3f7]">Revenue Cycle Analytics</h3>
              <ul className="space-y-2 text-[#b8d4e8]">
                <li>• Claim denial prediction</li>
                <li>• Fraud & anomaly detection</li>
                <li>• Underpayment identification</li>
                <li>• Revenue cycle monitoring</li>
              </ul>
              <div className="mt-6 text-sm font-light text-[#4fc3f7]">→ Improved cash flow & margins</div>
            </Card>

            <Card className="bg-[#0f2742]/50 border-[#4fc3f7]/30 hover:border-[#4fc3f7] transition-all p-8 backdrop-blur-sm">
              <div className="mb-4 p-3 rounded-full bg-[#4fc3f7]/10 w-fit">
                <Users className="w-6 h-6 text-[#4fc3f7]" />
              </div>
              <h3 className="text-2xl font-light mb-4 text-[#4fc3f7]">Population Health</h3>
              <ul className="space-y-2 text-[#b8d4e8]">
                <li>• Population risk segmentation</li>
                <li>• Disease progression prediction</li>
                <li>• Preventive care targeting</li>
                <li>• Value-based care analytics</li>
              </ul>
              <div className="mt-6 text-sm font-light text-[#4fc3f7]">→ Better long-term outcomes</div>
            </Card>
          </div>
        </div>
      </section>

      {/* Compliance Section */}
      <section className="py-20 bg-[#0a1628] border-y border-[#4fc3f7]/20">
        <div className="container mx-auto px-6">
          <div className="max-w-4xl mx-auto text-center">
            <h2 className="text-4xl font-light mb-8 text-[#4fc3f7]">Compliance & Privacy</h2>
            <p className="text-xl text-[#b8d4e8] mb-8 leading-relaxed">
              Healthcare AI must be safe, transparent, and compliant. We ensure HIPAA-compliant data handling, secure
              access controls, and explainable AI models.
            </p>
            <div className="grid md:grid-cols-4 gap-6 mt-12">
              <div className="text-center">
                <div className="text-3xl font-light text-[#4fc3f7] mb-2">HIPAA</div>
                <p className="text-sm text-[#b8d4e8]">Compliant</p>
              </div>
              <div className="text-center">
                <div className="text-3xl font-light text-[#4fc3f7] mb-2">Audit</div>
                <p className="text-sm text-[#b8d4e8]">Trails</p>
              </div>
              <div className="text-center">
                <div className="text-3xl font-light text-[#4fc3f7] mb-2">Explainable</div>
                <p className="text-sm text-[#b8d4e8]">AI</p>
              </div>
              <div className="text-center">
                <div className="text-3xl font-light text-[#4fc3f7] mb-2">Secure</div>
                <p className="text-sm text-[#b8d4e8]">by Design</p>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="py-12 border-t border-[#4fc3f7]/20">
        <div className="container mx-auto px-6 text-center text-[#b8d4e8]">
          <p className="text-sm">&copy; 2025 Nabla-X. Let's build something meaningful.</p>
        </div>
      </footer>

      <style jsx>{`
        .medical-background {
          position: fixed;
          top: 0;
          left: 0;
          width: 100%;
          height: 100%;
          pointer-events: none;
          z-index: 0;
          overflow: hidden;
        }

        .heartbeat-line {
          position: absolute;
          top: 50%;
          left: 0;
          width: 100%;
          height: 2px;
          background: linear-gradient(90deg, transparent 0%, #4fc3f7 50%, transparent 100%);
          opacity: 0.1;
          animation: heartbeat 2s ease-in-out infinite;
        }

        @keyframes heartbeat {
          0%, 100% { transform: scaleX(0.8); opacity: 0.1; }
          50% { transform: scaleX(1.2); opacity: 0.3; }
        }

        .data-pulse {
          position: absolute;
          width: 8px;
          height: 8px;
          background: #4fc3f7;
          border-radius: 50%;
          top: 50%;
          animation: pulse-move 3s ease-in-out infinite;
          box-shadow: 0 0 10px #4fc3f7;
        }

        @keyframes pulse-move {
          0%, 100% { transform: translateY(0); opacity: 0.3; }
          50% { transform: translateY(-100px); opacity: 1; }
        }

        .animate-pulse-slow {
          animation: pulse 3s cubic-bezier(0.4, 0, 0.6, 1) infinite;
        }

        @keyframes pulse {
          0%, 100% { opacity: 1; }
          50% { opacity: 0.5; }
        }
      `}</style>
    </div>
  )
}
