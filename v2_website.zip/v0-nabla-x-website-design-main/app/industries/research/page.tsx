"use client"

import Link from "next/link"
import { Beaker, Network, Database, FileCode, GitBranch, FlaskConical } from "lucide-react"
import { Card } from "@/components/ui/card"

export default function ResearchPage() {
  return (
    <div className="min-h-screen bg-gradient-to-br from-[#1a0a28] via-[#2d1242] to-[#1a0a28] text-[#f0e8f8]">
      {/* Header */}
      <header className="fixed top-0 w-full z-40 border-b border-[#a855f7]/20 bg-[#1a0a28]/80 backdrop-blur-md">
        <nav className="container mx-auto px-6 py-4 flex items-center justify-between">
          <Link
            href="/"
            className="text-3xl font-light text-[#a855f7] tracking-wider hover:opacity-80 transition-opacity"
          >
            ∇<sup className="text-xl animate-x-experiment inline-block">x</sup>
          </Link>
          <div className="flex items-center gap-8">
            <Link href="/" className="text-sm tracking-wide hover:text-[#a855f7] transition-colors">
              Home
            </Link>
            <Link href="/about" className="text-sm tracking-wide hover:text-[#a855f7] transition-colors">
              About
            </Link>
            <Link href="/services" className="text-sm tracking-wide hover:text-[#a855f7] transition-colors">
              Services
            </Link>
            <Link href="/contact" className="text-sm tracking-wide hover:text-[#a855f7] transition-colors">
              Contact
            </Link>
          </div>
        </nav>
      </header>

      {/* Research Animation Background */}
      <div className="research-background">
        {[...Array(15)].map((_, i) => (
          <div
            key={i}
            className="molecule-dot"
            style={{
              left: `${Math.random() * 100}%`,
              top: `${Math.random() * 100}%`,
              animationDelay: `${Math.random() * 3}s`,
              animationDuration: `${3 + Math.random() * 2}s`,
            }}
          />
        ))}
        <svg className="connection-lines" width="100%" height="100%">
          <line x1="20%" y1="30%" x2="40%" y2="50%" className="research-line" />
          <line x1="40%" y1="50%" x2="60%" y2="40%" className="research-line" />
          <line x1="60%" y1="40%" x2="80%" y2="60%" className="research-line" />
        </svg>
      </div>

      {/* Hero Section */}
      <section className="pt-32 pb-20 container mx-auto px-6 relative">
        <div className="max-w-4xl mx-auto text-center">
          <div className="mb-6 flex justify-center">
            <div className="p-4 rounded-full bg-[#a855f7]/10 border border-[#a855f7]/30">
              <Beaker className="w-12 h-12 text-[#a855f7] animate-pulse" />
            </div>
          </div>
          <h1 className="text-5xl md:text-6xl font-light mb-6 tracking-tight">
            Research <span className="text-[#a855f7]">Intelligence</span>
          </h1>
          <p className="text-xl text-[#d8c8e8] leading-relaxed text-pretty">
            Computational and analytical systems that support rigorous research, large-scale experimentation, and
            reproducible discovery
          </p>
        </div>
      </section>

      {/* Solutions Grid */}
      <section className="py-20 container mx-auto px-6">
        <div className="max-w-6xl mx-auto">
          <h2 className="text-4xl font-light mb-12 text-center text-[#a855f7]">Research & Experimental Intelligence</h2>

          <div className="grid md:grid-cols-2 gap-8">
            <Card className="bg-[#2d1242]/50 border-[#a855f7]/30 hover:border-[#a855f7] transition-all p-8 backdrop-blur-sm">
              <div className="mb-4 p-3 rounded-full bg-[#a855f7]/10 w-fit">
                <Database className="w-6 h-6 text-[#a855f7]" />
              </div>
              <h3 className="text-2xl font-light mb-4 text-[#a855f7]">Experimental Data Engineering</h3>
              <ul className="space-y-2 text-[#d8c8e8]">
                <li>• Research data pipelines</li>
                <li>• Versioned datasets & metadata tracking</li>
                <li>• Schema evolution handling</li>
                <li>• Experimental data validation</li>
              </ul>
              <div className="mt-6 text-sm font-light text-[#a855f7]">→ Reliable, reproducible datasets</div>
            </Card>

            <Card className="bg-[#2d1242]/50 border-[#a855f7]/30 hover:border-[#a855f7] transition-all p-8 backdrop-blur-sm">
              <div className="mb-4 p-3 rounded-full bg-[#a855f7]/10 w-fit">
                <FlaskConical className="w-6 h-6 text-[#a855f7]" />
              </div>
              <h3 className="text-2xl font-light mb-4 text-[#a855f7]">Experiment Design & Optimization</h3>
              <ul className="space-y-2 text-[#d8c8e8]">
                <li>• Design of experiments (DOE) frameworks</li>
                <li>• Parameter space exploration</li>
                <li>• Bayesian optimization</li>
                <li>• Sensitivity analysis</li>
              </ul>
              <div className="mt-6 text-sm font-light text-[#a855f7]">→ Higher information gain</div>
            </Card>

            <Card className="bg-[#2d1242]/50 border-[#a855f7]/30 hover:border-[#a855f7] transition-all p-8 backdrop-blur-sm">
              <div className="mb-4 p-3 rounded-full bg-[#a855f7]/10 w-fit">
                <GitBranch className="w-6 h-6 text-[#a855f7]" />
              </div>
              <h3 className="text-2xl font-light mb-4 text-[#a855f7]">Reproducible Modeling</h3>
              <ul className="space-y-2 text-[#d8c8e8]">
                <li>• Reproducible modeling pipelines</li>
                <li>• Simulation frameworks</li>
                <li>• Version-controlled development</li>
                <li>• Deterministic & stochastic modeling</li>
              </ul>
              <div className="mt-6 text-sm font-light text-[#a855f7]">→ Transparent model evolution</div>
            </Card>

            <Card className="bg-[#2d1242]/50 border-[#a855f7]/30 hover:border-[#a855f7] transition-all p-8 backdrop-blur-sm">
              <div className="mb-4 p-3 rounded-full bg-[#a855f7]/10 w-fit">
                <Network className="w-6 h-6 text-[#a855f7]" />
              </div>
              <h3 className="text-2xl font-light mb-4 text-[#a855f7]">Statistical Computing</h3>
              <ul className="space-y-2 text-[#d8c8e8]">
                <li>• Statistical modeling & inference</li>
                <li>• Time-series analysis</li>
                <li>• Multivariate analysis</li>
                <li>• Uncertainty quantification</li>
              </ul>
              <div className="mt-6 text-sm font-light text-[#a855f7]">→ Defensible results</div>
            </Card>

            <Card className="bg-[#2d1242]/50 border-[#a855f7]/30 hover:border-[#a855f7] transition-all p-8 backdrop-blur-sm">
              <div className="mb-4 p-3 rounded-full bg-[#a855f7]/10 w-fit">
                <FileCode className="w-6 h-6 text-[#a855f7]" />
              </div>
              <h3 className="text-2xl font-light mb-4 text-[#a855f7]">Research NLP</h3>
              <ul className="space-y-2 text-[#d8c8e8]">
                <li>• NLP for research papers</li>
                <li>• Automated literature review</li>
                <li>• Knowledge graph construction</li>
                <li>• Semantic search across corpora</li>
              </ul>
              <div className="mt-6 text-sm font-light text-[#a855f7]">→ Faster discovery</div>
            </Card>

            <Card className="bg-[#2d1242]/50 border-[#a855f7]/30 hover:border-[#a855f7] transition-all p-8 backdrop-blur-sm">
              <div className="mb-4 p-3 rounded-full bg-[#a855f7]/10 w-fit">
                <FlaskConical className="w-6 h-6 text-[#a855f7]" />
              </div>
              <h3 className="text-2xl font-light mb-4 text-[#a855f7]">Model Validation</h3>
              <ul className="space-y-2 text-[#d8c8e8]">
                <li>• Standardized evaluation pipelines</li>
                <li>• Cross-validation & robustness testing</li>
                <li>• Benchmarking frameworks</li>
                <li>• Bias assessment</li>
              </ul>
              <div className="mt-6 text-sm font-light text-[#a855f7]">→ Comparable results</div>
            </Card>
          </div>
        </div>
      </section>

      {/* Approach Section */}
      <section className="py-20 bg-[#1a0a28] border-y border-[#a855f7]/20">
        <div className="container mx-auto px-6">
          <div className="max-w-4xl mx-auto text-center">
            <h2 className="text-4xl font-light mb-8 text-[#a855f7]">Our Research Approach</h2>
            <p className="text-xl text-[#d8c8e8] mb-8 leading-relaxed">
              We prioritize correctness and clarity over speed. Our systems support both exploration and production at
              the edge of uncertainty.
            </p>
            <div className="grid md:grid-cols-3 gap-6 mt-12">
              <div className="text-center">
                <div className="text-3xl font-light text-[#a855f7] mb-2">Reproducible</div>
                <p className="text-sm text-[#d8c8e8]">Systems</p>
              </div>
              <div className="text-center">
                <div className="text-3xl font-light text-[#a855f7] mb-2">Version</div>
                <p className="text-sm text-[#d8c8e8]">Controlled</p>
              </div>
              <div className="text-center">
                <div className="text-3xl font-light text-[#a855f7] mb-2">Validated</div>
                <p className="text-sm text-[#d8c8e8]">Models</p>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="py-12 border-t border-[#a855f7]/20">
        <div className="container mx-auto px-6 text-center text-[#d8c8e8]">
          <p className="text-sm">&copy; 2025 Nabla-X. Let's build something meaningful.</p>
        </div>
      </footer>

      <style jsx>{`
        .research-background {
          position: fixed;
          top: 0;
          left: 0;
          width: 100%;
          height: 100%;
          pointer-events: none;
          z-index: 0;
          overflow: hidden;
        }

        .molecule-dot {
          position: absolute;
          width: 6px;
          height: 6px;
          background: #a855f7;
          border-radius: 50%;
          animation: molecule-float 4s ease-in-out infinite;
          box-shadow: 0 0 8px #a855f7;
          opacity: 0.4;
        }

        @keyframes molecule-float {
          0%, 100% { transform: translate(0, 0); }
          25% { transform: translate(20px, -20px); }
          50% { transform: translate(-10px, 10px); }
          75% { transform: translate(10px, 20px); }
        }

        .connection-lines {
          position: absolute;
          top: 0;
          left: 0;
          opacity: 0.1;
        }

        .research-line {
          stroke: #a855f7;
          stroke-width: 2;
          stroke-dasharray: 5, 5;
          animation: dash 2s linear infinite;
        }

        @keyframes dash {
          to { stroke-dashoffset: -20; }
        }

        @keyframes x-experiment {
          0%, 100% { transform: scale(1) rotate(0deg); }
          50% { transform: scale(1.2) rotate(180deg); }
        }

        .animate-x-experiment {
          animation: x-experiment 6s ease-in-out infinite;
          display: inline-block;
        }
      `}</style>
    </div>
  )
}
