"use client"

import type React from "react"
import { useState } from "react"
import Link from "next/link"
import { Mail, Phone, Linkedin, Instagram, Send, Building2, User, DollarSign, Calendar } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Card } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { trackEvent, AnalyticsEvents } from "@/lib/analytics"

export default function ContactPage() {
  const [formData, setFormData] = useState({
    name: "",
    email: "",
    company: "",
    role: "",
    budget: "",
    problem: "",
    preferredTime: "",
  })
  const [isSubmitting, setIsSubmitting] = useState(false)
  const [submitted, setSubmitted] = useState(false)
  const [formStarted, setFormStarted] = useState(false)

  const handleInputChange = (field: string, value: string) => {
    if (!formStarted) {
      setFormStarted(true)
      trackEvent(AnalyticsEvents.CONTACT_FORM_STARTED)
    }
    setFormData({ ...formData, [field]: value })
  }

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    setIsSubmitting(true)

    trackEvent(AnalyticsEvents.CONTACT_FORM_SUBMITTED, {
      role: formData.role,
      budget: formData.budget,
      hasPreferredTime: !!formData.preferredTime,
    })

    await new Promise((resolve) => setTimeout(resolve, 1500))
    setIsSubmitting(false)
    setSubmitted(true)
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-[#0a0a0a] via-[#1a1a1a] to-[#0f0f0f] text-[#e8e8e8]">
      {/* Header */}
      <header className="fixed top-0 w-full z-40 border-b border-[#d4af37]/20 bg-[#0a0a0a]/80 backdrop-blur-md">
        <nav className="container mx-auto px-6 py-4 flex items-center justify-between">
          <Link href="/" className="flex items-center gap-2 md:gap-3 hover:opacity-80 transition-opacity group">
            <span className="text-2xl md:text-3xl font-light text-[#d4af37] tracking-wider">
              ∇<sup className="text-base md:text-xl animate-x-rotate inline-block">x</sup>
            </span>
            <span className="text-lg md:text-2xl font-light tracking-wide">
              <span className="text-[#e8e8e8]">Nabla-</span>
              <span className="bg-gradient-to-r from-[#d4af37] via-[#f4cf47] to-[#d4af37] bg-clip-text text-transparent font-medium">
                X
              </span>
            </span>
          </Link>
          <div className="hidden md:flex items-center gap-8">
            <Link href="/about" className="text-sm tracking-wide hover:text-[#d4af37] transition-colors">
              About
            </Link>
            <Link href="/services" className="text-sm tracking-wide hover:text-[#d4af37] transition-colors">
              Services
            </Link>
            <Link href="/contact" className="text-sm tracking-wide text-[#d4af37]">
              Contact
            </Link>
          </div>
        </nav>
      </header>

      {/* Main Content */}
      <section className="pt-32 pb-20 container mx-auto px-6 relative">
        <div className="max-w-5xl mx-auto">
          {/* Hero */}
          <div className="text-center mb-16">
            <h1 className="text-5xl md:text-6xl font-light mb-6 tracking-tight text-balance">
              Let's <span className="text-[#d4af37]">Connect</span>
            </h1>
            <p className="text-xl text-[#b8b8b8] leading-relaxed max-w-2xl mx-auto">
              We're here to help transform your data into reliable intelligence
            </p>
          </div>

          <div className="grid md:grid-cols-2 gap-8 mb-16">
            <Card className="bg-[#1a1a1a]/50 border-[#d4af37]/30 p-8 backdrop-blur-sm">
              {!submitted ? (
                <form onSubmit={handleSubmit} className="space-y-6">
                  <div>
                    <label className="block text-sm mb-2 text-[#b8b8b8] flex items-center gap-2">
                      <User className="w-4 h-4 text-[#d4af37]" />
                      Name *
                    </label>
                    <Input
                      required
                      className="bg-[#0a0a0a]/50 border-[#d4af37]/30 text-[#e8e8e8] focus:border-[#d4af37]"
                      placeholder="Your name"
                      value={formData.name}
                      onChange={(e) => handleInputChange("name", e.target.value)}
                    />
                  </div>
                  <div>
                    <label className="block text-sm mb-2 text-[#b8b8b8] flex items-center gap-2">
                      <Mail className="w-4 h-4 text-[#d4af37]" />
                      Email *
                    </label>
                    <Input
                      required
                      type="email"
                      className="bg-[#0a0a0a]/50 border-[#d4af37]/30 text-[#e8e8e8] focus:border-[#d4af37]"
                      placeholder="your@email.com"
                      value={formData.email}
                      onChange={(e) => handleInputChange("email", e.target.value)}
                    />
                  </div>
                  <div>
                    <label className="block text-sm mb-2 text-[#b8b8b8] flex items-center gap-2">
                      <Building2 className="w-4 h-4 text-[#d4af37]" />
                      Company *
                    </label>
                    <Input
                      required
                      className="bg-[#0a0a0a]/50 border-[#d4af37]/30 text-[#e8e8e8] focus:border-[#d4af37]"
                      placeholder="Your company"
                      value={formData.company}
                      onChange={(e) => handleInputChange("company", e.target.value)}
                    />
                  </div>
                  <div>
                    <label className="block text-sm mb-2 text-[#b8b8b8]">Role *</label>
                    <select
                      required
                      className="w-full bg-[#0a0a0a]/50 border border-[#d4af37]/30 rounded-lg px-4 py-3 text-[#e8e8e8] focus:border-[#d4af37] focus:outline-none"
                      value={formData.role}
                      onChange={(e) => handleInputChange("role", e.target.value)}
                    >
                      <option value="">Select your role</option>
                      <option value="cto">CTO / VP Engineering</option>
                      <option value="data-lead">Head of Data / Analytics</option>
                      <option value="pm">Product Manager</option>
                      <option value="engineer">Data Engineer</option>
                      <option value="other">Other</option>
                    </select>
                  </div>
                  <div>
                    <label className="block text-sm mb-2 text-[#b8b8b8] flex items-center gap-2">
                      <DollarSign className="w-4 h-4 text-[#d4af37]" />
                      Budget Band
                    </label>
                    <select
                      className="w-full bg-[#0a0a0a]/50 border border-[#d4af37]/30 rounded-lg px-4 py-3 text-[#e8e8e8] focus:border-[#d4af37] focus:outline-none"
                      value={formData.budget}
                      onChange={(e) => handleInputChange("budget", e.target.value)}
                    >
                      <option value="">Select budget range</option>
                      <option value="under-50k">Under $50k</option>
                      <option value="50k-150k">$50k - $150k</option>
                      <option value="150k-500k">$150k - $500k</option>
                      <option value="over-500k">Over $500k</option>
                    </select>
                  </div>
                  <div>
                    <label className="block text-sm mb-2 text-[#b8b8b8]">Main Problem / Challenge *</label>
                    <textarea
                      required
                      className="w-full min-h-32 bg-[#0a0a0a]/50 border border-[#d4af37]/30 rounded-lg px-4 py-3 text-[#e8e8e8] focus:border-[#d4af37] focus:outline-none resize-none"
                      placeholder="Tell us about your main data or AI challenge..."
                      value={formData.problem}
                      onChange={(e) => handleInputChange("problem", e.target.value)}
                    />
                  </div>
                  <div>
                    <label className="block text-sm mb-2 text-[#b8b8b8] flex items-center gap-2">
                      <Calendar className="w-4 h-4 text-[#d4af37]" />
                      Preferred Call Time
                    </label>
                    <Input
                      className="bg-[#0a0a0a]/50 border-[#d4af37]/30 text-[#e8e8e8] focus:border-[#d4af37]"
                      placeholder="e.g., Weekdays 2-4pm EST"
                      value={formData.preferredTime}
                      onChange={(e) => handleInputChange("preferredTime", e.target.value)}
                    />
                  </div>
                  <Button
                    type="submit"
                    disabled={isSubmitting}
                    className="w-full bg-[#d4af37] text-[#0a0a0a] hover:bg-[#c4a037] py-6 flex items-center justify-center gap-2"
                  >
                    {isSubmitting ? (
                      <div className="w-5 h-5 border-2 border-[#0a0a0a] border-t-transparent rounded-full animate-spin" />
                    ) : (
                      <>
                        <Send className="w-4 h-4" />
                        Send Message
                      </>
                    )}
                  </Button>
                  <p className="text-xs text-[#8a8a8a] text-center">
                    We respect your privacy. Your information will only be used to contact you about your inquiry.
                  </p>
                </form>
              ) : (
                <div className="text-center py-12">
                  <div className="w-16 h-16 bg-[#d4af37]/20 rounded-full flex items-center justify-center mx-auto mb-4">
                    <svg className="w-8 h-8 text-[#d4af37]" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7" />
                    </svg>
                  </div>
                  <h3 className="text-2xl font-light mb-2 text-[#d4af37]">Message Sent</h3>
                  <p className="text-[#b8b8b8]">We'll get back to you within 24 hours.</p>
                </div>
              )}
            </Card>

            {/* Contact Information */}
            <div className="space-y-6">
              {/* Founding Note */}
              <Card className="bg-[#1a1a1a]/50 border-[#d4af37]/30 p-8 backdrop-blur-sm">
                <p className="text-[#b8b8b8] italic leading-relaxed text-balance">
                  Founded by Govind Tiwari — driven by a curiosity for the unknowns within known systems.
                </p>
              </Card>

              {/* Direct Contact */}
              <Card className="bg-[#1a1a1a]/50 border-[#d4af37]/30 p-8 backdrop-blur-sm">
                <h3 className="text-lg font-light mb-6 text-[#d4af37]">Govind Tiwari</h3>
                <div className="space-y-4">
                  <a
                    href="tel:+919587746703"
                    className="flex items-center gap-3 text-[#b8b8b8] hover:text-[#d4af37] transition-colors group"
                  >
                    <div className="p-2 rounded-lg bg-[#d4af37]/10 group-hover:bg-[#d4af37]/20 transition-colors">
                      <Phone className="w-4 h-4 text-[#d4af37]" />
                    </div>
                    <span>+91 95877 46703</span>
                  </a>
                  <a
                    href="mailto:govindtiwari23@gmail.com"
                    className="flex items-center gap-3 text-[#b8b8b8] hover:text-[#d4af37] transition-colors group"
                  >
                    <div className="p-2 rounded-lg bg-[#d4af37]/10 group-hover:bg-[#d4af37]/20 transition-colors">
                      <Mail className="w-4 h-4 text-[#d4af37]" />
                    </div>
                    <span>govindtiwari@nablax.in</span>
                  </a>
                </div>
              </Card>

              {/* General Inquiries */}
              <Card className="bg-[#1a1a1a]/50 border-[#d4af37]/30 p-8 backdrop-blur-sm">
                <h3 className="text-lg font-light mb-6 text-[#d4af37]">General Inquiries</h3>
                <a
                  href="mailto:ask.nabla.ai@gmail.com"
                  className="flex items-center gap-3 text-[#b8b8b8] hover:text-[#d4af37] transition-colors group"
                >
                  <div className="p-2 rounded-lg bg-[#d4af37]/10 group-hover:bg-[#d4af37]/20 transition-colors">
                    <Mail className="w-4 h-4 text-[#d4af37]" />
                  </div>
                  <span>ask@nablax.in</span>
                </a>
              </Card>

              <Card className="bg-[#1a1a1a]/50 border-[#d4af37]/30 p-6 backdrop-blur-sm">
                <h3 className="text-sm font-medium mb-2 text-[#d4af37]">Schedule a Call</h3>
                <p className="text-sm text-[#8a8a8a] mb-4">Prefer to book time directly? Use our calendar link.</p>
                <Button
                  variant="outline"
                  className="w-full border-[#d4af37] text-[#d4af37] hover:bg-[#d4af37]/10 bg-transparent"
                  onClick={() => {
                    trackEvent(AnalyticsEvents.CONTACT_CALENDAR_CLICKED)
                    window.open("https://calendly.com", "_blank")
                  }}
                >
                  <Calendar className="w-4 h-4 mr-2" />
                  Book a Time
                </Button>
              </Card>
            </div>
          </div>

          {/* Social Links */}
          <div className="flex justify-center gap-6">
            <a
              href="https://www.linkedin.com/company/nablax/"
              target="_blank"
              rel="noopener noreferrer"
              className="p-4 rounded-full bg-[#1a1a1a]/50 border border-[#d4af37]/30 hover:border-[#d4af37] hover:bg-[#d4af37]/10 transition-all group"
              onClick={() => trackEvent(AnalyticsEvents.SOCIAL_LINKEDIN_CLICKED, { source: "contact_page" })}
            >
              <Linkedin className="w-5 h-5 text-[#b8b8b8] group-hover:text-[#d4af37]" />
            </a>
            <a
              href="https://www.instagram.com/nablax.ai/"
              target="_blank"
              rel="noopener noreferrer"
              className="p-4 rounded-full bg-[#1a1a1a]/50 border border-[#d4af37]/30 hover:border-[#d4af37] hover:bg-[#d4af37]/10 transition-all group"
              onClick={() => trackEvent(AnalyticsEvents.SOCIAL_INSTAGRAM_CLICKED, { source: "contact_page" })}
            >
              <Instagram className="w-5 h-5 text-[#b8b8b8] group-hover:text-[#d4af37]" />
            </a>
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="py-12 border-t border-[#d4af37]/20">
        <div className="container mx-auto px-6 text-center text-[#b8b8b8]">
          <p className="text-sm">&copy; 2025 Nabla-X. Let's build something meaningful.</p>
        </div>
      </footer>

      <style jsx>{`
        @keyframes x-rotate {
          0%, 100% { transform: rotate(0deg); }
          25% { transform: rotate(90deg); }
          50% { transform: rotate(180deg); }
          75% { transform: rotate(270deg); }
        }

        .animate-x-rotate {
          animation: x-rotate 8s linear infinite;
          display: inline-block;
          transform-origin: center;
        }
      `}</style>
    </div>
  )
}
