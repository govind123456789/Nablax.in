import type { Metadata } from "next"

export const metadata: Metadata = {
  title: "Contact Us | Get in Touch with Nabla-X",
  description:
    "Ready to transform your data into reliable intelligence? Contact Nabla-X to discuss your AI and data challenges. Founded by Govind Tiwari.",
  keywords: ["contact Nabla-X", "AI consultation", "enterprise AI inquiry", "data intelligence", "AI demo request"],
  openGraph: {
    title: "Contact Us | Get in Touch with Nabla-X",
    description:
      "Ready to transform your data into reliable intelligence? Contact Nabla-X to discuss your AI and data challenges.",
    url: "https://nabla-x.ai/contact",
    siteName: "Nabla-X",
    type: "website",
    images: [
      {
        url: "/og-image.png",
        width: 1200,
        height: 630,
        alt: "Contact Nabla-X",
      },
    ],
  },
  twitter: {
    card: "summary_large_image",
    title: "Contact Us | Get in Touch with Nabla-X",
    description:
      "Ready to transform your data into reliable intelligence? Contact Nabla-X to discuss your AI and data challenges.",
    images: ["/og-image.png"],
  },
}
