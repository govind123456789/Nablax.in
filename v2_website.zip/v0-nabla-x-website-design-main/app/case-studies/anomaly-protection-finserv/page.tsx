"use client"

import Link from "next/link"
import { Card } from "@/components/ui/card"
import { motion } from "framer-motion"
import { ShieldCheck, Database, Clock, CheckCircle2, ArrowRight, AlertTriangle } from "lucide-react"

export default function AnomalyProtectionFinserv() {
  return (
    <div className="min-h-screen bg-black text-white">
      <header className="border-b border-white/10 bg-black/95 backdrop-blur-xl sticky top-0 z-50">
        <div className="container mx-auto px-6 py-5 flex items-center justify-between">
          <Link href="/" className="text-[#d4af37] text-2xl font-semibold tracking-tight">
            Nabla-X
          </Link>
          <nav className="hidden md:flex gap-8 text-sm text-gray-400">
            <Link href="/services" className="hover:text-white transition">
              Services
            </Link>
            <Link href="/case-studies" className="text-white font-medium">
              Case Studies
            </Link>
            <Link href="/contact" className="hover:text-white transition">
              Contact
            </Link>
          </nav>
        </div>
      </header>

      <section className="pt-32 pb-20">
        <div className="container mx-auto px-6 max-w-6xl">
          <div className="flex items-center gap-3 mb-8">
            <span className="px-3 py-1.5 bg-emerald-500/10 border border-emerald-500/20 rounded-full text-emerald-400 text-xs font-medium">
              Financial Services
            </span>
            <span className="text-gray-500">·</span>
            <span className="text-gray-400 text-sm">7 minute read</span>
          </div>

          <h1 className="text-5xl md:text-7xl font-bold leading-tight mb-8 text-balance">
            Preventing silent data failures
            <span className="text-emerald-400"> before</span> financial impact
          </h1>

          <p className="text-xl text-gray-400 max-w-3xl leading-relaxed mb-12">
            A Tier-1 global investment bank deployed DataSentinel across market data, reference feeds, and settlement
            pipelines to prevent silent failures before regulatory or financial impact.
          </p>

          <div className="flex gap-4">
            <Link
              href="/contact"
              className="bg-emerald-500 text-black px-8 py-4 rounded-lg font-semibold hover:bg-emerald-400 transition inline-flex items-center gap-2"
            >
              Discuss Your Environment
              <ArrowRight className="w-5 h-5" />
            </Link>
          </div>
        </div>
      </section>

      <section className="py-20 border-y border-white/10">
        <div className="container mx-auto px-6 max-w-6xl">
          <div className="grid md:grid-cols-3 gap-12">
            <div>
              <div className="text-6xl font-bold text-emerald-400 mb-3">$0</div>
              <div className="text-gray-400 text-lg">Loss from data incidents post-deployment</div>
            </div>
            <div>
              <div className="text-6xl font-bold text-emerald-400 mb-3">8 weeks</div>
              <div className="text-gray-400 text-lg">From discovery to production rollout</div>
            </div>
            <div>
              <div className="text-6xl font-bold text-emerald-400 mb-3">100%</div>
              <div className="text-gray-400 text-lg">Audit-replayable decision trails</div>
            </div>
          </div>
        </div>
      </section>

      {/* ARCHITECTURE */}
      <section className="pt-24 pb-16 border-b border-white/5">
        <div className="container mx-auto px-6 max-w-6xl grid lg:grid-cols-12 gap-12 items-center">
          <div className="lg:col-span-7">
            <div className="text-xs uppercase tracking-widest text-[#2dd4bf] mb-4">Case Study · Financial Services</div>

            <h1 className="text-4xl md:text-5xl font-light leading-tight mb-5">
              Data Trust & Anomaly Protection
              <br />
              <span className="text-[#2dd4bf]">for Regulated Financial Systems</span>
            </h1>

            <p className="text-gray-300 max-w-3xl mb-7">
              A Tier-1 global investment bank deployed continuous trust controls across market data, reference feeds,
              and settlement pipelines to prevent silent data failures before financial or regulatory impact.
            </p>

            <div className="flex gap-4">
              <Link href="/contact" className="bg-[#2dd4bf] text-black px-6 py-3 rounded-md font-medium">
                Discuss Your Environment
              </Link>
              <Link href="/services" className="border border-white/10 px-6 py-3 rounded-md text-gray-300">
                Engagement Models
              </Link>
            </div>
          </div>

          {/* ARCHITECTURE */}
          <div className="lg:col-span-5 bg-[#061813] rounded-lg p-6 border border-white/5">
            <div className="text-xs text-[#2dd4bf] mb-4 uppercase tracking-widest">System Architecture</div>
            <motion.svg width="100%" height="280" viewBox="0 0 360 280" initial="hidden" animate="visible">
              {/* Market Data Feeds */}
              <motion.rect
                x="18"
                y="20"
                rx="6"
                width="110"
                height="40"
                fill="#04120d"
                stroke="#2dd4bf"
                strokeWidth="1.5"
                variants={{ hidden: { opacity: 0 }, visible: { opacity: 1 } }}
              />
              <motion.text x="35" y="45" fill="#2dd4bf" fontSize="11">
                Market Feeds
              </motion.text>

              {/* Reference Data */}
              <motion.rect
                x="18"
                y="75"
                rx="6"
                width="110"
                height="40"
                fill="#04120d"
                stroke="#2dd4bf"
                strokeWidth="1.5"
                variants={{ hidden: { opacity: 0 }, visible: { opacity: 1 } }}
                transition={{ delay: 0.1 }}
              />
              <motion.text x="25" y="100" fill="#2dd4bf" fontSize="11">
                Reference Data
              </motion.text>

              {/* DataSentinel Core */}
              <motion.rect
                x="160"
                y="30"
                rx="8"
                width="180"
                height="110"
                fill="#020b08"
                stroke="#22c55e"
                strokeWidth="2"
                variants={{ hidden: { opacity: 0 }, visible: { opacity: 1 } }}
                transition={{ delay: 0.2 }}
              />
              <motion.text x="185" y="55" fill="#22c55e" fontSize="13" fontWeight="600">
                DataSentinel
              </motion.text>
              <motion.text x="185" y="75" fill="#86efac" fontSize="9">
                Trust Scoring Engine
              </motion.text>
              <motion.text x="185" y="92" fill="#86efac" fontSize="9">
                Schema Validation
              </motion.text>
              <motion.text x="185" y="109" fill="#86efac" fontSize="9">
                Anomaly Detection
              </motion.text>
              <motion.text x="185" y="126" fill="#86efac" fontSize="9">
                Auto-Gating Logic
              </motion.text>

              {/* Settlement Pipeline */}
              <motion.rect
                x="18"
                y="170"
                rx="6"
                width="110"
                height="40"
                fill="#04120d"
                stroke="#2dd4bf"
                strokeWidth="1.5"
                transition={{ delay: 0.35 }}
              />
              <motion.text x="22" y="195" fill="#2dd4bf" fontSize="11">
                Settlement Pipe
              </motion.text>

              {/* Audit Trail */}
              <motion.rect
                x="160"
                y="170"
                rx="6"
                width="180"
                height="40"
                fill="#051510"
                stroke="#22c55e"
                strokeWidth="1.5"
                transition={{ delay: 0.4 }}
              />
              <motion.text x="195" y="195" fill="#22c55e" fontSize="11">
                Audit Trail & Logs
              </motion.text>

              {/* Flow arrows */}
              <motion.path
                d="M128 40 L160 65"
                stroke="#2dd4bf"
                strokeWidth="2"
                strokeDasharray="4 4"
                variants={{ hidden: { pathLength: 0 }, visible: { pathLength: 1 } }}
                transition={{ duration: 0.8, delay: 0.5 }}
              />
              <motion.path
                d="M128 95 L160 95"
                stroke="#2dd4bf"
                strokeWidth="2"
                strokeDasharray="4 4"
                variants={{ hidden: { pathLength: 0 }, visible: { pathLength: 1 } }}
                transition={{ duration: 0.8, delay: 0.6 }}
              />
              <motion.path
                d="M250 140 L250 170"
                stroke="#22c55e"
                strokeWidth="2"
                variants={{ hidden: { pathLength: 0 }, visible: { pathLength: 1 } }}
                transition={{ duration: 0.6, delay: 0.7 }}
              />
              <motion.path
                d="M128 190 L160 190"
                stroke="#2dd4bf"
                strokeWidth="2"
                variants={{ hidden: { pathLength: 0 }, visible: { pathLength: 1 } }}
                transition={{ duration: 0.6, delay: 0.8 }}
              />

              {/* Alert indicator */}
              <motion.circle
                cx="250"
                cy="85"
                r="6"
                fill="#22c55e"
                animate={{ opacity: [0.5, 1, 0.5] }}
                transition={{ repeat: Number.POSITIVE_INFINITY, duration: 2 }}
              />
            </motion.svg>
          </div>
        </div>
      </section>

      <section className="py-20">
        <div className="container mx-auto px-6 max-w-4xl">
          <h2 className="text-sm uppercase tracking-widest text-emerald-400 mb-6 font-semibold">Client</h2>
          <p className="text-2xl text-gray-300 leading-relaxed">
            Tier-1 global investment bank operating multi-asset trading, post-trade, and settlement systems across North
            America, EMEA, and APAC with strict regulatory oversight.
          </p>
        </div>
      </section>

      {/* The Incident */}
      <section className="py-20 bg-gradient-to-b from-black via-emerald-500/5 to-black">
        <div className="container mx-auto px-6 max-w-4xl">
          <h2 className="text-4xl font-bold mb-8">The Incident</h2>
          <Card className="bg-white/5 border-red-500/30 p-8">
            <AlertTriangle className="w-12 h-12 text-red-400 mb-4" />
            <p className="text-xl text-gray-300 leading-relaxed">
              A delayed reference data feed introduced incorrect instrument mappings into downstream valuation systems.
              The issue was discovered manually{" "}
              <span className="text-red-400 font-semibold">hours before settlement</span>—narrowly avoiding failed
              settlement and regulatory escalation.
            </p>
          </Card>
        </div>
      </section>

      {/* Requirements */}
      <section className="py-20">
        <div className="container mx-auto px-6 max-w-6xl">
          <h2 className="text-4xl font-bold mb-12">Non-Negotiable Requirements</h2>

          <div className="grid md:grid-cols-2 gap-8">
            {[
              {
                title: "No auto-remediation",
                desc: "All corrections require explicit human approval before execution",
              },
              { title: "Zero added latency", desc: "No performance impact to critical trade execution paths" },
              { title: "Audit-replayable", desc: "Complete decision lineage for regulatory review and compliance" },
              {
                title: "Conservative learning",
                desc: "No model training on unverified corrections to preserve correctness",
              },
            ].map((item, i) => (
              <Card key={i} className="bg-white/5 border-white/10 p-8 hover:bg-white/[0.07] transition">
                <CheckCircle2 className="w-8 h-8 text-emerald-400 mb-4" />
                <h3 className="text-xl font-semibold mb-3">{item.title}</h3>
                <p className="text-gray-400 leading-relaxed">{item.desc}</p>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* Control-First Architecture */}
      <section className="py-20 bg-gradient-to-b from-black via-emerald-500/5 to-black">
        <div className="container mx-auto px-6 max-w-4xl">
          <h2 className="text-4xl font-bold mb-12">Control-First Architecture</h2>

          <div className="space-y-16">
            {[
              {
                step: "01",
                title: "Continuous trust scoring",
                desc: "Dynamic baselines across latency, volume, and statistical distributions for every data feed",
              },
              {
                step: "02",
                title: "Schema & lineage awareness",
                desc: "Column-level provenance and dependency modeling to understand downstream impact",
              },
              {
                step: "03",
                title: "Guarded execution",
                desc: "Automatic gating of downstream processes when trust scores fall below thresholds",
              },
              {
                step: "04",
                title: "Explainable remediation",
                desc: "Causal signals with audit-ready narratives for every alert and decision",
              },
            ].map((item, i) => (
              <motion.div
                key={i}
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ delay: i * 0.1 }}
                className="flex gap-8"
              >
                <div className="text-6xl font-bold text-emerald-400/20">{item.step}</div>
                <div className="flex-1 pt-2">
                  <h3 className="text-2xl font-semibold mb-3">{item.title}</h3>
                  <p className="text-gray-400 text-lg leading-relaxed">{item.desc}</p>
                </div>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* Deployment Timeline */}
      <section className="py-20">
        <div className="container mx-auto px-6 max-w-4xl">
          <h2 className="text-4xl font-bold mb-12">Deployment Timeline</h2>

          <div className="space-y-6">
            {[
              { phase: "Weeks 1–2", desc: "Trust surface mapping and failure-mode identification" },
              { phase: "Week 3", desc: "Shadow deployment with no gating—observation only" },
              { phase: "Week 5", desc: "Partial gating on non-critical pipelines with ops approval" },
              { phase: "Week 8", desc: "Full production rollout with audit sign-off" },
            ].map((item, i) => (
              <div key={i} className="flex gap-6 items-start">
                <div className="w-32 flex-shrink-0">
                  <div className="text-emerald-400 font-semibold">{item.phase}</div>
                </div>
                <div className="flex-1">
                  <div className="h-px bg-gradient-to-r from-emerald-500/50 to-transparent mb-4"></div>
                  <p className="text-gray-400 text-lg">{item.desc}</p>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Operational Outcomes */}
      <section className="py-20 border-t border-white/10">
        <div className="container mx-auto px-6 max-w-6xl">
          <h2 className="text-4xl font-bold mb-16 text-center">Operational Outcomes</h2>

          <div className="grid md:grid-cols-3 gap-8">
            <Card className="bg-gradient-to-br from-emerald-500/10 to-transparent border-emerald-500/20 p-8">
              <ShieldCheck className="w-8 h-8 text-emerald-400 mb-4" />
              <div className="text-4xl font-bold mb-2">Loss prevention</div>
              <div className="text-gray-400">Early detection before settlement impact</div>
            </Card>

            <Card className="bg-gradient-to-br from-emerald-500/10 to-transparent border-emerald-500/20 p-8">
              <Clock className="w-8 h-8 text-emerald-400 mb-4" />
              <div className="text-4xl font-bold mb-2">Lower ops load</div>
              <div className="text-gray-400">Reduced manual reconciliation effort</div>
            </Card>

            <Card className="bg-gradient-to-br from-emerald-500/10 to-transparent border-emerald-500/20 p-8">
              <Database className="w-8 h-8 text-emerald-400 mb-4" />
              <div className="text-4xl font-bold mb-2">Audit confidence</div>
              <div className="text-gray-400">Traceable decisions with preserved context</div>
            </Card>
          </div>
        </div>
      </section>

      {/* Powered By */}
      <section className="py-20 bg-gradient-to-b from-black via-emerald-500/5 to-black">
        <div className="container mx-auto px-6 max-w-6xl">
          <h2 className="text-4xl font-bold mb-12">Powered By</h2>

          <Link href="/products/datasentinel">
            <Card className="bg-white/5 border-white/10 p-12 hover:bg-white/[0.07] hover:border-emerald-500/30 transition">
              <h3 className="text-3xl font-bold mb-4 text-emerald-400">DataSentinel</h3>
              <p className="text-xl text-gray-400 leading-relaxed mb-6">
                Continuous data reliability monitoring, trust scoring, and anomaly detection for mission-critical data
                pipelines in regulated environments.
              </p>
              <div className="text-emerald-400 inline-flex items-center gap-2">
                Learn more about DataSentinel <ArrowRight className="w-5 h-5" />
              </div>
            </Card>
          </Link>
        </div>
      </section>

      <section className="py-32">
        <div className="container mx-auto px-6 max-w-4xl text-center">
          <h2 className="text-4xl md:text-5xl font-bold mb-6">
            Built for environments where failure is not acceptable
          </h2>
          <p className="text-xl text-gray-400 mb-12 max-w-2xl mx-auto">
            If your data powers financial decisions or regulatory reporting, let's talk about trust controls.
          </p>
          <div className="flex gap-4 justify-center">
            <Link
              href="/contact"
              className="bg-emerald-500 text-black px-8 py-4 rounded-lg font-semibold hover:bg-emerald-400 transition"
            >
              Speak with an Architect
            </Link>
            <Link
              href="/case-studies"
              className="border border-white/20 px-8 py-4 rounded-lg hover:border-white/40 transition"
            >
              View All Case Studies
            </Link>
          </div>
        </div>
      </section>

      <footer className="py-12 border-t border-white/10 text-center text-gray-500 text-sm">
        © 2025 Nabla-X. Intelligence for regulated financial systems.
      </footer>
    </div>
  )
}
