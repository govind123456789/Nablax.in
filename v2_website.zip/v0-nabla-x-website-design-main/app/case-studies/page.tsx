"use client"

import Link from "next/link"
import { Card } from "@/components/ui/card"
import { motion } from "framer-motion"
import { ArrowRight, Building2, HeartPulse, Radio } from "lucide-react"

export default function CaseStudiesHub() {
  const caseStudies = [
    {
      slug: "revenue-drift-healthcare",
      industry: "Healthcare",
      title: "Revenue Drift Diagnosis",
      subtitle: "for Healthcare Provider Networks",
      description:
        "Detect and explain hidden revenue leakage across hospitals and outpatient networks by combining intent-aware analytics, schema-grounded reasoning, and guarded execution.",
      icon: HeartPulse,
      color: "#60a5fa",
      bgGradient: "from-[#0a1628] via-[#0f2742] to-[#0a1628]",
      tags: ["QueryMind", "DataSentinel", "RootSense"],
    },
    {
      slug: "anomaly-protection-finserv",
      industry: "Financial Services",
      title: "Data Trust & Anomaly Protection",
      subtitle: "for Regulated Financial Systems",
      description:
        "Continuous trust controls across market data, reference feeds, and settlement pipelines to prevent silent data failures before financial or regulatory impact.",
      icon: Building2,
      color: "#2dd4bf",
      bgGradient: "from-[#020b08] via-[#061611] to-[#020b08]",
      tags: ["DataSentinel", "Real-time monitoring"],
    },
    {
      slug: "explainability-platform-telco",
      industry: "Telecommunications",
      title: "Explainability Platform",
      subtitle: "for Network Operations & Customer Analytics",
      description:
        "AI-driven churn prevention and network incident triage with transparent, defensible decision-making using causal explanation and historical analogues.",
      icon: Radio,
      color: "#60a5fa",
      bgGradient: "from-[#071a2e] via-[#0a2544] to-[#071a2e]",
      tags: ["RootSense", "Explainability"],
    },
  ]

  return (
    <div className="min-h-screen bg-gradient-to-br from-[#020510] via-[#0a0f1e] to-[#020510] text-[#e8f4f8]">
      {/* Header */}
      <header className="border-b border-white/6 bg-black/90 backdrop-blur sticky top-0 z-50">
        <div className="container mx-auto px-6 py-4 flex items-center justify-between">
          <Link href="/" className="text-[#60a5fa] text-2xl font-light">
            ∇<sup className="text-sm">x</sup>
          </Link>
          <nav className="hidden md:flex gap-6 text-sm">
            <Link href="/about" className="hover:text-[#60a5fa] transition">
              About
            </Link>
            <Link href="/services" className="hover:text-[#60a5fa] transition">
              Services
            </Link>
            <Link href="/case-studies" className="text-[#60a5fa]">
              Case Studies
            </Link>
            <Link href="/contact" className="hover:text-[#60a5fa] transition">
              Contact
            </Link>
          </nav>
        </div>
      </header>

      {/* Hero */}
      <section className="pt-28 pb-16">
        <div className="container mx-auto px-6 max-w-5xl text-center">
          <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.6 }}>
            <div className="text-xs uppercase tracking-widest text-[#60a5fa] mb-4">Representative Engagements</div>

            <h1 className="text-5xl md:text-6xl font-light leading-tight mb-6">
              Intelligence systems
              <br />
              <span className="text-[#60a5fa]">built for production</span>
            </h1>

            <p className="text-gray-300 text-lg max-w-3xl mx-auto leading-relaxed">
              Selected engagements demonstrating our approach to correctness, safety, and operationalization in
              regulated and high-stakes environments.
            </p>
          </motion.div>
        </div>
      </section>

      {/* Featured Case Studies */}
      <section className="py-12">
        <div className="container mx-auto px-6 max-w-6xl">
          <div className="space-y-8">
            {caseStudies.map((study, index) => (
              <motion.div
                key={study.slug}
                initial={{ opacity: 0, y: 30 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.5, delay: index * 0.15 }}
              >
                <Card className="bg-gradient-to-br from-[#071021]/80 to-[#0a1628]/60 border-white/8 overflow-hidden hover:border-white/20 transition-all duration-300">
                  <Link href={`/case-studies/${study.slug}`}>
                    <div className="grid lg:grid-cols-12 gap-8 p-8 items-center">
                      {/* Icon & Industry Tag */}
                      <div className="lg:col-span-2 flex flex-col items-center lg:items-start gap-3">
                        <div
                          className="w-16 h-16 rounded-xl flex items-center justify-center"
                          style={{
                            backgroundColor: `${study.color}15`,
                            border: `1px solid ${study.color}40`,
                          }}
                        >
                          <study.icon className="w-8 h-8" style={{ color: study.color }} />
                        </div>
                        <span
                          className="text-xs px-3 py-1 rounded-full font-medium"
                          style={{
                            backgroundColor: `${study.color}20`,
                            color: study.color,
                          }}
                        >
                          {study.industry}
                        </span>
                      </div>

                      {/* Content */}
                      <div className="lg:col-span-8">
                        <h3 className="text-2xl font-light mb-2">
                          {study.title}
                          <span className="text-gray-400"> {study.subtitle}</span>
                        </h3>
                        <p className="text-gray-300 text-sm leading-relaxed mb-4">{study.description}</p>
                        <div className="flex gap-2 flex-wrap">
                          {study.tags.map((tag) => (
                            <span key={tag} className="text-xs px-3 py-1 rounded bg-white/5 text-gray-400">
                              {tag}
                            </span>
                          ))}
                        </div>
                      </div>

                      {/* CTA Arrow */}
                      <div className="lg:col-span-2 flex justify-center lg:justify-end">
                        <div
                          className="w-12 h-12 rounded-full flex items-center justify-center group-hover:scale-110 transition-transform"
                          style={{ backgroundColor: `${study.color}20` }}
                        >
                          <ArrowRight className="w-5 h-5" style={{ color: study.color }} />
                        </div>
                      </div>
                    </div>
                  </Link>
                </Card>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* Approach Summary */}
      <section className="py-16 border-t border-white/6">
        <div className="container mx-auto px-6 max-w-5xl">
          <div className="text-center mb-10">
            <h2 className="text-3xl font-light mb-4">Our approach</h2>
            <p className="text-gray-400 max-w-2xl mx-auto">
              Every engagement follows a systematic pattern: understand constraints, map semantics, deploy with
              guardrails, and operationalize for lasting impact.
            </p>
          </div>

          <div className="grid md:grid-cols-3 gap-6">
            <Card className="bg-[#071021] border-white/8 p-6 text-center">
              <div className="text-4xl font-light text-[#60a5fa] mb-2">01</div>
              <h4 className="text-sm font-medium mb-2">Context & Constraints</h4>
              <p className="text-xs text-gray-400">
                Map decision flows, risk surfaces, and regulatory requirements before any implementation.
              </p>
            </Card>

            <Card className="bg-[#071021] border-white/8 p-6 text-center">
              <div className="text-4xl font-light text-[#60a5fa] mb-2">02</div>
              <h4 className="text-sm font-medium mb-2">Guarded Deployment</h4>
              <p className="text-xs text-gray-400">
                Deploy with observability, trust scoring, and execution controls to ensure safety at scale.
              </p>
            </Card>

            <Card className="bg-[#071021] border-white/8 p-6 text-center">
              <div className="text-4xl font-light text-[#60a5fa] mb-2">03</div>
              <h4 className="text-sm font-medium mb-2">Explainable Outcomes</h4>
              <p className="text-xs text-gray-400">
                Provide context-rich explanations with audit trails for regulatory and operational confidence.
              </p>
            </Card>
          </div>
        </div>
      </section>

      {/* CTA */}
      <section className="py-16 border-t border-white/6">
        <div className="container mx-auto px-6 max-w-4xl text-center">
          <h3 className="text-2xl font-light mb-4">Built for environments where correctness is non-negotiable</h3>
          <p className="text-gray-400 mb-6 max-w-2xl mx-auto">
            If your systems carry decision risk or regulatory constraints, we should talk. We prioritize selective,
            durable engagements.
          </p>
          <div className="flex justify-center gap-4">
            <Link
              href="/contact"
              className="bg-[#60a5fa] text-black px-8 py-3 rounded-md font-medium hover:opacity-95 transition"
            >
              Discuss Your Environment
            </Link>
            <Link
              href="/services"
              className="border border-white/20 px-8 py-3 rounded-md text-gray-300 hover:border-white/40 transition"
            >
              Engagement Models
            </Link>
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="py-10 border-t border-white/8 text-center text-gray-400">
        <p className="text-sm">© 2025 Nabla-X. Intelligence for complex systems.</p>
      </footer>
    </div>
  )
}
