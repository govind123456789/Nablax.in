"use client"

import Link from "next/link"
import { Card } from "@/components/ui/card"
import { motion } from "framer-motion"
import { Lightbulb, Target, CheckCircle2, ArrowRight, Zap, TrendingUp } from "lucide-react"

export default function ExplainabilityTelco() {
  return (
    <div className="min-h-screen bg-black text-white">
      <header className="border-b border-white/10 bg-black/95 backdrop-blur-xl sticky top-0 z-50">
        <div className="container mx-auto px-6 py-5 flex items-center justify-between">
          <Link href="/" className="text-[#d4af37] text-2xl font-semibold tracking-tight">
            Nabla-X
          </Link>
          <nav className="hidden md:flex gap-8 text-sm text-gray-400">
            <Link href="/services" className="hover:text-white transition">
              Services
            </Link>
            <Link href="/case-studies" className="text-white font-medium">
              Case Studies
            </Link>
            <Link href="/contact" className="hover:text-white transition">
              Contact
            </Link>
          </nav>
        </div>
      </header>

      <section className="pt-32 pb-20">
        <div className="container mx-auto px-6 max-w-6xl">
          <div className="flex items-center gap-3 mb-8">
            <span className="px-3 py-1.5 bg-orange-500/10 border border-orange-500/20 rounded-full text-orange-400 text-xs font-medium">
              Telecommunications
            </span>
            <span className="text-gray-500">·</span>
            <span className="text-gray-400 text-sm">6 minute read</span>
          </div>

          <h1 className="text-5xl md:text-7xl font-bold leading-tight mb-8 text-balance">
            Making AI decisions
            <span className="text-orange-400"> transparent</span> and defensible
          </h1>

          <p className="text-xl text-gray-400 max-w-3xl leading-relaxed mb-12">
            A national telecommunications provider deployed RootSense to make AI-driven churn prevention and network
            incident decisions transparent, defensible, and operationally actionable.
          </p>

          <div className="flex gap-4">
            <Link
              href="/contact"
              className="bg-orange-500 text-white px-8 py-4 rounded-lg font-semibold hover:bg-orange-400 transition inline-flex items-center gap-2"
            >
              Discuss Your Use Case
              <ArrowRight className="w-5 h-5" />
            </Link>
          </div>
        </div>
      </section>

      <section className="py-20 border-y border-white/10">
        <div className="container mx-auto px-6 max-w-6xl">
          <div className="grid md:grid-cols-3 gap-12">
            <div>
              <div className="text-6xl font-bold text-orange-400 mb-3">40%</div>
              <div className="text-gray-400 text-lg">Faster incident triage with causal context</div>
            </div>
            <div>
              <div className="text-6xl font-bold text-orange-400 mb-3">9 weeks</div>
              <div className="text-gray-400 text-lg">From design to production deployment</div>
            </div>
            <div>
              <div className="text-6xl font-bold text-orange-400 mb-3">100%</div>
              <div className="text-gray-400 text-lg">Regulator-ready decision trails</div>
            </div>
          </div>
        </div>
      </section>

      {/* Hero */}
      <section className="pt-24 pb-12 border-b border-white/6">
        <div className="container mx-auto px-6 max-w-6xl">
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-10 items-center">
            <div className="lg:col-span-7">
              <div className="text-xs uppercase tracking-widest text-[#f97316] mb-4">
                Case Study · Telecommunications · Powered by RootSense
              </div>

              <h1 className="text-4xl md:text-5xl font-light leading-tight mb-4">
                Explainability Platform
                <br />
                <span className="text-[#f97316]">for Network Operations & Customer Analytics</span>
              </h1>

              <p className="text-gray-300 max-w-3xl mb-6">
                A national telecommunications provider deployed RootSense to make AI-driven churn prevention and network
                incident decisions transparent, defensible, and operationally actionable.
              </p>

              <div className="flex gap-4 flex-wrap">
                <Link
                  href="/contact"
                  className="bg-[#f97316] text-white px-6 py-3 rounded-md font-medium hover:opacity-95 transition"
                >
                  Discuss Your Use Case
                </Link>
                <Link
                  href="/products/rootsense"
                  className="border border-[#f97316]/40 px-6 py-3 rounded-md text-gray-300 hover:border-[#f97316] transition"
                >
                  Explore RootSense
                </Link>
              </div>
            </div>

            {/* Architecture Diagram */}
            <div className="lg:col-span-5">
              <div className="bg-[#0f1628] rounded-lg p-6 border border-[#f97316]/20">
                <div className="text-xs text-[#f97316] mb-4 uppercase tracking-widest">RootSense Architecture</div>
                <motion.svg width="100%" height="260" viewBox="0 0 360 260" initial="hidden" animate="visible">
                  {/* AI Models */}
                  <motion.rect
                    x="18"
                    y="20"
                    rx="8"
                    width="120"
                    height="52"
                    fill="#0f1a2e"
                    stroke="#f97316"
                    strokeWidth="1.5"
                    variants={{ hidden: { opacity: 0 }, visible: { opacity: 1 } }}
                    transition={{ duration: 0.4 }}
                  />
                  <motion.text x="28" y="42" fill="#fb923c" fontSize="10">
                    Churn Model
                  </motion.text>
                  <motion.text x="28" y="58" fill="#fb923c" fontSize="10">
                    Incident Model
                  </motion.text>

                  {/* RootSense Layer */}
                  <motion.rect
                    x="160"
                    y="16"
                    rx="8"
                    width="180"
                    height="90"
                    fill="#0a1528"
                    stroke="#f97316"
                    strokeWidth="2"
                    variants={{ hidden: { opacity: 0 }, visible: { opacity: 1 } }}
                    transition={{ duration: 0.4, delay: 0.15 }}
                  />
                  <motion.text x="175" y="40" fill="#f97316" fontSize="12" fontWeight="600">
                    RootSense Engine
                  </motion.text>
                  <motion.text x="175" y="58" fill="#fb923c" fontSize="9">
                    Causal Extraction
                  </motion.text>
                  <motion.text x="175" y="73" fill="#fb923c" fontSize="9">
                    Feature Importance
                  </motion.text>
                  <motion.text x="175" y="88" fill="#fb923c" fontSize="9">
                    Similarity Search
                  </motion.text>

                  {/* Operations Dashboard */}
                  <motion.rect
                    x="18"
                    y="130"
                    rx="8"
                    width="120"
                    height="52"
                    fill="#0f1a2e"
                    stroke="#f97316"
                    strokeWidth="1.5"
                    variants={{ hidden: { opacity: 0 }, visible: { opacity: 1 } }}
                    transition={{ duration: 0.4, delay: 0.2 }}
                  />
                  <motion.text x="28" y="160" fill="#fb923c" fontSize="10">
                    Ops Dashboard
                  </motion.text>

                  {/* Audit Trail */}
                  <motion.rect
                    x="160"
                    y="130"
                    rx="8"
                    width="180"
                    height="52"
                    fill="#0a1528"
                    stroke="#22c55e"
                    strokeWidth="1.5"
                    variants={{ hidden: { opacity: 0 }, visible: { opacity: 1 } }}
                    transition={{ duration: 0.4, delay: 0.25 }}
                  />
                  <motion.text x="175" y="160" fill="#22c55e" fontSize="10">
                    Audit & Decision Lineage
                  </motion.text>

                  {/* Historical DB */}
                  <motion.rect
                    x="18"
                    y="200"
                    rx="8"
                    width="120"
                    height="42"
                    fill="#0f1a2e"
                    stroke="#f97316"
                    strokeWidth="1.5"
                    variants={{ hidden: { opacity: 0 }, visible: { opacity: 1 } }}
                    transition={{ duration: 0.4, delay: 0.3 }}
                  />
                  <motion.text x="28" y="225" fill="#fb923c" fontSize="10">
                    Historical Cases
                  </motion.text>

                  {/* Flow Lines */}
                  <motion.path
                    d="M138 46 L160 51"
                    stroke="#f97316"
                    strokeWidth="2"
                    variants={{ hidden: { pathLength: 0 }, visible: { pathLength: 1 } }}
                    transition={{ duration: 0.6, delay: 0.35 }}
                  />
                  <motion.path
                    d="M78 72 L78 130"
                    stroke="#f97316"
                    strokeWidth="2"
                    strokeDasharray="4 6"
                    variants={{ hidden: { pathLength: 0 }, visible: { pathLength: 1 } }}
                    transition={{ duration: 0.6, delay: 0.4 }}
                  />
                  <motion.path
                    d="M250 106 L250 130"
                    stroke="#22c55e"
                    strokeWidth="2"
                    variants={{ hidden: { pathLength: 0 }, visible: { pathLength: 1 } }}
                    transition={{ duration: 0.6, delay: 0.45 }}
                  />
                  <motion.path
                    d="M78 182 L78 200"
                    stroke="#f97316"
                    strokeWidth="2"
                    strokeDasharray="4 6"
                    variants={{ hidden: { pathLength: 0 }, visible: { pathLength: 1 } }}
                    transition={{ duration: 0.6, delay: 0.5 }}
                  />
                  <motion.path
                    d="M138 221 L160 75"
                    stroke="#f97316"
                    strokeWidth="1.5"
                    strokeDasharray="3 5"
                    variants={{ hidden: { pathLength: 0 }, visible: { pathLength: 1 } }}
                    transition={{ duration: 0.8, delay: 0.55 }}
                  />

                  {/* Pulse indicator */}
                  <motion.circle
                    cx="250"
                    cy="60"
                    r="5"
                    fill="#f97316"
                    animate={{ opacity: [0.5, 1, 0.5], scale: [1, 1.2, 1] }}
                    transition={{ repeat: Number.POSITIVE_INFINITY, duration: 2 }}
                  />
                </motion.svg>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Client Context */}
      <section className="py-20">
        <div className="container mx-auto px-6 max-w-4xl">
          <h2 className="text-sm uppercase tracking-widest text-orange-400 mb-6 font-semibold">Client</h2>
          <p className="text-2xl text-gray-300 leading-relaxed">
            National telecommunications provider serving 15M+ subscribers with complex network infrastructure.
            Operations and customer analytics teams relied on AI models for churn prediction and incident
            prioritization.
          </p>
        </div>
      </section>

      {/* The Problem */}
      <section className="py-20 bg-gradient-to-b from-black via-orange-500/5 to-black">
        <div className="container mx-auto px-6 max-w-6xl">
          <h2 className="text-4xl font-bold mb-12">The Challenge</h2>

          <div className="grid md:grid-cols-3 gap-8">
            <Card className="bg-white/5 border-white/10 p-8 hover:bg-white/[0.07] transition">
              <Target className="w-10 h-10 text-orange-400 mb-4" />
              <h3 className="text-xl font-semibold mb-3">Opaque predictions</h3>
              <p className="text-gray-400 leading-relaxed">
                AI models flagged high-risk customers without actionable reasoning. Retention teams couldn't personalize
                interventions.
              </p>
            </Card>

            <Card className="bg-white/5 border-white/10 p-8 hover:bg-white/[0.07] transition">
              <Zap className="w-10 h-10 text-orange-400 mb-4" />
              <h3 className="text-xl font-semibold mb-3">Incident delays</h3>
              <p className="text-gray-400 leading-relaxed">
                Network operations received prioritized incidents without historical context, slowing root cause
                analysis.
              </p>
            </Card>

            <Card className="bg-white/5 border-white/10 p-8 hover:bg-white/[0.07] transition">
              <Lightbulb className="w-10 h-10 text-orange-400 mb-4" />
              <h3 className="text-xl font-semibold mb-3">Regulatory risk</h3>
              <p className="text-gray-400 leading-relaxed">
                Regulators required transparent decision logic. Existing models couldn't produce defensible
                explanations.
              </p>
            </Card>
          </div>
        </div>
      </section>

      {/* Our Approach */}
      <section className="py-12">
        <div className="container mx-auto px-6 max-w-6xl">
          <h2 className="text-2xl text-[#f97316] font-light mb-6">Our Approach</h2>

          <div className="space-y-6">
            <Card className="bg-[#0a1e36] border-white/10 p-6">
              <h3 className="text-lg text-[#f97316] mb-2">1. RootSense Explanation Layer</h3>
              <p className="text-gray-300 text-sm">
                Deployed RootSense as a middle layer between AI models and operational systems. For each prediction,
                RootSense extracted causal factors, ranked feature importance, and retrieved historical analogues from
                similar past events.
              </p>
            </Card>

            <Card className="bg-[#0a1e36] border-white/10 p-6">
              <h3 className="text-lg text-[#f97316] mb-2">2. Contextual Narrative Generation</h3>
              <p className="text-gray-300 text-sm">
                Transformed model outputs into human-readable narratives: "Customer flagged due to 3 recent service
                outages (similar to Case #4521) + contract ending in 45 days." Linked directly to execution context and
                historical resolution patterns.
              </p>
            </Card>

            <Card className="bg-[#0a1e36] border-white/10 p-6">
              <h3 className="text-lg text-[#f97316] mb-2">3. Audit-Ready Decision Trails</h3>
              <p className="text-gray-300 text-sm">
                Every AI decision logged with full lineage: input features, model version, explanation reasoning, and
                human override actions. Created regulator-ready audit artifacts without additional manual documentation.
              </p>
            </Card>
          </div>
        </div>
      </section>

      {/* Implementation Timeline */}
      <section className="py-20 bg-gradient-to-b from-black via-orange-500/5 to-black">
        <div className="container mx-auto px-6 max-w-4xl">
          <h2 className="text-4xl font-bold mb-12">Implementation Timeline</h2>

          <div className="space-y-6">
            {[
              { phase: "Weeks 1–2", desc: "Model inventory, feature mapping, explanation surface design" },
              { phase: "Week 3", desc: "RootSense integration with churn model (shadow mode)" },
              { phase: "Week 5", desc: "Network incident model integration + historical analogue retrieval" },
              { phase: "Week 7", desc: "Operations dashboard rollout with explanation UI" },
              { phase: "Week 9", desc: "Regulatory review prep and full production deployment" },
            ].map((item, i) => (
              <div key={i} className="flex gap-6 items-start">
                <div className="w-28 flex-shrink-0">
                  <div className="text-orange-400 font-semibold">{item.phase}</div>
                </div>
                <div className="flex-1">
                  <div className="h-px bg-gradient-to-r from-orange-500/50 to-transparent mb-4"></div>
                  <p className="text-gray-400 text-lg">{item.desc}</p>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Outcomes */}
      <section className="py-20 border-t border-white/10">
        <div className="container mx-auto px-6 max-w-6xl">
          <h2 className="text-4xl font-bold mb-16 text-center">Operational Outcomes</h2>

          <div className="grid md:grid-cols-3 gap-8">
            <Card className="bg-gradient-to-br from-orange-500/10 to-transparent border-orange-500/20 p-8">
              <TrendingUp className="w-8 h-8 text-orange-400 mb-4" />
              <div className="text-4xl font-bold mb-2">40% faster</div>
              <div className="text-gray-400">Network ops resolved incidents with causal context</div>
            </Card>

            <Card className="bg-gradient-to-br from-orange-500/10 to-transparent border-orange-500/20 p-8">
              <CheckCircle2 className="w-8 h-8 text-orange-400 mb-4" />
              <div className="text-4xl font-bold mb-2">Audit-ready</div>
              <div className="text-gray-400">Passed regulatory review with complete decision trails</div>
            </Card>

            <Card className="bg-gradient-to-br from-orange-500/10 to-transparent border-orange-500/20 p-8">
              <Lightbulb className="w-8 h-8 text-orange-400 mb-4" />
              <div className="text-4xl font-bold mb-2">Higher trust</div>
              <div className="text-gray-400">Teams adopted AI recommendations confidently</div>
            </Card>
          </div>
        </div>
      </section>

      {/* Product Callout */}
      <section className="py-20 bg-gradient-to-b from-black via-orange-500/5 to-black">
        <div className="container mx-auto px-6 max-w-6xl">
          <h2 className="text-4xl font-bold mb-12">Powered By</h2>

          <Link href="/products/rootsense">
            <Card className="bg-white/5 border-white/10 p-12 hover:bg-white/[0.07] hover:border-orange-500/30 transition">
              <h3 className="text-3xl font-bold mb-4 text-orange-400">RootSense</h3>
              <p className="text-xl text-gray-400 leading-relaxed mb-6">
                Causal explanation, similarity search, and decision lineage for AI systems. Transform opaque model
                outputs into transparent, auditable narratives with deep explainability.
              </p>
              <div className="text-orange-400 inline-flex items-center gap-2">
                Learn more about RootSense <ArrowRight className="w-5 h-5" />
              </div>
            </Card>
          </Link>
        </div>
      </section>

      <section className="py-32">
        <div className="container mx-auto px-6 max-w-4xl text-center">
          <h2 className="text-4xl md:text-5xl font-bold mb-6">Make your AI decisions explainable</h2>
          <p className="text-xl text-gray-400 mb-12 max-w-2xl mx-auto">
            If your AI systems influence operations or face regulatory scrutiny, let's discuss explainability.
          </p>
          <div className="flex gap-4 justify-center">
            <Link
              href="/contact"
              className="bg-orange-500 text-white px-8 py-4 rounded-lg font-semibold hover:bg-orange-400 transition"
            >
              Speak with an Architect
            </Link>
            <Link
              href="/case-studies"
              className="border border-white/20 px-8 py-4 rounded-lg hover:border-white/40 transition"
            >
              View All Case Studies
            </Link>
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="py-12 border-t border-white/10 text-center text-gray-500 text-sm">
        © 2025 Nabla-X. Intelligence for complex systems.
      </footer>
    </div>
  )
}
