"use client"

import Link from "next/link"
import { Card } from "@/components/ui/card"
import { motion } from "framer-motion"

export default function RevenueDriftHealthcare() {
  return (
    <div className="min-h-screen bg-black text-white antialiased healthcare-theme">


      {/* Header (matching Services page header style) */}
      <header className="border-b border-white/6 bg-black/85 backdrop-blur">
        <div className="container mx-auto px-6 py-4 flex items-center justify-between">
          <Link href="/" className="text-[#60a5fa] text-2xl font-light">
            ∇<sup className="text-sm">x</sup>
          </Link>
          <nav className="hidden md:flex gap-6 text-sm">
            <Link href="/" className="hover:text-[#60a5fa]">Home</Link>
            <Link href="/about" className="hover:text-[#60a5fa]">About</Link>
            <Link href="/services" className="text-[#60a5fa]">Services</Link>
            <Link href="/contact" className="hover:text-[#60a5fa]">Contact</Link>
          </nav>
        </div>
      </header>

      {/* HERO — healthcare-styled */}
      <section className="pt-24 pb-12 border-b border-white/6">
        <div className="container mx-auto px-6 max-w-6xl">
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-center">
            <div className="lg:col-span-7">
              <div className="text-xs uppercase tracking-wide text-[#60a5fa] mb-4">
                Industry · Healthcare
              </div>

              <h1 className="text-4xl md:text-5xl font-light leading-tight mb-4">
                Revenue Drift Diagnosis
                <br />
                <span className="text-[#60a5fa]">
                  for Healthcare Provider Networks
                </span>
              </h1>

              <p className="text-gray-300 max-w-3xl mb-6">
                Detect and explain hidden revenue leakage across hospitals and outpatient networks by
                combining intent-aware analytics, schema-grounded reasoning, and guarded execution.
                Designed for clinical environments where decisions affect both care and finances.
              </p>

              <div className="flex flex-wrap gap-3 items-center">
                <Link
                  href="/contact"
                  className="inline-block bg-[#60a5fa] text-black px-6 py-3 rounded-md font-medium hover:opacity-95 transition"
                >
                  Discuss Your Environment
                </Link>

                <Link
                  href="/products/querymind"
                  className="inline-block border border-white/10 text-gray-300 px-5 py-3 rounded-md hover:bg-white/2 transition text-sm"
                >
                  Explore QueryMind
                </Link>
              </div>

              <div className="mt-6 text-sm text-gray-300 flex gap-3 flex-wrap">
                <span className="opacity-60">Explore:</span>
                <Link href="/industries/healthcare" className="underline hover:text-[#60a5fa]">
                  Healthcare overview
                </Link>
                <span className="opacity-30">•</span>
                <Link href="/products/querymind" className="underline hover:text-[#60a5fa]">
                  QueryMind
                </Link>
                <span className="opacity-30">•</span>
                <Link href="/products/datasentinel" className="underline hover:text-[#60a5fa]">
                  DataSentinel
                </Link>
                <span className="opacity-30">•</span>
                <Link href="/products/rootsense" className="underline hover:text-[#60a5fa]">
                  RootSense
                </Link>
              </div>
            </div>

            {/* === ANIMATED ARCHITECTURE SVG === */}
            <div className="lg:col-span-5">
              <div className="bg-[#071a2e] rounded-lg p-6 flex justify-center items-center">

                <motion.svg
                  width="340"
                  height="220"
                  viewBox="0 0 340 220"
                  initial="hidden"
                  animate="visible"
                  whileHover="hover"
                >

                  {/* EHR / Billing */}
                  <motion.rect
                    x="12"
                    y="20"
                    rx="8"
                    width="120"
                    height="60"
                    fill="#0f172a"
                    stroke="#38bdf8"
                    variants={{
                      hidden: { opacity: 0, y: 10 },
                      visible: { opacity: 1, y: 0 }
                    }}
                    transition={{ duration: 0.4 }}
                  />
                  <text x="22" y="56" fill="#bae6fd" fontSize="11">
                    EHR / Billing
                  </text>

                  {/* Intent & Semantics */}
                  <motion.rect
                    x="152"
                    y="16"
                    rx="8"
                    width="176"
                    height="48"
                    fill="#020617"
                    stroke="#22d3ee"
                    variants={{
                      hidden: { opacity: 0, y: 10 },
                      visible: { opacity: 1, y: 0 }
                    }}
                    transition={{ duration: 0.4, delay: 0.1 }}
                  />
                  <text x="172" y="44" fill="#bae6fd" fontSize="11">
                    Intent & Semantics
                  </text>

                  {/* DataSentinel */}
                  <motion.rect
                    x="12"
                    y="110"
                    rx="8"
                    width="120"
                    height="64"
                    fill="#0f172a"
                    stroke="#38bdf8"
                    variants={{
                      hidden: { opacity: 0, y: 10 },
                      visible: { opacity: 1, y: 0 }
                    }}
                    transition={{ duration: 0.4, delay: 0.2 }}
                  />
                  <text x="26" y="144" fill="#bae6fd" fontSize="11">
                    DataSentinel (DQ)
                  </text>

                  {/* Execution */}
                  <motion.rect
                    x="152"
                    y="96"
                    rx="8"
                    width="176"
                    height="78"
                    fill="#020617"
                    stroke="#22d3ee"
                    variants={{
                      hidden: { opacity: 0, y: 10 },
                      visible: { opacity: 1, y: 0 }
                    }}
                    transition={{ duration: 0.4, delay: 0.3 }}
                  />
                  <text x="164" y="126" fill="#bae6fd" fontSize="11">
                    Guarded Execution → Explanation
                  </text>

                  {/* Flow lines */}
                  <motion.path
                    d="M132 50 L152 36"
                    stroke="#38bdf8"
                    strokeWidth="2"
                    strokeDasharray="4 6"
                    variants={{
                      hidden: { pathLength: 0 },
                      visible: { pathLength: 1 }
                    }}
                    transition={{ duration: 0.6, delay: 0.4 }}
                  />

                  <motion.path
                    d="M72 80 L72 110"
                    stroke="#38bdf8"
                    strokeWidth="2"
                    variants={{
                      hidden: { pathLength: 0 },
                      visible: { pathLength: 1 }
                    }}
                    transition={{ duration: 0.6, delay: 0.5 }}
                  />

                  <motion.path
                    d="M200 64 L200 96"
                    stroke="#22d3ee"
                    strokeWidth="2"
                    strokeDasharray="4 6"
                    animate={{ opacity: [0.4, 1, 0.4] }}
                    transition={{ repeat: Infinity, duration: 2 }}
                  />
                </motion.svg>

              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Healthcare context — deeper details */}
      <section className="py-12">
        <div className="container mx-auto px-6 max-w-6xl">
          <h2 className="text-2xl text-[#60a5fa] font-light mb-4">Healthcare context — why this is hard</h2>

          <div className="grid md:grid-cols-3 gap-6">
            <Card className="bg-[#071021] border-white/6 p-5">
              <h3 className="text-sm text-[#60a5fa] mb-2 font-medium">Fragmented systems</h3>
              <p className="text-gray-300 text-sm">
                Clinical (EHR), billing, lab, PACS, and external payer feeds often disagree on encounters and timestamps.
                Reconciling these reliably requires lineage, mapping, and conservative joins.
              </p>
            </Card>

            <Card className="bg-[#071021] border-white/6 p-5">
              <h3 className="text-sm text-[#60a5fa] mb-2 font-medium">Coding & documentation variability</h3>
              <p className="text-gray-300 text-sm">
                CPT/DRG use differs across facilities and coders. Small documentation differences can produce large revenue changes.
                Detection requires semantic matching across clinical notes and invoice records.
              </p>
            </Card>

            <Card className="bg-[#071021] border-white/6 p-5">
              <h3 className="text-sm text-[#60a5fa] mb-2 font-medium">Payer & contract complexity</h3>
              <p className="text-gray-300 text-sm">
                Different payer contracts apply different remittance rules; revenue shifts may be payer-driven rather than clinical.
                Our solution surfaces payer-driven vs clinical-driven causes.
              </p>
            </Card>
          </div>
        </div>
      </section>

      {/* The problem (detailed) */}
      <section className="py-12 border-t border-white/6">
        <div className="container mx-auto px-6 max-w-6xl">
          <h2 className="text-2xl text-[#60a5fa] font-light mb-4">Problem statement</h2>

          <Card className="bg-[#071021] border-white/6 p-6">
            <p className="text-gray-300 leading-relaxed mb-4">
              Finance noticed recurring drops in revenue for several service lines. Surface-level metrics (totals) were
              available, but leadership needed causality: which service, which site, which documentation gap, and what
              payer behavior caused the change. Analysts were reluctant to run complex joins for fear of producing
              misleading results because some sources (e.g., lab, outpatient) were partial or delayed.
            </p>

            <div className="grid md:grid-cols-2 gap-4 text-sm text-gray-300">
              <div>
                <strong>Symptoms</strong>
                <ul className="mt-2 space-y-2 list-disc list-inside">
                  <li>Revenue down 8% month-on-month in elective procedures</li>
                  <li>Inconsistent encounter counts between EHR and billing</li>
                  <li>Delayed lab and PACS feeds causing incomplete cohorts</li>
                </ul>
              </div>

              <div>
                <strong>Constraints</strong>
                <ul className="mt-2 space-y-2 list-disc list-inside">
                  <li>Regulatory & payer compliance required for audits</li>
                  <li>No risky wide joins across sensitive PHI without controls</li>
                  <li>Need reproducible, auditable query plans and explanations</li>
                </ul>
              </div>
            </div>
          </Card>
        </div>
      </section>

      {/* Technical approach (Intent → Semantics → Verification → Execution → Explanation) */}
      <section className="py-12">
        <div className="container mx-auto px-6 max-w-6xl">
          <h2 className="text-2xl text-[#60a5fa] font-light mb-4">Technical approach</h2>

          <div className="space-y-6">
            <Card className="bg-[#071021] border-white/6 p-6">
              <h3 className="text-lg text-[#60a5fa] mb-2">1. Intent capture (diagnostic)</h3>
              <p className="text-gray-300 text-sm">
                We classify the user's question as diagnostic (causal) rather than an aggregation. This changes
                downstream logic: the planner avoids naive aggregations and instead reasons about segments, baselines,
                and required evidence to support causal claims.
              </p>
            </Card>

            <Card className="bg-[#071021] border-white/6 p-6">
              <h3 className="text-lg text-[#60a5fa] mb-2">2. Semantic grounding</h3>
              <p className="text-gray-300 text-sm">
                Map natural-language entities (e.g., "revenue", "elective procedures", "site X") to canonical
                tables, columns, and glossary terms. Use column lineage and historical validated queries to avoid
                ambiguous mappings.
              </p>
            </Card>

            <Card className="bg-[#071021] border-white/6 p-6">
              <h3 className="text-lg text-[#60a5fa] mb-2">3. Safe query planning & verification</h3>
              <p className="text-gray-300 text-sm">
                The planner decomposes analysis into sub-queries, estimates cost, computes blast radius, and consults
                DataSentinel signals for data completeness and trust. High-risk plans (wide cross-facility joins,
                cross-PHI joins) are flagged and either rewritten into safe alternatives or require explicit approval.
              </p>
            </Card>

            <Card className="bg-[#071021] border-white/6 p-6">
              <h3 className="text-lg text-[#60a5fa] mb-2">4. Guarded execution & observability</h3>
              <p className="text-gray-300 text-sm">
                Execute with row limits, cost ceilings and timeouts. Every execution records: intent, plan, data sources,
                result shape and trust scores — all available in a searchable execution log for audit and model feedback.
              </p>
            </Card>

            <Card className="bg-[#071021] border-white/6 p-6">
              <h3 className="text-lg text-[#60a5fa] mb-2">5. Explanation & learning loop</h3>
              <p className="text-gray-300 text-sm">
                Return narrative explanations (what changed, what was excluded, alternative interpretations). Confirmed
                corrections (only from authorized reviewers) are used to update metadata and mappings — not to blindy
                retrain models — preserving correctness.
              </p>
            </Card>
          </div>
        </div>
      </section>

      {/* Implementation details (more technical) */}
      <section className="py-12 border-t border-white/6">
        <div className="container mx-auto px-6 max-w-6xl">
          <h2 className="text-2xl text-[#60a5fa] font-light mb-4">Implementation details & integrations</h2>

          <div className="grid md:grid-cols-2 gap-6">
            <Card className="bg-[#071021] border-white/6 p-6">
              <h4 className="text-sm text-[#60a5fa] mb-2">Data sources</h4>
              <ul className="text-gray-300 text-sm space-y-2 list-disc list-inside">
                <li>EHR: encounter, ADT, clinical notes</li>
                <li>Billing: invoices, claim edits, remittance</li>
                <li>Payer feeds: adjudication timing & reason codes</li>
                <li>Operational: OR schedules, staffing, supply usage</li>
              </ul>
            </Card>

            <Card className="bg-[#071021] border-white/6 p-6">
              <h4 className="text-sm text-[#60a5fa] mb-2">Platform & runbook</h4>
              <ul className="text-gray-300 text-sm space-y-2 list-disc list-inside">
                <li>Data ingestion (CDC/ETL) into governed warehouse (Snowflake/Redshift/BigQuery)</li>
                <li>Metadata store with column lineage & business glossary</li>
                <li>Query planner service (stateless) that calls execution engine via API</li>
                <li>Observability: execution log, trust scores, and health dashboards</li>
              </ul>
            </Card>
          </div>

          <div className="mt-6 text-sm text-gray-400">
            <strong>Security & compliance:</strong> PHI is never exfiltrated to third-party LLMs. Any ML that touches PHI
            runs within your VPC on approved runtimes. Audit trails and RBAC are enforced for correction and learning loops.
          </div>
        </div>
      </section>

      {/* Outcomes & impact metrics */}
      <section className="py-12">
        <div className="container mx-auto px-6 max-w-6xl">
          <h2 className="text-2xl text-[#60a5fa] font-light mb-4">Results we delivered (example)</h2>

          <div className="grid md:grid-cols-3 gap-6 mb-6">
            <Card className="bg-[#06131a] border-white/8 p-6">
              <div className="text-2xl font-semibold text-white">+$1.0M</div>
              <div className="text-sm text-gray-300">Recovered revenue identified in Q1 via targeted remediation</div>
            </Card>

            <Card className="bg-[#06131a] border-white/8 p-6">
              <div className="text-2xl font-semibold text-white">35%</div>
              <div className="text-sm text-gray-300">Reduction in under-coding errors after alert workflow</div>
            </Card>

            <Card className="bg-[#06131a] border-white/8 p-6">
              <div className="text-2xl font-semibold text-white">24 hrs → realtime</div>
              <div className="text-sm text-gray-300">From delayed batch checks to near real-time diagnostic monitoring</div>
            </Card>
          </div>

          <p className="text-gray-300 text-sm">
            These numbers are illustrative: actual impact depends on data maturity, scope, and remediation workflows.
            We always run a short discovery to produce a realistic estimate before any PoC.
          </p>
        </div>
      </section>

      {/* Cross-link product callouts */}
      <section className="py-12 border-t border-white/6">
        <div className="container mx-auto px-6 max-w-6xl">
          <h2 className="text-2xl text-[#60a5fa] font-light mb-6">Products used</h2>

          <div className="grid md:grid-cols-3 gap-6">
            <Card className="bg-[#071021] border-white/6 p-6">
              <h4 className="text-sm text-[#60a5fa] mb-2">QueryMind</h4>
              <p className="text-gray-300 text-sm mb-3">Intent-first analytics: safe, schema-aware question answering and automatic SQL generation with verification.</p>
              <Link href="/products/querymind" className="text-xs text-[#60a5fa] underline">Open QueryMind →</Link>
            </Card>

            <Card className="bg-[#071021] border-white/6 p-6">
              <h4 className="text-sm text-[#60a5fa] mb-2">DataSentinel</h4>
              <p className="text-gray-300 text-sm mb-3">Continuous data reliability monitoring, trust scoring, and anomaly detection used to gate executions.</p>
              <Link href="/products/datasentinel" className="text-xs text-[#60a5fa] underline">Open DataSentinel →</Link>
            </Card>

            <Card className="bg-[#071021] border-white/6 p-6">
              <h4 className="text-sm text-[#60a5fa] mb-2">RootSense</h4>
              <p className="text-gray-300 text-sm mb-3">Causal and similarity analysis for explainability and runbook recommendations.</p>
              <Link href="/products/rootsense" className="text-xs text-[#60a5fa] underline">Open RootSense →</Link>
            </Card>
          </div>
        </div>
      </section>

      {/* Suggested next steps (engagement model) */}
      <section className="py-12">
        <div className="container mx-auto px-6 max-w-6xl">
          <h2 className="text-2xl text-[#60a5fa] font-light mb-4">How we engage</h2>

          <div className="grid md:grid-cols-3 gap-6">
            <Card className="bg-[#071021] border-white/6 p-6">
              <h5 className="text-sm text-[#60a5fa] mb-2">Discovery (1–2 weeks)</h5>
              <p className="text-gray-300 text-sm">Data mapping, problem scoping, initial ROI estimate, and runbook review.</p>
            </Card>

            <Card className="bg-[#071021] border-white/6 p-6">
              <h5 className="text-sm text-[#60a5fa] mb-2">Rapid PoC (2–4 weeks)</h5>
              <p className="text-gray-300 text-sm">Deliver validated diagnostics and remediation playbooks on a small cohort.</p>
            </Card>

            <Card className="bg-[#071021] border-white/6 p-6">
              <h5 className="text-sm text-[#60a5fa] mb-2">Pilot → Rollout</h5>
              <p className="text-gray-300 text-sm">Scale to additional sites, harden guardrails and handover to operations with SLOs and runbooks.</p>
            </Card>
          </div>
        </div>
      </section>

      {/* Final CTA */}
      <section className="py-16 text-center border-t border-white/6">
        <h3 className="text-xl font-light mb-4">Ready to find hidden revenue without risking patient safety or auditability?</h3>
        <div className="flex items-center justify-center gap-4">
          <Link href="/contact" className="inline-block bg-[#60a5fa] text-black px-6 py-3 rounded-md font-medium">Talk to an Expert</Link>
          <Link href="/products/querymind" className="inline-block border border-white/10 text-gray-300 px-5 py-3 rounded-md">Try QueryMind</Link>
        </div>
      </section>

      {/* Footer (simple) */}
      <footer className="py-10 border-t border-white/8">
        <div className="container mx-auto px-6 text-center text-gray-400">
          <p className="text-sm">© 2025 Nabla-X. Intelligence for regulated systems.</p>
        </div>
      </footer>

      <style jsx>{`
  /* ============================
     INDUSTRY THEME: HEALTHCARE
     ============================ */

  .healthcare-theme {
    --accent-primary: #22c55e;      /* clinical blue */
    --accent-secondary: #22d3ee;    /* diagnostic cyan */
    --accent-soft: #7dd3fc;

    --panel-bg: #071a2e;
    --card-bg: #071021;
    --node-bg: #0f172a;
    --node-alt-bg: #020617;
    --glow: rgba(56, 189, 248, 0.25);
  }

  /* Override existing hardcoded Tailwind colors safely */
  .healthcare-theme .text-\\[\\#60a5fa\\] {
    color: var(--accent-primary);
  }

  .healthcare-theme .bg-\\[\\#60a5fa\\] {
    background-color: var(--accent-primary);
  }

  .healthcare-theme .hover\\:text-\\[\\#60a5fa\\]:hover {
    color: var(--accent-secondary);
  }

  .healthcare-theme .border-\\[\\#60a5fa\\] {
    border-color: var(--accent-primary);
  }

  /* Optional subtle healthcare glow */
  .healthcare-theme svg:hover {
    filter: drop-shadow(0 0 12px var(--glow));
  }

  @media (min-width: 1024px) {
    .container { max-width: 1180px; }
  }
`}</style>
    </div>
  )
}
