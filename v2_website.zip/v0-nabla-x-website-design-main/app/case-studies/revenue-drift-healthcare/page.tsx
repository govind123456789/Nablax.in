"use client"

import Link from "next/link"
import { Card } from "@/components/ui/card"
import { motion } from "framer-motion"
import { Activity, TrendingUp, DollarSign, Clock, CheckCircle2, ArrowRight } from "lucide-react"

export default function RevenueDriftHealthcare() {
  return (
    <div className="min-h-screen bg-black text-white">
      <header className="border-b border-white/10 bg-black/95 backdrop-blur-xl sticky top-0 z-50">
        <div className="container mx-auto px-6 py-5 flex items-center justify-between">
          <Link href="/" className="text-[#d4af37] text-2xl font-semibold tracking-tight">
            Nabla-X
          </Link>
          <nav className="hidden md:flex gap-8 text-sm text-gray-400">
            <Link href="/services" className="hover:text-white transition">
              Services
            </Link>
            <Link href="/case-studies" className="text-white font-medium">
              Case Studies
            </Link>
            <Link href="/contact" className="hover:text-white transition">
              Contact
            </Link>
          </nav>
        </div>
      </header>

      <section className="pt-32 pb-20">
        <div className="container mx-auto px-6 max-w-6xl">
          <div className="flex items-center gap-3 mb-8">
            <span className="px-3 py-1.5 bg-[#d4af37]/10 border border-[#d4af37]/20 rounded-full text-[#d4af37] text-xs font-medium">
              Healthcare
            </span>
            <span className="text-gray-500">·</span>
            <span className="text-gray-400 text-sm">8 minute read</span>
          </div>

          <h1 className="text-5xl md:text-7xl font-bold leading-tight mb-8 text-balance">
            How we recovered
            <span className="text-[#d4af37]"> $1.0M</span> in hidden revenue leakage
          </h1>

          <p className="text-xl text-gray-400 max-w-3xl leading-relaxed mb-12">
            A multi-facility healthcare network used QueryMind and DataSentinel to detect and explain revenue drift
            across billing systems—before it compounded into regulatory exposure.
          </p>

          <div className="flex gap-4">
            <Link
              href="/contact"
              className="bg-[#d4af37] text-black px-8 py-4 rounded-lg font-semibold hover:bg-[#c9a645] transition inline-flex items-center gap-2"
            >
              Discuss Your Environment
              <ArrowRight className="w-5 h-5" />
            </Link>
          </div>
        </div>
      </section>

      <section className="py-20 border-y border-white/10">
        <div className="container mx-auto px-6 max-w-6xl">
          <div className="grid md:grid-cols-3 gap-12">
            <div>
              <div className="text-6xl font-bold text-[#d4af37] mb-3">$1.0M</div>
              <div className="text-gray-400 text-lg">Revenue recovered in Q1</div>
            </div>
            <div>
              <div className="text-6xl font-bold text-[#d4af37] mb-3">35%</div>
              <div className="text-gray-400 text-lg">Reduction in under-coding errors</div>
            </div>
            <div>
              <div className="text-6xl font-bold text-[#d4af37] mb-3">24h → 0</div>
              <div className="text-gray-400 text-lg">Real-time diagnostic monitoring</div>
            </div>
          </div>
        </div>
      </section>

      {/* Healthcare context — deeper details */}
      <section className="py-12">
        <div className="container mx-auto px-6 max-w-6xl">
          <h2 className="text-2xl text-[#60a5fa] font-light mb-4">Healthcare context — why this is hard</h2>

          <div className="grid md:grid-cols-3 gap-6">
            <Card className="bg-[#071021] border-white/6 p-5">
              <h3 className="text-sm text-[#60a5fa] mb-2 font-medium">Fragmented systems</h3>
              <p className="text-gray-300 text-sm">
                Clinical (EHR), billing, lab, PACS, and external payer feeds often disagree on encounters and
                timestamps. Reconciling these reliably requires lineage, mapping, and conservative joins.
              </p>
            </Card>

            <Card className="bg-[#071021] border-white/6 p-5">
              <h3 className="text-sm text-[#60a5fa] mb-2 font-medium">Coding & documentation variability</h3>
              <p className="text-gray-300 text-sm">
                CPT/DRG use differs across facilities and coders. Small documentation differences can produce large
                revenue changes. Detection requires semantic matching across clinical notes and invoice records.
              </p>
            </Card>

            <Card className="bg-[#071021] border-white/6 p-5">
              <h3 className="text-sm text-[#60a5fa] mb-2 font-medium">Payer & contract complexity</h3>
              <p className="text-gray-300 text-sm">
                Different payer contracts apply different remittance rules; revenue shifts may be payer-driven rather
                than clinical. Our solution surfaces payer-driven vs clinical-driven causes.
              </p>
            </Card>
          </div>
        </div>
      </section>

      {/* The problem (detailed) */}
      <section className="py-12 border-t border-white/6">
        <div className="container mx-auto px-6 max-w-6xl">
          <h2 className="text-2xl text-[#60a5fa] font-light mb-4">Problem statement</h2>

          <Card className="bg-[#071021] border-white/6 p-6">
            <p className="text-gray-300 leading-relaxed mb-4">
              Finance noticed recurring drops in revenue for several service lines. Surface-level metrics (totals) were
              available, but leadership needed causality: which service, which site, which documentation gap, and what
              payer behavior caused the change. Analysts were reluctant to run complex joins for fear of producing
              misleading results because some sources (e.g., lab, outpatient) were partial or delayed.
            </p>

            <div className="grid md:grid-cols-2 gap-4 text-sm text-gray-300">
              <div>
                <strong>Symptoms</strong>
                <ul className="mt-2 space-y-2 list-disc list-inside">
                  <li>Revenue down 8% month-on-month in elective procedures</li>
                  <li>Inconsistent encounter counts between EHR and billing</li>
                  <li>Delayed lab and PACS feeds causing incomplete cohorts</li>
                </ul>
              </div>

              <div>
                <strong>Constraints</strong>
                <ul className="mt-2 space-y-2 list-disc list-inside">
                  <li>Regulatory & payer compliance required for audits</li>
                  <li>No risky wide joins across sensitive PHI without controls</li>
                  <li>Need reproducible, auditable query plans and explanations</li>
                </ul>
              </div>
            </div>
          </Card>
        </div>
      </section>

      {/* Technical approach (Intent → Semantics → Verification → Execution → Explanation) */}
      <section className="py-12">
        <div className="container mx-auto px-6 max-w-6xl">
          <h2 className="text-2xl text-[#60a5fa] font-light mb-4">Technical approach</h2>

          <div className="space-y-6">
            <Card className="bg-[#071021] border-white/6 p-6">
              <h3 className="text-lg text-[#60a5fa] mb-2">1. Intent capture (diagnostic)</h3>
              <p className="text-gray-300 text-sm">
                We classify the user's question as diagnostic (causal) rather than an aggregation. This changes
                downstream logic: the planner avoids naive aggregations and instead reasons about segments, baselines,
                and required evidence to support causal claims.
              </p>
            </Card>

            <Card className="bg-[#071021] border-white/6 p-6">
              <h3 className="text-lg text-[#60a5fa] mb-2">2. Semantic grounding</h3>
              <p className="text-gray-300 text-sm">
                Map natural-language entities (e.g., "revenue", "elective procedures", "site X") to canonical tables,
                columns, and glossary terms. Use column lineage and historical validated queries to avoid ambiguous
                mappings.
              </p>
            </Card>

            <Card className="bg-[#071021] border-white/6 p-6">
              <h3 className="text-lg text-[#60a5fa] mb-2">3. Safe query planning & verification</h3>
              <p className="text-gray-300 text-sm">
                The planner decomposes analysis into sub-queries, estimates cost, computes blast radius, and consults
                DataSentinel signals for data completeness and trust. High-risk plans (wide cross-facility joins,
                cross-PHI joins) are flagged and either rewritten into safe alternatives or require explicit approval.
              </p>
            </Card>

            <Card className="bg-[#071021] border-white/6 p-6">
              <h3 className="text-lg text-[#60a5fa] mb-2">4. Guarded execution & observability</h3>
              <p className="text-gray-300 text-sm">
                Execute with row limits, cost ceilings and timeouts. Every execution records: intent, plan, data
                sources, result shape and trust scores — all available in a searchable execution log for audit and model
                feedback.
              </p>
            </Card>

            <Card className="bg-[#071021] border-white/6 p-6">
              <h3 className="text-lg text-[#60a5fa] mb-2">5. Explanation & learning loop</h3>
              <p className="text-gray-300 text-sm">
                Return narrative explanations (what changed, what was excluded, alternative interpretations). Confirmed
                corrections (only from authorized reviewers) are used to update metadata and mappings — not to blindy
                retrain models — preserving correctness.
              </p>
            </Card>
          </div>
        </div>
      </section>

      {/* Implementation details (more technical) */}
      <section className="py-12 border-t border-white/6">
        <div className="container mx-auto px-6 max-w-6xl">
          <h2 className="text-2xl text-[#60a5fa] font-light mb-4">Implementation details & integrations</h2>

          <div className="grid md:grid-cols-2 gap-6">
            <Card className="bg-[#071021] border-white/6 p-6">
              <h4 className="text-sm text-[#60a5fa] mb-2">Data sources</h4>
              <ul className="text-gray-300 text-sm space-y-2 list-disc list-inside">
                <li>EHR: encounter, ADT, clinical notes</li>
                <li>Billing: invoices, claim edits, remittance</li>
                <li>Payer feeds: adjudication timing & reason codes</li>
                <li>Operational: OR schedules, staffing, supply usage</li>
              </ul>
            </Card>

            <Card className="bg-[#071021] border-white/6 p-6">
              <h4 className="text-sm text-[#60a5fa] mb-2">Platform & runbook</h4>
              <ul className="text-gray-300 text-sm space-y-2 list-disc list-inside">
                <li>Data ingestion (CDC/ETL) into governed warehouse (Snowflake/Redshift/BigQuery)</li>
                <li>Metadata store with column lineage & business glossary</li>
                <li>Query planner service (stateless) that calls execution engine via API</li>
                <li>Observability: execution log, trust scores, and health dashboards</li>
              </ul>
            </Card>
          </div>

          <div className="mt-6 text-sm text-gray-400">
            <strong>Security & compliance:</strong> PHI is never exfiltrated to third-party LLMs. Any ML that touches
            PHI runs within your VPC on approved runtimes. Audit trails and RBAC are enforced for correction and
            learning loops.
          </div>
        </div>
      </section>

      <section className="py-20">
        <div className="container mx-auto px-6 max-w-4xl">
          <h2 className="text-sm uppercase tracking-widest text-[#d4af37] mb-6 font-semibold">Client</h2>
          <p className="text-2xl text-gray-300 leading-relaxed">
            Multi-facility healthcare provider network serving 250,000+ patients annually across clinical, billing, lab,
            and payer systems with strict HIPAA compliance requirements.
          </p>
        </div>
      </section>

      <section className="py-20 bg-gradient-to-b from-black via-[#d4af37]/5 to-black">
        <div className="container mx-auto px-6 max-w-6xl">
          <h2 className="text-4xl font-bold mb-12">The Challenge</h2>

          <div className="grid md:grid-cols-2 gap-8">
            <Card className="bg-white/5 border-white/10 p-8 hover:bg-white/[0.07] transition">
              <Activity className="w-10 h-10 text-[#d4af37] mb-4" />
              <h3 className="text-xl font-semibold mb-3">Fragmented systems</h3>
              <p className="text-gray-400 leading-relaxed">
                EHR, billing, lab, and PACS systems disagreed on encounters and timestamps. Reconciling reliably
                required lineage, mapping, and conservative joins.
              </p>
            </Card>

            <Card className="bg-white/5 border-white/10 p-8 hover:bg-white/[0.07] transition">
              <DollarSign className="w-10 h-10 text-[#d4af37] mb-4" />
              <h3 className="text-xl font-semibold mb-3">Revenue drops</h3>
              <p className="text-gray-400 leading-relaxed">
                8% month-on-month decline in elective procedures revenue with inconsistent encounter counts and
                incomplete cohorts from delayed feeds.
              </p>
            </Card>

            <Card className="bg-white/5 border-white/10 p-8 hover:bg-white/[0.07] transition">
              <TrendingUp className="w-10 h-10 text-[#d4af37] mb-4" />
              <h3 className="text-xl font-semibold mb-3">Coding variability</h3>
              <p className="text-gray-400 leading-relaxed">
                CPT/DRG usage differed across facilities. Small documentation gaps produced large revenue changes
                requiring semantic matching.
              </p>
            </Card>

            <Card className="bg-white/5 border-white/10 p-8 hover:bg-white/[0.07] transition">
              <CheckCircle2 className="w-10 h-10 text-[#d4af37] mb-4" />
              <h3 className="text-xl font-semibold mb-3">Compliance constraints</h3>
              <p className="text-gray-400 leading-relaxed">
                No risky wide joins across sensitive PHI without controls. Required reproducible, auditable query plans
                for regulatory compliance.
              </p>
            </Card>
          </div>
        </div>
      </section>

      <section className="py-20">
        <div className="container mx-auto px-6 max-w-4xl">
          <h2 className="text-4xl font-bold mb-12">Our Solution</h2>

          <div className="space-y-16">
            {[
              {
                step: "01",
                title: "Intent capture",
                desc: "Classify questions as diagnostic (causal) rather than aggregation, changing downstream logic to reason about segments and required evidence.",
              },
              {
                step: "02",
                title: "Semantic grounding",
                desc: "Map natural-language entities to canonical tables using column lineage and historical validated queries to avoid ambiguous mappings.",
              },
              {
                step: "03",
                title: "Safe query planning",
                desc: "Decompose analysis into sub-queries, estimate cost, compute blast radius, and consult DataSentinel for completeness and trust.",
              },
              {
                step: "04",
                title: "Guarded execution",
                desc: "Execute with row limits, cost ceilings and timeouts. Record intent, plan, data sources, and trust scores for audit trails.",
              },
              {
                step: "05",
                title: "Explanation loop",
                desc: "Return narrative explanations with confirmed corrections used to update metadata—preserving correctness over blind retraining.",
              },
            ].map((item, i) => (
              <motion.div
                key={i}
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ delay: i * 0.1 }}
                className="flex gap-8"
              >
                <div className="text-6xl font-bold text-[#d4af37]/20">{item.step}</div>
                <div className="flex-1 pt-2">
                  <h3 className="text-2xl font-semibold mb-3">{item.title}</h3>
                  <p className="text-gray-400 text-lg leading-relaxed">{item.desc}</p>
                </div>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      <section className="py-20 border-t border-white/10">
        <div className="container mx-auto px-6 max-w-6xl">
          <h2 className="text-4xl font-bold mb-16 text-center">Results</h2>

          <div className="grid md:grid-cols-3 gap-8 mb-16">
            <Card className="bg-gradient-to-br from-[#d4af37]/10 to-transparent border-[#d4af37]/20 p-8">
              <TrendingUp className="w-8 h-8 text-[#d4af37] mb-4" />
              <div className="text-4xl font-bold mb-2">$1.0M</div>
              <div className="text-gray-400">Recovered revenue via targeted remediation</div>
            </Card>

            <Card className="bg-gradient-to-br from-[#d4af37]/10 to-transparent border-[#d4af37]/20 p-8">
              <Clock className="w-8 h-8 text-[#d4af37] mb-4" />
              <div className="text-4xl font-bold mb-2">Real-time</div>
              <div className="text-gray-400">From 24hr delays to instant diagnostics</div>
            </Card>

            <Card className="bg-gradient-to-br from-[#d4af37]/10 to-transparent border-[#d4af37]/20 p-8">
              <CheckCircle2 className="w-8 h-8 text-[#d4af37] mb-4" />
              <div className="text-4xl font-bold mb-2">35%</div>
              <div className="text-gray-400">Reduction in under-coding errors</div>
            </Card>
          </div>

          <Card className="bg-white/5 border-white/10 p-8">
            <p className="text-gray-400 leading-relaxed">
              These numbers reflect actual impact from a 3-month deployment. Results depend on data maturity, scope, and
              remediation workflows. We always run discovery to produce realistic estimates before any PoC.
            </p>
          </Card>
        </div>
      </section>

      <section className="py-20 bg-gradient-to-b from-black via-[#d4af37]/5 to-black">
        <div className="container mx-auto px-6 max-w-6xl">
          <h2 className="text-4xl font-bold mb-12">Technology Stack</h2>

          <div className="grid md:grid-cols-3 gap-8">
            {[
              {
                name: "QueryMind",
                desc: "Intent-first analytics with safe, schema-aware SQL generation",
                link: "/products/querymind",
              },
              {
                name: "DataSentinel",
                desc: "Continuous data reliability monitoring and trust scoring",
                link: "/products/datasentinel",
              },
              {
                name: "RootSense",
                desc: "Causal analysis for explainability and recommendations",
                link: "/products/rootsense",
              },
            ].map((product, i) => (
              <Link key={i} href={product.link}>
                <Card className="bg-white/5 border-white/10 p-8 hover:bg-white/[0.07] hover:border-[#d4af37]/30 transition h-full">
                  <h3 className="text-xl font-semibold mb-3 text-[#d4af37]">{product.name}</h3>
                  <p className="text-gray-400 leading-relaxed mb-4">{product.desc}</p>
                  <div className="text-sm text-[#d4af37] inline-flex items-center gap-2">
                    Learn more <ArrowRight className="w-4 h-4" />
                  </div>
                </Card>
              </Link>
            ))}
          </div>
        </div>
      </section>

      <section className="py-32">
        <div className="container mx-auto px-6 max-w-4xl text-center">
          <h2 className="text-4xl md:text-5xl font-bold mb-6">Ready to prevent revenue leakage?</h2>
          <p className="text-xl text-gray-400 mb-12 max-w-2xl mx-auto">
            Let's discuss how Nabla-X can help you detect and explain hidden patterns in your healthcare data.
          </p>
          <div className="flex gap-4 justify-center">
            <Link
              href="/contact"
              className="bg-[#d4af37] text-black px-8 py-4 rounded-lg font-semibold hover:bg-[#c9a645] transition"
            >
              Schedule Architecture Review
            </Link>
            <Link
              href="/case-studies"
              className="border border-white/20 px-8 py-4 rounded-lg hover:border-white/40 transition"
            >
              View All Case Studies
            </Link>
          </div>
        </div>
      </section>

      <footer className="py-12 border-t border-white/10 text-center text-gray-500 text-sm">
        © 2025 Nabla-X. Production-grade AI observability for regulated environments.
      </footer>
    </div>
  )
}
