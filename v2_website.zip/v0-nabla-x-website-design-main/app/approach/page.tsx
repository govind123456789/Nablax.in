export default function ApproachPage() {
  return (
    <main className="min-h-screen px-6 py-24 max-w-6xl mx-auto">
      {/* Hero */}
      <section className="text-center mb-24">
        <h1 className="text-4xl md:text-5xl font-semibold text-white mb-6">
          How We Build Trustworthy AI
        </h1>
        <p className="text-lg text-neutral-400 max-w-3xl mx-auto">
          At Nabla-X, intelligence starts with decisions, not models. We design
          AI systems that are explainable, resilient, and safe to operate in
          complex, regulated environments.
        </p>
      </section>

      {/* Principles */}
      <section className="grid md:grid-cols-3 gap-8 mb-24">
        {[
          {
            title: "Decision-First",
            desc: "We begin with the decision that needs improvement — not the algorithm."
          },
          {
            title: "System-Aware",
            desc: "We model full data and decision systems, not isolated pipelines."
          },
          {
            title: "Trust by Design",
            desc: "Explainability, monitoring, and governance are built in from day one."
          }
        ].map((item) => (
          <div
            key={item.title}
            className="border border-neutral-800 rounded-xl p-6 bg-neutral-950"
          >
            <h3 className="text-xl font-medium text-white mb-2">
              {item.title}
            </h3>
            <p className="text-neutral-400">{item.desc}</p>
          </div>
        ))}
      </section>

      {/* System Thinking */}
      <section className="mb-24">
        <h2 className="text-3xl font-semibold text-white mb-6">
          System-Level Thinking
        </h2>
        <p className="text-neutral-400 mb-6 max-w-4xl">
          Most AI failures happen at system boundaries — between APIs,
          pipelines, models, and decision-makers. We design across the entire
          lifecycle.
        </p>
        <div className="border border-neutral-800 rounded-xl p-6 bg-neutral-950 text-neutral-300">
          Data Sources → Pipelines → Intelligence → Decisions → Monitoring.
        </div>
      </section>

      {/* Delivery */}
      <section>
        <h2 className="text-3xl font-semibold text-white mb-6">
          From Pilot to Production
        </h2>
        <ul className="space-y-4 text-neutral-400">
          <li>• Rapid feasibility and risk assessment</li>
          <li>• Explainable intelligence deployment</li>
          <li>• Continuous monitoring and drift detection</li>
          <li>• Human-in-the-loop decision control</li>
        </ul>
      </section>
    </main>
  );
}
