"use client"

import { motion } from "framer-motion"
import { Button } from "@/components/ui/button"
import { Card } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { ArrowRight, Brain, Cpu, CheckCircle2, Sparkles, GitBranch, Database } from "lucide-react"
import Link from "next/link"

export default function AIMLEngineeringPage() {
  return (
    <div className="min-h-screen bg-black text-white">
      {/* Hero Section */}
      <section className="relative py-32 overflow-hidden">
        <div className="absolute inset-0 bg-gradient-to-b from-[#d4af37]/5 via-transparent to-transparent" />

        <div className="container mx-auto px-6 max-w-6xl relative z-10">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6 }}
            className="text-center"
          >
            <div className="inline-flex items-center gap-2 px-4 py-2 rounded-full bg-[#d4af37]/10 border border-[#d4af37]/30 mb-6">
              <Sparkles className="w-4 h-4 text-[#d4af37]" />
              <span className="text-sm text-[#d4af37] font-medium">Enterprise AI/ML Engineering</span>
            </div>

            <h1 className="text-6xl md:text-7xl font-light mb-6 leading-tight">
              Build intelligent systems
              <br />
              <span className="text-[#d4af37]">that scale</span>
            </h1>

            <p className="text-xl text-gray-400 max-w-3xl mx-auto mb-12 leading-relaxed">
              From custom machine learning models to LLM integrations and intelligent automation—we deliver
              production-grade AI solutions that solve real business problems.
            </p>

            <div className="flex flex-wrap gap-4 justify-center">
              <Link href="/contact">
                <Button className="bg-[#d4af37] text-black hover:bg-[#c4a037] px-8 py-6 text-lg">
                  Start a Project
                  <ArrowRight className="w-5 h-5 ml-2" />
                </Button>
              </Link>
              <Link href="/demo">
                <Button
                  variant="outline"
                  className="border-[#d4af37]/30 text-[#d4af37] hover:bg-[#d4af37]/10 px-8 py-6 text-lg bg-transparent"
                >
                  View Demos
                </Button>
              </Link>
            </div>
          </motion.div>
        </div>
      </section>

      {/* Capabilities Grid */}
      <section className="py-24 border-t border-[#d4af37]/10">
        <div className="container mx-auto px-6 max-w-6xl">
          <motion.div
            initial={{ opacity: 0 }}
            whileInView={{ opacity: 1 }}
            viewport={{ once: true }}
            className="text-center mb-16"
          >
            <h2 className="text-5xl font-light mb-4">
              Our <span className="text-[#d4af37]">capabilities</span>
            </h2>
            <p className="text-gray-400 text-lg">Comprehensive AI/ML services from research to production deployment</p>
          </motion.div>

          <div className="grid md:grid-cols-2 gap-6">
            {[
              {
                icon: Brain,
                title: "Custom ML Model Development",
                desc: "Design, train, and optimize machine learning models tailored to your specific use case—from classical ML to deep learning architectures.",
                features: [
                  "Classification & regression models",
                  "Computer vision & image processing",
                  "Natural language processing",
                  "Time series forecasting",
                  "Anomaly detection systems",
                ],
              },
              {
                icon: Cpu,
                title: "LLM & RAG Systems",
                desc: "Build intelligent applications powered by large language models with retrieval-augmented generation for grounded, accurate responses.",
                features: [
                  "GPT/Claude integration & fine-tuning",
                  "Vector database architecture",
                  "Semantic search implementation",
                  "Custom RAG pipelines",
                  "Prompt engineering & optimization",
                ],
              },
              {
                icon: GitBranch,
                title: "MLOps & Model Deployment",
                desc: "Production-ready infrastructure for continuous model training, monitoring, and deployment with automated CI/CD pipelines.",
                features: [
                  "Automated training pipelines",
                  "Model versioning & registry",
                  "A/B testing frameworks",
                  "Performance monitoring",
                  "Automated retraining systems",
                ],
              },
              {
                icon: Database,
                title: "Data Pipeline Engineering",
                desc: "Build robust data pipelines that collect, clean, transform, and deliver high-quality training data at scale.",
                features: [
                  "Feature engineering pipelines",
                  "Real-time data processing",
                  "Data quality validation",
                  "Distributed computing (Spark)",
                  "Data versioning & lineage",
                ],
              },
            ].map((capability, i) => (
              <motion.div
                key={i}
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ delay: i * 0.1 }}
              >
                <Card className="bg-[#0a0a0a] border-[#d4af37]/20 hover:border-[#d4af37]/50 p-8 h-full transition-all duration-300 group">
                  <div className="p-3 rounded-xl bg-[#d4af37]/10 w-fit mb-6 group-hover:scale-110 transition-transform">
                    <capability.icon className="w-7 h-7 text-[#d4af37]" />
                  </div>

                  <h3 className="text-2xl text-white mb-3 font-light">{capability.title}</h3>
                  <p className="text-gray-400 leading-relaxed mb-6">{capability.desc}</p>

                  <div className="space-y-2.5">
                    {capability.features.map((feature, idx) => (
                      <div key={idx} className="flex items-start gap-3">
                        <CheckCircle2 className="w-4 h-4 text-[#d4af37] flex-shrink-0 mt-1" />
                        <span className="text-sm text-gray-300">{feature}</span>
                      </div>
                    ))}
                  </div>
                </Card>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* Technology Stack */}
      <section className="py-24 border-t border-[#d4af37]/10 bg-gradient-to-b from-transparent to-[#d4af37]/5">
        <div className="container mx-auto px-6 max-w-6xl">
          <motion.div
            initial={{ opacity: 0 }}
            whileInView={{ opacity: 1 }}
            viewport={{ once: true }}
            className="text-center mb-16"
          >
            <h2 className="text-5xl font-light mb-4">
              Technology <span className="text-[#d4af37]">stack</span>
            </h2>
            <p className="text-gray-400 text-lg">Industry-leading tools and frameworks for robust AI solutions</p>
          </motion.div>

          <div className="grid sm:grid-cols-2 md:grid-cols-4 gap-8">
            {[
              { category: "Frameworks", items: ["PyTorch", "TensorFlow", "JAX", "Scikit-learn", "Hugging Face"] },
              { category: "LLM & AI", items: ["OpenAI GPT", "Claude", "LangChain", "LlamaIndex", "Pinecone"] },
              { category: "MLOps", items: ["MLflow", "Weights & Biases", "Kubeflow", "Docker", "Kubernetes"] },
              { category: "Data", items: ["Pandas", "Polars", "Apache Spark", "DuckDB", "PostgreSQL"] },
            ].map((stack, i) => (
              <motion.div
                key={i}
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ delay: i * 0.1 }}
              >
                <h3 className="text-[#d4af37] font-medium mb-4 text-lg">{stack.category}</h3>
                <div className="space-y-2">
                  {stack.items.map((item, idx) => (
                    <Badge
                      key={idx}
                      variant="outline"
                      className="border-[#d4af37]/30 text-gray-300 hover:border-[#d4af37] hover:bg-[#d4af37]/10 mr-2 mb-2 transition-colors"
                    >
                      {item}
                    </Badge>
                  ))}
                </div>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* Process */}
      <section className="py-24 border-t border-[#d4af37]/10">
        <div className="container mx-auto px-6 max-w-6xl">
          <motion.div
            initial={{ opacity: 0 }}
            whileInView={{ opacity: 1 }}
            viewport={{ once: true }}
            className="text-center mb-16"
          >
            <h2 className="text-5xl font-light mb-4">
              Our <span className="text-[#d4af37]">process</span>
            </h2>
            <p className="text-gray-400 text-lg">From discovery to production—systematic approach to AI success</p>
          </motion.div>

          <div className="grid md:grid-cols-4 gap-8">
            {[
              {
                step: "01",
                title: "Discovery & Research",
                desc: "Understand your business problem, analyze data availability, and define success metrics.",
              },
              {
                step: "02",
                title: "Experimentation",
                desc: "Rapid prototyping, model selection, baseline establishment, and feasibility validation.",
              },
              {
                step: "03",
                title: "Development",
                desc: "Production-grade implementation with rigorous testing, optimization, and documentation.",
              },
              {
                step: "04",
                title: "Deployment & Monitoring",
                desc: "Continuous delivery, performance monitoring, and ongoing improvement cycles.",
              },
            ].map((phase, i) => (
              <motion.div
                key={i}
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ delay: i * 0.1 }}
                className="relative"
              >
                <div className="text-6xl font-light text-[#d4af37]/20 mb-4">{phase.step}</div>
                <h3 className="text-xl text-white mb-3 font-light">{phase.title}</h3>
                <p className="text-gray-400 text-sm leading-relaxed">{phase.desc}</p>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-24 border-t border-[#d4af37]/10">
        <div className="container mx-auto px-6 max-w-4xl text-center">
          <motion.div initial={{ opacity: 0, y: 20 }} whileInView={{ opacity: 1, y: 0 }} viewport={{ once: true }}>
            <h2 className="text-5xl font-light mb-6">
              Ready to build intelligent <span className="text-[#d4af37]">solutions?</span>
            </h2>
            <p className="text-gray-400 text-lg mb-12 max-w-2xl mx-auto">
              Let's discuss how AI/ML can transform your business. Schedule a consultation with our engineering team.
            </p>
            <Link href="/contact">
              <Button className="bg-[#d4af37] text-black hover:bg-[#c4a037] px-10 py-7 text-lg">
                Get Started
                <ArrowRight className="w-5 h-5 ml-2" />
              </Button>
            </Link>
          </motion.div>
        </div>
      </section>
    </div>
  )
}
