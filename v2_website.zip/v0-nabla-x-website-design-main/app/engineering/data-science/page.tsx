"use client"

import { motion } from "framer-motion"
import { Button } from "@/components/ui/button"
import { Card } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { ArrowRight, TrendingUp, BarChart3, Lightbulb, CheckCircle2, Target, Brain } from "lucide-react"
import Link from "next/link"

export default function DataSciencePage() {
  return (
    <div className="min-h-screen bg-black text-white">
      {/* Hero Section */}
      <section className="relative py-32 overflow-hidden">
        <div className="absolute inset-0 bg-gradient-to-b from-[#d4af37]/5 via-transparent to-transparent" />

        <div className="container mx-auto px-6 max-w-6xl relative z-10">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6 }}
            className="text-center"
          >
            <div className="inline-flex items-center gap-2 px-4 py-2 rounded-full bg-[#d4af37]/10 border border-[#d4af37]/30 mb-6">
              <TrendingUp className="w-4 h-4 text-[#d4af37]" />
              <span className="text-sm text-[#d4af37] font-medium">Data Analysis & Data Science</span>
            </div>

            <h1 className="text-6xl md:text-7xl font-light mb-6 leading-tight">
              Turn data into decisions
              <br />
              <span className="text-[#d4af37]">with confidence</span>
            </h1>

            <p className="text-xl text-gray-400 max-w-3xl mx-auto mb-12 leading-relaxed">
              Advanced statistical analysis, predictive modeling, and business intelligence to unlock insights and drive
              data-informed strategic decisions.
            </p>

            <div className="flex flex-wrap gap-4 justify-center">
              <Link href="/contact">
                <Button className="bg-[#d4af37] text-black hover:bg-[#c4a037] px-8 py-6 text-lg">
                  Start a Project
                  <ArrowRight className="w-5 h-5 ml-2" />
                </Button>
              </Link>
              <Link href="/demo">
                <Button
                  variant="outline"
                  className="border-[#d4af37]/30 text-[#d4af37] hover:bg-[#d4af37]/10 px-8 py-6 text-lg bg-transparent"
                >
                  View Demos
                </Button>
              </Link>
            </div>
          </motion.div>
        </div>
      </section>

      {/* Capabilities Grid */}
      <section className="py-24 border-t border-[#d4af37]/10">
        <div className="container mx-auto px-6 max-w-6xl">
          <motion.div
            initial={{ opacity: 0 }}
            whileInView={{ opacity: 1 }}
            viewport={{ once: true }}
            className="text-center mb-16"
          >
            <h2 className="text-5xl font-light mb-4">
              Our <span className="text-[#d4af37]">capabilities</span>
            </h2>
            <p className="text-gray-400 text-lg">Comprehensive data science services from exploration to prediction</p>
          </motion.div>

          <div className="grid md:grid-cols-2 gap-6">
            {[
              {
                icon: Lightbulb,
                title: "Exploratory Data Analysis",
                desc: "Deep dive into your data to uncover patterns, anomalies, and relationships that inform strategic decisions.",
                features: [
                  "Statistical profiling & distribution analysis",
                  "Correlation & dependency detection",
                  "Data quality assessment",
                  "Visualization & storytelling",
                  "Hypothesis generation",
                ],
              },
              {
                icon: Brain,
                title: "Predictive Modeling & Forecasting",
                desc: "Build statistical and machine learning models that predict future outcomes with quantified uncertainty.",
                features: [
                  "Time series forecasting (ARIMA, Prophet)",
                  "Regression & classification models",
                  "Customer churn prediction",
                  "Demand forecasting",
                  "Risk scoring & credit models",
                ],
              },
              {
                icon: BarChart3,
                title: "Business Intelligence Dashboards",
                desc: "Create compelling, interactive dashboards that democratize data access and empower self-service analytics.",
                features: [
                  "KPI tracking & monitoring",
                  "Executive reporting",
                  "Interactive visualizations",
                  "Automated email reports",
                  "Mobile-responsive design",
                ],
              },
              {
                icon: Target,
                title: "A/B Testing & Experimentation",
                desc: "Design, run, and analyze experiments to validate hypotheses and optimize product features, marketing campaigns, and UX.",
                features: [
                  "Experiment design & power analysis",
                  "Statistical significance testing",
                  "Multi-variant testing (MVT)",
                  "Bayesian A/B testing",
                  "Causal inference analysis",
                ],
              },
            ].map((capability, i) => (
              <motion.div
                key={i}
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ delay: i * 0.1 }}
              >
                <Card className="bg-[#0a0a0a] border-[#d4af37]/20 hover:border-[#d4af37]/50 p-8 h-full transition-all duration-300 group">
                  <div className="p-3 rounded-xl bg-[#d4af37]/10 w-fit mb-6 group-hover:scale-110 transition-transform">
                    <capability.icon className="w-7 h-7 text-[#d4af37]" />
                  </div>

                  <h3 className="text-2xl text-white mb-3 font-light">{capability.title}</h3>
                  <p className="text-gray-400 leading-relaxed mb-6">{capability.desc}</p>

                  <div className="space-y-2.5">
                    {capability.features.map((feature, idx) => (
                      <div key={idx} className="flex items-start gap-3">
                        <CheckCircle2 className="w-4 h-4 text-[#d4af37] flex-shrink-0 mt-1" />
                        <span className="text-sm text-gray-300">{feature}</span>
                      </div>
                    ))}
                  </div>
                </Card>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* Technology Stack */}
      <section className="py-24 border-t border-[#d4af37]/10 bg-gradient-to-b from-transparent to-[#d4af37]/5">
        <div className="container mx-auto px-6 max-w-6xl">
          <motion.div
            initial={{ opacity: 0 }}
            whileInView={{ opacity: 1 }}
            viewport={{ once: true }}
            className="text-center mb-16"
          >
            <h2 className="text-5xl font-light mb-4">
              Technology <span className="text-[#d4af37]">stack</span>
            </h2>
            <p className="text-gray-400 text-lg">Industry-standard tools for data analysis and visualization</p>
          </motion.div>

          <div className="grid sm:grid-cols-2 md:grid-cols-4 gap-8">
            {[
              { category: "Analysis", items: ["Python", "R", "SQL", "Pandas", "NumPy"] },
              { category: "Statistics", items: ["SciPy", "Statsmodels", "scikit-learn", "Prophet", "PyMC"] },
              { category: "Visualization", items: ["Matplotlib", "Seaborn", "Plotly", "Tableau", "Power BI"] },
              { category: "Notebooks", items: ["Jupyter", "Google Colab", "Databricks", "Hex", "Observable"] },
            ].map((stack, i) => (
              <motion.div
                key={i}
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ delay: i * 0.1 }}
              >
                <h3 className="text-[#d4af37] font-medium mb-4 text-lg">{stack.category}</h3>
                <div className="space-y-2">
                  {stack.items.map((item, idx) => (
                    <Badge
                      key={idx}
                      variant="outline"
                      className="border-[#d4af37]/30 text-gray-300 hover:border-[#d4af37] hover:bg-[#d4af37]/10 mr-2 mb-2 transition-colors"
                    >
                      {item}
                    </Badge>
                  ))}
                </div>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* Process */}
      <section className="py-24 border-t border-[#d4af37]/10">
        <div className="container mx-auto px-6 max-w-6xl">
          <motion.div
            initial={{ opacity: 0 }}
            whileInView={{ opacity: 1 }}
            viewport={{ once: true }}
            className="text-center mb-16"
          >
            <h2 className="text-5xl font-light mb-4">
              Our <span className="text-[#d4af37]">process</span>
            </h2>
            <p className="text-gray-400 text-lg">Rigorous methodology for data-driven insights</p>
          </motion.div>

          <div className="grid md:grid-cols-4 gap-8">
            {[
              {
                step: "01",
                title: "Problem Framing",
                desc: "Define business questions, success metrics, and analytical approach collaboratively.",
              },
              {
                step: "02",
                title: "Data Exploration",
                desc: "Analyze data quality, distributions, and relationships to understand the landscape.",
              },
              {
                step: "03",
                title: "Modeling & Analysis",
                desc: "Apply statistical methods and ML techniques to extract insights and build models.",
              },
              {
                step: "04",
                title: "Communication & Action",
                desc: "Translate findings into actionable recommendations with clear visualizations.",
              },
            ].map((phase, i) => (
              <motion.div
                key={i}
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ delay: i * 0.1 }}
                className="relative"
              >
                <div className="text-6xl font-light text-[#d4af37]/20 mb-4">{phase.step}</div>
                <h3 className="text-xl text-white mb-3 font-light">{phase.title}</h3>
                <p className="text-gray-400 text-sm leading-relaxed">{phase.desc}</p>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-24 border-t border-[#d4af37]/10">
        <div className="container mx-auto px-6 max-w-4xl text-center">
          <motion.div initial={{ opacity: 0, y: 20 }} whileInView={{ opacity: 1, y: 0 }} viewport={{ once: true }}>
            <h2 className="text-5xl font-light mb-6">
              Ready to unlock <span className="text-[#d4af37]">data-driven insights?</span>
            </h2>
            <p className="text-gray-400 text-lg mb-12 max-w-2xl mx-auto">
              Let's discuss your business questions and design an analytical approach that delivers results.
            </p>
            <Link href="/contact">
              <Button className="bg-[#d4af37] text-black hover:bg-[#c4a037] px-10 py-7 text-lg">
                Get Started
                <ArrowRight className="w-5 h-5 ml-2" />
              </Button>
            </Link>
          </motion.div>
        </div>
      </section>
    </div>
  )
}
