"use client"

import Link from "next/link"
import { Brain, Users, ArrowRight, Zap, Target, Lightbulb, Rocket } from "lucide-react"
import { Card } from "@/components/ui/card"

export default function CareersPage() {
  return (
    <div className="min-h-screen bg-gradient-to-br from-[#0a1f1f] via-[#0f2f2f] to-[#082020] text-[#e0f5f5]">
      {/* Header */}
      <header className="fixed top-0 w-full z-40 border-b border-[#2dd4bf]/20 bg-[#0a1f1f]/80 backdrop-blur-md">
        <nav className="container mx-auto px-6 py-4 flex items-center justify-between">
          <Link href="/" className="flex items-center gap-2 md:gap-3 hover:opacity-80 transition-opacity group">
            <span className="text-2xl md:text-3xl font-light text-[#5eead4] tracking-wider">
              ∇<sup className="text-base md:text-xl animate-x-float inline-block">x</sup>
            </span>
            <span className="text-lg md:text-2xl font-light tracking-wide">
              <span className="text-[#e0f5f5]">Nabla-</span>
              <span className="bg-gradient-to-r from-[#5eead4] via-[#99f6e4] to-[#5eead4] bg-clip-text text-transparent font-medium">
                X
              </span>
            </span>
          </Link>
          <div className="hidden md:flex items-center gap-8">
            <Link href="/about" className="text-sm tracking-wide hover:text-[#5eead4] transition-colors">
              About
            </Link>
            <Link href="/services" className="text-sm tracking-wide hover:text-[#5eead4] transition-colors">
              Services
            </Link>
            <Link href="/contact" className="text-sm tracking-wide hover:text-[#5eead4] transition-colors">
              Contact
            </Link>
          </div>
        </nav>
      </header>

      {/* Animated Background Particles */}
      <div className="particles-container">
        {[...Array(30)].map((_, i) => (
          <div
            key={i}
            className="particle"
            style={{
              left: `${Math.random() * 100}%`,
              top: `${Math.random() * 100}%`,
              animationDelay: `${Math.random() * 3}s`,
              animationDuration: `${3 + Math.random() * 2}s`,
            }}
          />
        ))}
      </div>

      {/* Hero Section */}
      <section className="pt-32 pb-20 container mx-auto px-6 relative">
        <div className="max-w-4xl mx-auto text-center">
          <div className="inline-flex items-center gap-2 px-4 py-2 mb-6 rounded-full bg-[#5eead4]/10 border border-[#5eead4]/30">
            <Zap className="w-4 h-4 text-[#5eead4]" />
            <span className="text-sm text-[#5eead4]">Join Our Team</span>
          </div>
          <h1 className="text-5xl md:text-6xl font-light mb-6 tracking-tight text-balance">
            Build the <span className="text-[#5eead4]">Future of Intelligence</span>
          </h1>
          <p className="text-xl text-[#99f6e4] leading-relaxed text-pretty max-w-2xl mx-auto">
            Work on problems that matter. Build intelligence systems that actually work in the real world.
          </p>
        </div>
      </section>

      {/* Open Positions */}
      <section className="py-20 container mx-auto px-6">
        <div className="max-w-4xl mx-auto">
          <h2 className="text-4xl font-light mb-12 text-center text-[#5eead4]">Open Positions</h2>

          <div className="space-y-6">
            {/* Research/AI Engineer */}
            <Card className="bg-[#0f2f2f]/50 border-[#2dd4bf]/30 hover:border-[#5eead4] transition-all p-8 backdrop-blur-sm group">
              <div className="flex items-start justify-between gap-6">
                <div className="flex-1">
                  <div className="flex items-center gap-3 mb-4">
                    <div className="p-3 rounded-full bg-[#5eead4]/10">
                      <Brain className="w-6 h-6 text-[#5eead4]" />
                    </div>
                    <h3 className="text-2xl font-light text-[#5eead4]">Research / AI Engineer</h3>
                  </div>

                  <p className="text-[#99f6e4] mb-4 leading-relaxed">
                    Build and refine intelligent systems that solve real problems in healthcare, finance, and research
                    domains.
                  </p>

                  <div className="mb-4">
                    <h4 className="text-sm font-light text-[#5eead4] mb-2">What We're Looking For</h4>
                    <ul className="space-y-2 text-[#99f6e4] text-sm">
                      <li className="flex items-start gap-2">
                        <span className="text-[#5eead4] mt-1">→</span>
                        <span>Strong problem-solving approach and analytical thinking</span>
                      </li>
                      <li className="flex items-start gap-2">
                        <span className="text-[#5eead4] mt-1">→</span>
                        <span>Ready to adapt and learn new technologies quickly</span>
                      </li>
                      <li className="flex items-start gap-2">
                        <span className="text-[#5eead4] mt-1">→</span>
                        <span>Passion for understanding complex systems</span>
                      </li>
                    </ul>
                  </div>
                </div>

                <Link
                  href="/contact"
                  className="flex-shrink-0 p-3 rounded-full bg-[#5eead4]/10 hover:bg-[#5eead4]/20 transition-all group-hover:translate-x-1"
                >
                  <ArrowRight className="w-5 h-5 text-[#5eead4]" />
                </Link>
              </div>
            </Card>

            {/* Partner Consultant */}
            <Card className="bg-[#0f2f2f]/50 border-[#2dd4bf]/30 hover:border-[#5eead4] transition-all p-8 backdrop-blur-sm group">
              <div className="flex items-start gap-6">
                <div className="flex-1">
                  <div className="flex items-center gap-3 mb-4">
                    <div className="p-3 rounded-full bg-[#5eead4]/10">
                      <Users className="w-6 h-6 text-[#5eead4]" />
                    </div>
                    <h3 className="text-2xl font-light text-[#5eead4]">Partner Consultant</h3>
                  </div>

                  <p className="text-[#99f6e4] mb-4 leading-relaxed">
                    Bridge the gap between technology and business. Help clients understand and adopt AI solutions that
                    transform their operations.
                  </p>

                  <div className="mb-4">
                    <h4 className="text-sm font-light text-[#5eead4] mb-2">What We're Looking For</h4>
                    <ul className="space-y-2 text-[#99f6e4] text-sm">
                      <li className="flex items-start gap-2">
                        <span className="text-[#5eead4] mt-1">→</span>
                        <span>Excellent communication and presentation skills</span>
                      </li>
                      <li className="flex items-start gap-2">
                        <span className="text-[#5eead4] mt-1">→</span>
                        <span>Genuine passion for technology and its applications</span>
                      </li>
                      <li className="flex items-start gap-2">
                        <span className="text-[#5eead4] mt-1">→</span>
                        <span>Ability to translate complex technical concepts for diverse audiences</span>
                      </li>
                    </ul>
                  </div>
                </div>

                <Link
                  href="/contact"
                  className="flex-shrink-0 p-3 rounded-full bg-[#5eead4]/10 hover:bg-[#5eead4]/20 transition-all group-hover:translate-x-1"
                >
                  <ArrowRight className="w-5 h-5 text-[#5eead4]" />
                </Link>
              </div>
            </Card>
          </div>
        </div>
      </section>

      {/* Why Join Nabla-X */}
      <section className="py-20 bg-[#0a1f1f]/50 border-y border-[#2dd4bf]/20">
        <div className="container mx-auto px-6">
          <div className="max-w-4xl mx-auto">
            <h2 className="text-3xl font-light mb-10 text-center text-[#5eead4]">Why Join Nabla-X</h2>

            <div className="grid md:grid-cols-2 gap-6">
              <Card className="bg-[#0f2f2f]/50 border-[#2dd4bf]/30 p-6 backdrop-blur-sm">
                <Target className="w-8 h-8 text-[#5eead4] mb-3" />
                <h3 className="text-lg font-light mb-3 text-[#5eead4]">Real Problems</h3>
                <p className="text-[#99f6e4] text-sm">
                  Work on challenges that matter in healthcare, finance, and research, not just vanity projects.
                </p>
              </Card>

              <Card className="bg-[#0f2f2f]/50 border-[#2dd4bf]/30 p-6 backdrop-blur-sm">
                <Zap className="w-8 h-8 text-[#5eead4] mb-3" />
                <h3 className="text-lg font-light mb-3 text-[#5eead4]">Deep Work</h3>
                <p className="text-[#99f6e4] text-sm">
                  Focus on rigorous, meaningful work without the noise of typical corporate environments.
                </p>
              </Card>

              <Card className="bg-[#0f2f2f]/50 border-[#2dd4bf]/30 p-6 backdrop-blur-sm">
                <Lightbulb className="w-8 h-8 text-[#5eead4] mb-3" />
                <h3 className="text-lg font-light mb-3 text-[#5eead4]">Learning Culture</h3>
                <p className="text-[#99f6e4] text-sm">
                  Continuous exposure to new technologies, methods, and domains with mentorship from experienced
                  practitioners.
                </p>
              </Card>

              <Card className="bg-[#0f2f2f]/50 border-[#2dd4bf]/30 p-6 backdrop-blur-sm">
                <Rocket className="w-8 h-8 text-[#5eead4] mb-3" />
                <h3 className="text-lg font-light mb-3 text-[#5eead4]">Impact</h3>
                <p className="text-[#99f6e4] text-sm">
                  See your work deployed in production systems that make real decisions and drive real outcomes.
                </p>
              </Card>
            </div>
          </div>
        </div>
      </section>

      {/* Apply CTA */}
      <section className="py-20 container mx-auto px-6">
        <div className="max-w-2xl mx-auto text-center">
          <h2 className="text-3xl font-light mb-6 text-[#5eead4]">Ready to Apply?</h2>
          <p className="text-[#99f6e4] mb-8 leading-relaxed">
            Send us your CV and a brief note about what problems you're excited to solve.
          </p>
          <Link
            href="/contact"
            className="inline-flex items-center gap-2 px-8 py-4 bg-[#5eead4]/10 border border-[#5eead4] text-[#5eead4] rounded hover:bg-[#5eead4]/20 transition-all"
          >
            <span>Get in Touch</span>
            <ArrowRight className="w-4 h-4" />
          </Link>
        </div>
      </section>

      {/* Footer */}
      <footer className="py-12 border-t border-[#2dd4bf]/20">
        <div className="container mx-auto px-6 text-center text-[#99f6e4]">
          <p className="text-sm">&copy; 2025 Nabla-X. Let's build something meaningful.</p>
        </div>
      </footer>

      <style jsx>{`
        .particles-container {
          position: fixed;
          top: 0;
          left: 0;
          width: 100%;
          height: 100%;
          pointer-events: none;
          z-index: 0;
        }

        .particle {
          position: absolute;
          width: 3px;
          height: 3px;
          background: #5eead4;
          border-radius: 50%;
          animation: float 5s ease-in-out infinite;
          opacity: 0.4;
        }

        @keyframes float {
          0%,
          100% {
            transform: translateY(0) translateX(0);
            opacity: 0.4;
          }
          50% {
            transform: translateY(-20px) translateX(10px);
            opacity: 0.8;
          }
        }

        @keyframes x-float {
          0%,
          100% {
            transform: translateY(0);
          }
          50% {
            transform: translateY(-5px);
          }
        }

        .animate-x-float {
          animation: x-float 3s ease-in-out infinite;
          display: inline-block;
        }
      `}</style>
    </div>
  )
}
