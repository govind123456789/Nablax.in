"use client"

import Link from "next/link"
import { MessageSquare, ArrowRight, Sparkles, BarChart3, Code } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Card } from "@/components/ui/card"

import QueryMindDeepDive from "@/components/querymind/QueryMindDeepDive"
import SemanticCoreExpansion from "@/components/querymind/SemanticCoreExpansion"
import QueryMindArchitectureDiagram from "@/components/querymind/QueryMindArchitectureDiagram"
import QueryMindGuardrails from "@/components/querymind/QueryMindGuardrails"


export default function QueryMindPage() {
  return (
    <div className="min-h-screen bg-gradient-to-br from-[#0a0a0f] via-[#0f1622] to-[#0a0a0f] text-[#e8e8e8]">
      {/* Header */}
      <header className="fixed top-0 w-full z-40 border-b border-[#3b82f6]/20 bg-[#0a0a0f]/80 backdrop-blur-md">
        <nav className="container mx-auto px-6 py-4 flex items-center justify-between">
          <Link
            href="/"
            className="text-3xl font-light text-[#3b82f6] tracking-wider hover:opacity-80 transition-opacity"
          >
            ∇<sup className="text-xl animate-x-query inline-block">x</sup>
          </Link>
          <div className="flex items-center gap-8">
            <Link href="/" className="text-sm tracking-wide hover:text-[#3b82f6] transition-colors">
              Home
            </Link>
            <Link href="/about" className="text-sm tracking-wide hover:text-[#3b82f6] transition-colors">
              About
            </Link>
            <Link href="/contact" className="text-sm tracking-wide hover:text-[#3b82f6] transition-colors">
              Contact
            </Link>
          </div>
        </nav>
      </header>

      {/* Hero Section */}
      <section className="pt-32 pb-20 container mx-auto px-6">
        <div className="max-w-4xl mx-auto text-center">
          <div className="mb-8 flex justify-center">
            <div className="p-6 rounded-2xl bg-[#3b82f6]/10 border border-[#3b82f6]/30">
              <MessageSquare className="w-16 h-16 text-[#3b82f6]" />
            </div>
          </div>
          <h1 className="text-6xl md:text-7xl font-light mb-4 tracking-tight text-balance">
            Nabla-X <span className="text-[#3b82f6]">QueryMind</span>
          </h1>
          <p className="text-2xl text-[#3b82f6] mb-6 italic">Ask. Analyze. Understand.</p>
          <p className="text-xl text-[#b8b8b8] mb-12 leading-relaxed max-w-2xl mx-auto text-pretty">
            The AI Analytics Copilot that transforms natural language questions into instant insights, SQL queries, and
            visual analytics.
          </p>
          <Link href="/contact">
            <Button className="bg-[#3b82f6] text-white hover:bg-[#2563eb] px-8 py-6 text-base">
              Request Demo <ArrowRight className="ml-2 w-5 h-5" />
            </Button>
          </Link>
        </div>

        {/* Animated Query Demo */}
        <div className="mt-20 relative">
          <div className="query-animation-bg absolute inset-0 opacity-10"></div>
          <div className="relative">
            <Card className="bg-[#0f1622]/80 border-[#3b82f6]/30 p-8 max-w-3xl mx-auto backdrop-blur-sm">
              <div className="flex items-center gap-3 mb-6">
                <Sparkles className="w-5 h-5 text-[#3b82f6] animate-pulse" />
                <span className="text-sm text-[#3b82f6]">Natural Language Query</span>
              </div>
              <div className="text-lg mb-8 text-[#e8e8e8] typing-animation">
                "Show monthly revenue trends for Q3 with anomaly detection"
              </div>
              <div className="grid md:grid-cols-2 gap-6">
                <div className="bg-[#1a2234]/50 p-4 rounded-lg border border-[#3b82f6]/20">
                  <div className="flex items-center gap-2 mb-3">
                    <Code className="w-4 h-4 text-[#3b82f6]" />
                    <span className="text-xs text-[#3b82f6]">Generated SQL</span>
                  </div>
                  <pre className="text-xs text-[#b8b8b8] overflow-x-auto">
                    <code>{`SELECT 
  month,
  SUM(revenue) as total
FROM sales
WHERE quarter = 3
GROUP BY month`}</code>
                  </pre>
                </div>
                <div className="bg-[#1a2234]/50 p-4 rounded-lg border border-[#3b82f6]/20">
                  <div className="flex items-center gap-2 mb-3">
                    <BarChart3 className="w-4 h-4 text-[#3b82f6]" />
                    <span className="text-xs text-[#3b82f6]">Insights</span>
                  </div>
                  <ul className="text-xs text-[#b8b8b8] space-y-2">
                    <li className="flex items-start gap-2">
                      <span className="text-[#10b981]">✓</span>
                      <span>Revenue increased 12% in Q3</span>
                    </li>
                    <li className="flex items-start gap-2">
                      <span className="text-[#f97316]">⚠</span>
                      <span>Anomaly detected in July</span>
                    </li>
                  </ul>
                </div>
              </div>
            </Card>
          </div>
        </div>
      </section>

      {/* Features Section */}
      <section className="py-20 container mx-auto px-6">
        <h2 className="text-4xl font-light mb-12 text-center tracking-tight">Core Capabilities</h2>
        <div className="grid md:grid-cols-3 gap-8 max-w-5xl mx-auto">
          <Card className="bg-[#0f1622]/50 border-[#3b82f6]/30 p-6">
            <h3 className="text-xl font-light mb-3 text-[#3b82f6]">Natural Language to SQL</h3>
            <p className="text-[#b8b8b8] leading-relaxed">
              Convert plain English questions into optimized SQL queries. No coding required.
            </p>
          </Card>
          <Card className="bg-[#0f1622]/50 border-[#3b82f6]/30 p-6">
            <h3 className="text-xl font-light mb-3 text-[#3b82f6]">Instant Visualizations</h3>
            <p className="text-[#b8b8b8] leading-relaxed">
              Automatic chart generation and dashboard creation from your data queries.
            </p>
          </Card>
          <Card className="bg-[#0f1622]/50 border-[#3b82f6]/30 p-6">
            <h3 className="text-xl font-light mb-3 text-[#3b82f6]">AI-Powered Insights</h3>
            <p className="text-[#b8b8b8] leading-relaxed">
              Contextual analysis and recommendations based on your business metrics.
            </p>
          </Card>
        </div>
      </section>
      
      {/* ================= COMPONENTS ================= */}

      <QueryMindDeepDive />

      <QueryMindArchitectureDiagram />

      <QueryMindGuardrails />

      {/* Footer */}
      <footer className="py-12 border-t border-[#3b82f6]/20">
        <div className="container mx-auto px-6 text-center text-[#b8b8b8]">
          <p className="text-sm">&copy; 2025 Nabla-X. Intelligence for Complex Systems.</p>
        </div>
      </footer>

      <style jsx>{`
        @keyframes x-query {
          0%, 100% { transform: scale(1) rotate(0deg); }
          25% { transform: scale(1.1) rotate(5deg); }
          50% { transform: scale(1) rotate(0deg); }
          75% { transform: scale(1.1) rotate(-5deg); }
        }

        .animate-x-query {
          animation: x-query 3s ease-in-out infinite;
          transform-origin: center;
        }

        .query-animation-bg {
          background-image: 
            linear-gradient(rgba(59, 130, 246, 0.1) 1px, transparent 1px),
            linear-gradient(90deg, rgba(59, 130, 246, 0.1) 1px, transparent 1px);
          background-size: 40px 40px;
        }

        .typing-animation {
          overflow: hidden;
          border-right: 2px solid #3b82f6;
          white-space: nowrap;
          animation: typing 3s steps(60) infinite, blink 0.75s step-end infinite;
        }

        @keyframes typing {
          0%, 100% { width: 0; }
          50% { width: 100%; }
        }

        @keyframes blink {
          50% { border-color: transparent; }
        }
      `}</style>
    </div>
  )
}
