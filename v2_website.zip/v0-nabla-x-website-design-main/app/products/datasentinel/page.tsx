"use client"

import Link from "next/link"
import { Shield, ArrowRight, AlertTriangle, CheckCircle, TrendingUp } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Card } from "@/components/ui/card"

import DataSentinelHowItWorks from "@/components/datasentinel/HowItWorks"
import DataSentinelHowItThinks from "@/components/datasentinel/HowItThinks"
import DataSentinelArchitecture from "@/components/datasentinel/Architecture"

export default function DataSentinelPage() {
  return (
    <div className="min-h-screen bg-gradient-to-br from-[#0a0a0f] via-[#0f1f0f] to-[#0a0a0f] text-[#e8e8e8]">
      {/* Header */}
      <header className="fixed top-0 w-full z-40 border-b border-[#10b981]/20 bg-[#0a0a0f]/80 backdrop-blur-md">
        <nav className="container mx-auto px-6 py-4 flex items-center justify-between">
          <Link
            href="/"
            className="text-3xl font-light text-[#10b981] tracking-wider hover:opacity-80 transition-opacity"
          >
            ∇<sup className="text-xl animate-x-sentinel inline-block">x</sup>
          </Link>
          <div className="flex items-center gap-8">
            <Link href="/" className="text-sm tracking-wide hover:text-[#10b981] transition-colors">
              Home
            </Link>
            <Link href="/about" className="text-sm tracking-wide hover:text-[#10b981] transition-colors">
              About
            </Link>
            <Link href="/contact" className="text-sm tracking-wide hover:text-[#10b981] transition-colors">
              Contact
            </Link>
          </div>
        </nav>
      </header>

      {/* Hero Section */}
      <section className="pt-32 pb-20 container mx-auto px-6">
        <div className="max-w-4xl mx-auto text-center">
          <div className="mb-8 flex justify-center">
            <div className="p-6 rounded-2xl bg-[#10b981]/10 border border-[#10b981]/30">
              <Shield className="w-16 h-16 text-[#10b981]" />
            </div>
          </div>
          <h1 className="text-6xl md:text-7xl font-light mb-4 tracking-tight text-balance">
            Nabla-X <span className="text-[#10b981]">DataSentinel</span>
          </h1>
          <p className="text-2xl text-[#10b981] mb-6 italic">Your data's first line of defense.</p>
          <p className="text-xl text-[#b8b8b8] mb-12 leading-relaxed max-w-2xl mx-auto text-pretty">
            AI-powered data reliability monitoring that detects anomalies, ensures quality, and protects your data
            before issues cascade.
          </p>
          <div className="flex flex-col items-center gap-4">
            <Link href="/contact">
              <Button className="bg-[#10b981] text-white hover:bg-[#059669] px-8 py-6 text-base">
                Request Demo <ArrowRight className="ml-2 w-5 h-5" />
              </Button>
            </Link>
            <Link
              href="/case-studies/anomaly-protection-finserv"
              className="text-sm text-[#10b981] underline underline-offset-4 hover:opacity-80 transition"
            >
              See DataSentinel in action: Financial Services Case Study →
            </Link>
          </div>
        </div>

        {/* Anomaly Detection Demo */}
        <div className="mt-20 relative">
          <div className="sentinel-pulse absolute inset-0"></div>
          <div className="relative max-w-4xl mx-auto">
            <Card className="bg-[#0f1f0f]/80 border-[#10b981]/30 p-8 backdrop-blur-sm">
              <div className="flex items-center justify-between mb-6">
                <div className="flex items-center gap-3">
                  <div className="w-3 h-3 bg-[#10b981] rounded-full animate-pulse"></div>
                  <span className="text-sm text-[#10b981]">Monitoring Active</span>
                </div>
                <span className="text-xs text-[#b8b8b8]">Last scan: 2 seconds ago</span>
              </div>

              <div className="space-y-4">
                <div className="bg-[#1a2f1a]/50 p-4 rounded-lg border border-[#10b981]/30 flex items-start gap-4">
                  <CheckCircle className="w-5 h-5 text-[#10b981] mt-1 flex-shrink-0" />
                  <div>
                    <div className="font-medium text-[#10b981] mb-1">Data Quality: Excellent</div>
                    <div className="text-sm text-[#b8b8b8]">
                      All schema validations passed. No null anomalies detected.
                    </div>
                  </div>
                </div>

                <div className="bg-[#2f1f1a]/50 p-4 rounded-lg border border-[#f97316]/30 flex items-start gap-4 animate-alert">
                  <AlertTriangle className="w-5 h-5 text-[#f97316] mt-1 flex-shrink-0" />
                  <div className="flex-1">
                    <div className="font-medium text-[#f97316] mb-1">High Priority: Volume Spike Detected</div>
                    <div className="text-sm text-[#b8b8b8] mb-3">
                      Transaction volume 340% above baseline. Potential data duplication issue.
                    </div>
                    <div className="bg-[#0f1f0f]/50 p-3 rounded border border-[#10b981]/20">
                      <div className="text-xs text-[#10b981] mb-2">Suggested Fix</div>
                      <pre className="text-xs text-[#b8b8b8]">
                        <code>SELECT DISTINCT * FROM transactions WHERE timestamp &gt; NOW() - INTERVAL '1 hour'</code>
                      </pre>
                    </div>
                  </div>
                </div>

                <div className="bg-[#1a2f1a]/50 p-4 rounded-lg border border-[#10b981]/30 flex items-start gap-4">
                  <TrendingUp className="w-5 h-5 text-[#10b981] mt-1 flex-shrink-0" />
                  <div>
                    <div className="font-medium text-[#10b981] mb-1">Confidence Score: 94%</div>
                    <div className="text-sm text-[#b8b8b8]">Model accuracy validated against historical patterns.</div>
                  </div>
                </div>
              </div>
            </Card>
          </div>
        </div>
      </section>

      {/* Features Section */}
      <section className="py-20 container mx-auto px-6">
        <h2 className="text-4xl font-light mb-12 text-center tracking-tight">Core Capabilities</h2>
        <div className="grid md:grid-cols-3 gap-8 max-w-5xl mx-auto">
          <Card className="bg-[#0f1f0f]/50 border-[#10b981]/30 p-6">
            <h3 className="text-xl font-light mb-3 text-[#10b981]">Anomaly Detection</h3>
            <p className="text-[#b8b8b8] leading-relaxed">
              Real-time monitoring of data patterns with intelligent anomaly detection and alerting.
            </p>
          </Card>
          <Card className="bg-[#0f1f0f]/50 border-[#10b981]/30 p-6">
            <h3 className="text-xl font-light mb-3 text-[#10b981]">Auto-Remediation</h3>
            <p className="text-[#b8b8b8] leading-relaxed">
              Suggested fixes and automated responses to common data quality issues.
            </p>
          </Card>
          <Card className="bg-[#0f1f0f]/50 border-[#10b981]/30 p-6">
            <h3 className="text-xl font-light mb-3 text-[#10b981]">Trust Scores</h3>
            <p className="text-[#b8b8b8] leading-relaxed">
              Confidence metrics for every dataset, updated continuously as data flows.
            </p>
          </Card>
        </div>
      </section>

      <DataSentinelHowItWorks />
      <DataSentinelHowItThinks />
      <DataSentinelArchitecture />

      {/* Footer */}
      <footer className="py-12 border-t border-[#10b981]/20">
        <div className="container mx-auto px-6 text-center text-[#b8b8b8]">
          <p className="text-sm">&copy; 2025 Nabla-X. Intelligence for Complex Systems.</p>
        </div>
      </footer>

      <style jsx>{`
        @keyframes x-sentinel {
          0%, 100% { transform: scale(1); opacity: 1; }
          50% { transform: scale(1.15); opacity: 0.8; }
        }

        .animate-x-sentinel {
          animation: x-sentinel 2s ease-in-out infinite;
          transform-origin: center;
        }

        .sentinel-pulse {
          background: radial-gradient(circle at center, rgba(16, 185, 129, 0.1) 0%, transparent 70%);
          animation: pulse-wave 3s ease-out infinite;
        }

        @keyframes pulse-wave {
          0% { transform: scale(0.8); opacity: 0; }
          50% { opacity: 0.5; }
          100% { transform: scale(1.5); opacity: 0; }
        }

        @keyframes alert {
          0%, 100% { border-color: rgba(249, 115, 22, 0.3); }
          50% { border-color: rgba(249, 115, 22, 0.6); }
        }

        .animate-alert {
          animation: alert 2s ease-in-out infinite;
        }
      `}</style>
    </div>
  )
}
