"use client"

import Link from "next/link"
import { Search, ArrowRight, GitBranch, TrendingUp, Lightbulb } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Card } from "@/components/ui/card"

import RootSenseHowItWorks from "@/components/rootsense/HowItWorks"
import RootSenseHowItThinks from "@/components/rootsense/HowItThinks"
import RootSenseArchitecture from "@/components/rootsense/Architecture"

export default function RootSensePage() {
  return (
    <div className="min-h-screen bg-gradient-to-br from-[#0a0a0f] via-[#221a0f] to-[#0a0a0f] text-[#e8e8e8]">
      {/* Header */}
      <header className="fixed top-0 w-full z-40 border-b border-[#f97316]/20 bg-[#0a0a0f]/80 backdrop-blur-md">
        <nav className="container mx-auto px-6 py-4 flex items-center justify-between">
          <Link
            href="/"
            className="text-3xl font-light text-[#f97316] tracking-wider hover:opacity-80 transition-opacity"
          >
            ∇<sup className="text-xl animate-x-root inline-block">x</sup>
          </Link>
          <div className="flex items-center gap-8">
            <Link href="/" className="text-sm tracking-wide hover:text-[#f97316] transition-colors">
              Home
            </Link>
            <Link href="/about" className="text-sm tracking-wide hover:text-[#f97316] transition-colors">
              About
            </Link>
            <Link href="/contact" className="text-sm tracking-wide hover:text-[#f97316] transition-colors">
              Contact
            </Link>
          </div>
        </nav>
      </header>

      {/* Hero Section */}
      <section className="pt-32 pb-20 container mx-auto px-6">
        <div className="max-w-4xl mx-auto text-center">
          <div className="mb-8 flex justify-center">
            <div className="p-6 rounded-2xl bg-[#f97316]/10 border border-[#f97316]/30">
              <Search className="w-16 h-16 text-[#f97316]" />
            </div>
          </div>
          <h1 className="text-6xl md:text-7xl font-light mb-4 tracking-tight text-balance">
            Nabla-X <span className="text-[#f97316]">RootSense</span>
          </h1>
          <p className="text-2xl text-[#f97316] mb-6 italic">Know the 'why' behind every outcome.</p>
          <p className="text-xl text-[#b8b8b8] mb-12 leading-relaxed max-w-2xl mx-auto text-pretty">
            AI-powered root-cause intelligence that explains, compares, and solves complex issues through deep
            explainability and similarity analysis.
          </p>
          <div className="flex flex-col items-center gap-4">
            <Link href="/contact">
              <Button className="bg-[#f97316] text-white hover:bg-[#ea580c] px-8 py-6 text-base">
                Request Demo <ArrowRight className="ml-2 w-5 h-5" />
              </Button>
            </Link>
            <Link
              href="/case-studies/explainability-platform-telco"
              className="text-sm text-[#f97316] underline underline-offset-4 hover:opacity-80 transition"
            >
              See RootSense in action: Telecommunications Case Study →
            </Link>
          </div>
        </div>

        {/* Root Cause Demo */}
        <div className="mt-20 relative">
          <div className="root-network absolute inset-0 opacity-10"></div>
          <div className="relative max-w-4xl mx-auto">
            <Card className="bg-[#221a0f]/80 border-[#f97316]/30 p-8 backdrop-blur-sm">
              <div className="mb-6">
                <div className="flex items-center gap-3 mb-4">
                  <Lightbulb className="w-5 h-5 text-[#f97316] animate-pulse" />
                  <span className="text-sm text-[#f97316]">Root Cause Analysis</span>
                </div>
                <div className="text-lg text-[#e8e8e8] mb-2">Issue: Customer Churn Rate +23%</div>
              </div>

              <div className="grid md:grid-cols-2 gap-6">
                <div className="bg-[#1a1410]/50 p-6 rounded-lg border border-[#f97316]/20">
                  <div className="flex items-center gap-2 mb-4">
                    <TrendingUp className="w-4 h-4 text-[#f97316]" />
                    <span className="text-xs text-[#f97316]">Feature Importance</span>
                  </div>
                  <div className="space-y-3">
                    <div>
                      <div className="flex justify-between text-xs mb-1">
                        <span className="text-[#b8b8b8]">Response Time</span>
                        <span className="text-[#f97316]">87%</span>
                      </div>
                      <div className="h-2 bg-[#1a1410] rounded-full overflow-hidden">
                        <div className="h-full bg-[#f97316] w-[87%] feature-bar"></div>
                      </div>
                    </div>
                    <div>
                      <div className="flex justify-between text-xs mb-1">
                        <span className="text-[#b8b8b8]">Support Quality</span>
                        <span className="text-[#f97316]">64%</span>
                      </div>
                      <div className="h-2 bg-[#1a1410] rounded-full overflow-hidden">
                        <div className="h-full bg-[#f97316] w-[64%] feature-bar"></div>
                      </div>
                    </div>
                    <div>
                      <div className="flex justify-between text-xs mb-1">
                        <span className="text-[#b8b8b8]">Pricing</span>
                        <span className="text-[#f97316]">41%</span>
                      </div>
                      <div className="h-2 bg-[#1a1410] rounded-full overflow-hidden">
                        <div className="h-full bg-[#f97316] w-[41%] feature-bar"></div>
                      </div>
                    </div>
                  </div>
                </div>

                <div className="bg-[#1a1410]/50 p-6 rounded-lg border border-[#f97316]/20">
                  <div className="flex items-center gap-2 mb-4">
                    <GitBranch className="w-4 h-4 text-[#f97316]" />
                    <span className="text-xs text-[#f97316]">Similar Past Events</span>
                  </div>
                  <div className="space-y-3 text-xs">
                    <div className="flex items-start gap-2">
                      <div className="w-1 h-1 bg-[#10b981] rounded-full mt-1.5 flex-shrink-0"></div>
                      <div>
                        <div className="text-[#b8b8b8] mb-1">Q2 2024: +19% churn</div>
                        <div className="text-[#10b981]">Resolved: Reduced support wait time by 40%</div>
                      </div>
                    </div>
                    <div className="flex items-start gap-2">
                      <div className="w-1 h-1 bg-[#10b981] rounded-full mt-1.5 flex-shrink-0"></div>
                      <div>
                        <div className="text-[#b8b8b8] mb-1">Q4 2023: +15% churn</div>
                        <div className="text-[#10b981]">Resolved: Improved onboarding flow</div>
                      </div>
                    </div>
                  </div>
                  <Button
                    size="sm"
                    variant="outline"
                    className="mt-4 w-full border-[#f97316] text-[#f97316] hover:bg-[#f97316]/10 bg-transparent text-xs"
                  >
                    View Resolution Details
                  </Button>
                </div>
              </div>

              <div className="mt-6 p-4 bg-[#f97316]/10 rounded-lg border border-[#f97316]/30">
                <div className="text-sm text-[#f97316] font-medium mb-2">Recommended Actions</div>
                <ul className="text-xs text-[#b8b8b8] space-y-1">
                  <li className="flex items-start gap-2">
                    <span className="text-[#f97316]">1.</span>
                    <span>Implement real-time support queue monitoring</span>
                  </li>
                  <li className="flex items-start gap-2">
                    <span className="text-[#f97316]">2.</span>
                    <span>Review Q2 2024 resolution playbook for similar patterns</span>
                  </li>
                  <li className="flex items-start gap-2">
                    <span className="text-[#f97316]">3.</span>
                    <span>Conduct customer satisfaction survey focusing on response time</span>
                  </li>
                </ul>
              </div>
            </Card>
          </div>
        </div>
      </section>

      {/* Features Section */}
      <section className="py-20 container mx-auto px-6">
        <h2 className="text-4xl font-light mb-12 text-center tracking-tight">Core Capabilities</h2>
        <div className="grid md:grid-cols-3 gap-8 max-w-5xl mx-auto">
          <Card className="bg-[#221a0f]/50 border-[#f97316]/30 p-6">
            <h3 className="text-xl font-light mb-3 text-[#f97316]">Deep Explainability</h3>
            <p className="text-[#b8b8b8] leading-relaxed">
              Understand feature importance and causal factors driving every outcome.
            </p>
          </Card>
          <Card className="bg-[#221a0f]/50 border-[#f97316]/30 p-6">
            <h3 className="text-xl font-light mb-3 text-[#f97316]">Similarity Intelligence</h3>
            <p className="text-[#b8b8b8] leading-relaxed">
              Find similar past events and learn from previous resolutions.
            </p>
          </Card>
          <Card className="bg-[#221a0f]/50 border-[#f97316]/30 p-6">
            <h3 className="text-xl font-light mb-3 text-[#f97316]">Actionable Insights</h3>
            <p className="text-[#b8b8b8] leading-relaxed">
              Get specific, prioritized recommendations based on root-cause analysis.
            </p>
          </Card>
        </div>
      </section>

      <RootSenseHowItWorks />
      <RootSenseHowItThinks />
      <RootSenseArchitecture />

      {/* Footer */}
      <footer className="py-12 border-t border-[#f97316]/20">
        <div className="container mx-auto px-6 text-center text-[#b8b8b8]">
          <p className="text-sm">&copy; 2025 Nabla-X. Intelligence for Complex Systems.</p>
        </div>
      </footer>

      <style jsx>{`
        @keyframes x-root {
          0%, 100% { transform: translateY(0) rotate(0deg); }
          25% { transform: translateY(-3px) rotate(10deg); }
          50% { transform: translateY(0) rotate(0deg); }
          75% { transform: translateY(3px) rotate(-10deg); }
        }

        .animate-x-root {
          animation: x-root 4s ease-in-out infinite;
          transform-origin: center;
        }
      `}</style>
    </div>
  )
}
