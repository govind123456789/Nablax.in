"use client"

import Link from "next/link"
import { GraduationCap, ArrowRight, Play, Sparkles } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Card } from "@/components/ui/card"

import EduVerseHowItWorks from "@/components/eduverse/HowItWorks"
import EduVerseHowItThinks from "@/components/eduverse/HowItThinks"
import EduVerseArchitecture from "@/components/eduverse/Architecture"

export default function EduVersePage() {
  return (
    <div className="min-h-screen bg-gradient-to-br from-[#0a0a0f] via-[#1a0f22] to-[#0a0a0f] text-[#e8e8e8]">
      {/* Header */}
      <header className="fixed top-0 w-full z-40 border-b border-[#a855f7]/20 bg-[#0a0a0f]/80 backdrop-blur-md">
        <nav className="container mx-auto px-6 py-4 flex items-center justify-between">
          <Link
            href="/"
            className="text-3xl font-light text-[#a855f7] tracking-wider hover:opacity-80 transition-opacity"
          >
            ∇<sup className="text-xl animate-x-edu inline-block">x</sup>
          </Link>
          <div className="flex items-center gap-8">
            <Link href="/" className="text-sm tracking-wide hover:text-[#a855f7] transition-colors">
              Home
            </Link>
            <Link href="/about" className="text-sm tracking-wide hover:text-[#a855f7] transition-colors">
              About
            </Link>
            <Link href="/contact" className="text-sm tracking-wide hover:text-[#a855f7] transition-colors">
              Contact
            </Link>
          </div>
        </nav>
      </header>

      {/* Hero Section */}
      <section className="pt-32 pb-20 container mx-auto px-6">
        <div className="max-w-4xl mx-auto text-center">
          <div className="mb-8 flex justify-center">
            <div className="p-6 rounded-2xl bg-[#a855f7]/10 border border-[#a855f7]/30">
              <GraduationCap className="w-16 h-16 text-[#a855f7]" />
            </div>
          </div>
          <h1 className="text-6xl md:text-7xl font-light mb-4 tracking-tight text-balance">
            Nabla-X <span className="text-[#a855f7]">EduVerse</span>
          </h1>
          <p className="text-2xl text-[#a855f7] mb-6 italic">Personalized learning, one video at a time.</p>
          <p className="text-xl text-[#b8b8b8] mb-12 leading-relaxed max-w-2xl mx-auto text-pretty">
            AI-generated explainer videos that adapt to every learner's age, pace, and style. Teach anything. Understand
            everything.
          </p>
          <Link href="/contact">
            <Button className="bg-[#a855f7] text-white hover:bg-[#9333ea] px-8 py-6 text-base">
              Request Demo <ArrowRight className="ml-2 w-5 h-5" />
            </Button>
          </Link>
        </div>

        {/* Video Generation Demo */}
        <div className="mt-20 relative">
          <div className="edu-sparkle absolute inset-0"></div>
          <div className="relative max-w-4xl mx-auto">
            <Card className="bg-[#1a0f22]/80 border-[#a855f7]/30 p-8 backdrop-blur-sm">
              <div className="mb-6">
                <div className="flex items-center gap-3 mb-4">
                  <Sparkles className="w-5 h-5 text-[#a855f7] animate-pulse" />
                  <span className="text-sm text-[#a855f7]">AI Video Generator</span>
                </div>
                <div className="bg-[#0f0a17]/50 p-4 rounded-lg border border-[#a855f7]/20 mb-4">
                  <input
                    type="text"
                    className="w-full bg-transparent text-[#e8e8e8] placeholder-[#b8b8b8] outline-none"
                    placeholder="Explain photosynthesis for a 10-year-old..."
                    value="Explain photosynthesis for a 10-year-old"
                    readOnly
                  />
                </div>
                <div className="flex items-center gap-4 mb-6">
                  <div className="flex items-center gap-2">
                    <span className="text-xs text-[#b8b8b8]">Age:</span>
                    <div className="bg-[#a855f7]/20 px-3 py-1 rounded-full text-xs text-[#a855f7]">10 years</div>
                  </div>
                  <div className="flex items-center gap-2">
                    <span className="text-xs text-[#b8b8b8]">Difficulty:</span>
                    <div className="bg-[#a855f7]/20 px-3 py-1 rounded-full text-xs text-[#a855f7]">Beginner</div>
                  </div>
                  <div className="flex items-center gap-2">
                    <span className="text-xs text-[#b8b8b8]">Length:</span>
                    <div className="bg-[#a855f7]/20 px-3 py-1 rounded-full text-xs text-[#a855f7]">3-5 min</div>
                  </div>
                </div>
              </div>

              <div className="grid md:grid-cols-2 gap-6">
                <div className="bg-[#0f0a17]/50 p-6 rounded-lg border border-[#a855f7]/20">
                  <div className="relative aspect-video bg-gradient-to-br from-[#a855f7]/20 to-[#9333ea]/20 rounded-lg mb-4 flex items-center justify-center border border-[#a855f7]/30">
                    <Play className="w-12 h-12 text-[#a855f7] animate-pulse" />
                    <div className="absolute top-2 right-2 bg-[#0f0a17]/80 px-2 py-1 rounded text-xs text-[#a855f7]">
                      3:24
                    </div>
                  </div>
                  <div className="text-xs text-[#b8b8b8]">
                    <div className="mb-2">Generated video with:</div>
                    <ul className="space-y-1 ml-4">
                      <li className="flex items-start gap-2">
                        <span className="text-[#a855f7]">•</span>
                        <span>Simple animations</span>
                      </li>
                      <li className="flex items-start gap-2">
                        <span className="text-[#a855f7]">•</span>
                        <span>Age-appropriate language</span>
                      </li>
                      <li className="flex items-start gap-2">
                        <span className="text-[#a855f7]">•</span>
                        <span>Interactive quiz points</span>
                      </li>
                    </ul>
                  </div>
                </div>

                <div className="bg-[#0f0a17]/50 p-6 rounded-lg border border-[#a855f7]/20">
                  <div className="text-xs text-[#a855f7] mb-3">Video Transcript</div>
                  <div className="text-xs text-[#b8b8b8] leading-relaxed space-y-2 max-h-48 overflow-y-auto">
                    <p>
                      "Hey there! Today we're going to learn about something really cool that plants do. It's called
                      photosynthesis!"
                    </p>
                    <p>
                      "Imagine plants are like tiny chefs in a kitchen. They take three ingredients: sunlight, water,
                      and air..."
                    </p>
                    <p className="text-[#a855f7] italic">[Interactive: Can you name the three ingredients?]</p>
                    <p>
                      "And they mix these together to make their own food! Just like you might mix flour, eggs, and milk
                      to make pancakes..."
                    </p>
                  </div>
                  <Button
                    size="sm"
                    variant="outline"
                    className="mt-4 w-full border-[#a855f7] text-[#a855f7] hover:bg-[#a855f7]/10 bg-transparent text-xs"
                  >
                    View Full Transcript
                  </Button>
                </div>
              </div>

              <div className="mt-6 grid grid-cols-3 gap-4">
                <div className="bg-[#a855f7]/10 p-3 rounded-lg border border-[#a855f7]/20 text-center">
                  <div className="text-2xl font-light text-[#a855f7] mb-1">98%</div>
                  <div className="text-xs text-[#b8b8b8]">Engagement Rate</div>
                </div>
                <div className="bg-[#a855f7]/10 p-3 rounded-lg border border-[#a855f7]/20 text-center">
                  <div className="text-2xl font-light text-[#a855f7] mb-1">4.9/5</div>
                  <div className="text-xs text-[#b8b8b8]">Comprehension Score</div>
                </div>
                <div className="bg-[#a855f7]/10 p-3 rounded-lg border border-[#a855f7]/20 text-center">
                  <div className="text-2xl font-light text-[#a855f7] mb-1">85%</div>
                  <div className="text-xs text-[#b8b8b8]">Quiz Pass Rate</div>
                </div>
              </div>
            </Card>
          </div>
        </div>
      </section>

      {/* Features Section */}
      <section className="py-20 container mx-auto px-6">
        <h2 className="text-4xl font-light mb-12 text-center tracking-tight">Core Capabilities</h2>
        <div className="grid md:grid-cols-3 gap-8 max-w-5xl mx-auto">
          <Card className="bg-[#1a0f22]/50 border-[#a855f7]/30 p-6">
            <h3 className="text-xl font-light mb-3 text-[#a855f7]">Adaptive Content</h3>
            <p className="text-[#b8b8b8] leading-relaxed">
              Videos automatically adjust complexity, pace, and language based on learner profiles.
            </p>
          </Card>
          <Card className="bg-[#1a0f22]/50 border-[#a855f7]/30 p-6">
            <h3 className="text-xl font-light mb-3 text-[#a855f7]">Interactive Learning</h3>
            <p className="text-[#b8b8b8] leading-relaxed">
              Built-in quizzes, checkpoints, and engagement tracking throughout the video.
            </p>
          </Card>
          <Card className="bg-[#1a0f22]/50 border-[#a855f7]/30 p-6">
            <h3 className="text-xl font-light mb-3 text-[#a855f7]">Multi-Format Export</h3>
            <p className="text-[#b8b8b8] leading-relaxed">
              Generate videos, transcripts, study guides, and practice tests from one topic.
            </p>
          </Card>
        </div>
      </section>

      <EduVerseHowItWorks />
      <EduVerseHowItThinks />
      <EduVerseArchitecture />

      {/* Footer */}
      <footer className="py-12 border-t border-[#a855f7]/20">
        <div className="container mx-auto px-6 text-center text-[#b8b8b8]">
          <p className="text-sm">&copy; 2025 Nabla-X. Intelligence for Complex Systems.</p>
        </div>
      </footer>

      <style jsx>{`
        @keyframes x-edu {
          0%, 100% { transform: translateY(0) scale(1); }
          25% { transform: translateY(-2px) scale(1.05); }
          50% { transform: translateY(0) scale(1); }
          75% { transform: translateY(2px) scale(1.05); }
        }

        .animate-x-edu {
          animation: x-edu 3s ease-in-out infinite;
          transform-origin: center;
        }

        .edu-sparkle {
          background-image: radial-gradient(circle, rgba(168, 85, 247, 0.1) 2px, transparent 2px);
          background-size: 50px 50px;
          animation: sparkleMove 20s linear infinite;
        }

        @keyframes sparkleMove {
          0% { background-position: 0 0; }
          100% { background-position: 50px 50px; }
        }
      `}</style>
    </div>
  )
}
