import type { Metadata } from "next"

export const metadata: Metadata = {
  title: "About Nabla-X | AI Intelligence for Complex Systems",
  description:
    "Founded by Govind Tiwari, Nabla-X builds applied intelligence systems for healthcare, finance, and research. Learn about our mission, philosophy, and approach to responsible AI.",
  keywords: [
    "AI intelligence",
    "complex systems",
    "healthcare AI",
    "financial AI",
    "explainable AI",
    "production AI",
    "AI governance",
  ],
  openGraph: {
    title: "About Nabla-X | AI Intelligence for Complex Systems",
    description:
      "Founded by Govind Tiwari, Nabla-X builds applied intelligence systems for healthcare, finance, and research.",
    url: "https://nabla-x.ai/about",
    siteName: "Nabla-X",
    type: "website",
    images: [
      {
        url: "/og-image.png",
        width: 1200,
        height: 630,
        alt: "Nabla-X - Intelligence for Complex Systems",
      },
    ],
  },
  twitter: {
    card: "summary_large_image",
    title: "About Nabla-X | AI Intelligence for Complex Systems",
    description:
      "Founded by Govind Tiwari, Nabla-X builds applied intelligence systems for healthcare, finance, and research.",
    images: ["/og-image.png"],
  },
}
