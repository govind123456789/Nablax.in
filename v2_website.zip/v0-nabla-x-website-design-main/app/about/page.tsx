"use client"

import Link from "next/link"
import { Sparkles, Target, Shield, Zap } from "lucide-react"
import { Card } from "@/components/ui/card"

export default function AboutPage() {
  return (
    <div className="min-h-screen bg-gradient-to-br from-[#0a0520] via-[#1a1040] to-[#0f0830] text-[#e8e8ff]">
      {/* Header */}
      <header className="fixed top-0 w-full z-40 border-b border-[#8b7eff]/20 bg-[#0a0520]/80 backdrop-blur-md">
        <nav className="container mx-auto px-6 py-4 flex items-center justify-between">
          <Link href="/" className="flex items-center gap-2 md:gap-3 hover:opacity-80 transition-opacity group">
            <span className="text-2xl md:text-3xl font-light text-[#c4b5fd] tracking-wider">
              ∇<sup className="text-base md:text-xl animate-x-float inline-block">x</sup>
            </span>
            <span className="text-lg md:text-2xl font-light tracking-wide">
              <span className="text-[#e8e8ff]">Nabla-</span>
              <span className="bg-gradient-to-r from-[#c4b5fd] via-[#e4d5ff] to-[#c4b5fd] bg-clip-text text-transparent font-medium">
                X
              </span>
            </span>
          </Link>
          <div className="hidden md:flex items-center gap-8">
            <Link href="/about" className="text-sm tracking-wide text-[#c4b5fd]">
              About
            </Link>
            <Link href="/services" className="text-sm tracking-wide hover:text-[#c4b5fd] transition-colors">
              Services
            </Link>
            <Link href="/contact" className="text-sm tracking-wide hover:text-[#c4b5fd] transition-colors">
              Contact
            </Link>
          </div>
        </nav>
      </header>

      {/* Stars Background */}
      <div className="stars-container">
        {[...Array(50)].map((_, i) => (
          <div
            key={i}
            className="star"
            style={{
              left: `${Math.random() * 100}%`,
              top: `${Math.random() * 100}%`,
              animationDelay: `${Math.random() * 3}s`,
              animationDuration: `${2 + Math.random() * 2}s`,
            }}
          />
        ))}
      </div>

      {/* Hero Section */}
      <section className="pt-32 pb-20 container mx-auto px-6 relative">
        <div className="max-w-4xl mx-auto text-center">
          <div className="mb-8 flex justify-center">
            <div className="text-7xl font-light text-[#c4b5fd] cosmic-glow">
              ∇<sup className="text-4xl animate-x-orbit">x</sup>
            </div>
          </div>
          <h1 className="text-5xl md:text-6xl font-light mb-6 tracking-tight text-balance">
            About <span className="text-[#c4b5fd]">Nabla-X</span>
          </h1>
          <p className="text-xl text-[#d4c5ff] mb-8 leading-relaxed text-pretty">
            ∇x is a mathematical expression. ∇ denotes the direction of greatest change. x represents the unknown.
          </p>
        </div>
      </section>

      {/* Philosophy Section */}
      <section className="py-20 container mx-auto px-6">
        <div className="max-w-5xl mx-auto">
          <h2 className="text-4xl font-light mb-12 text-center text-[#c4b5fd]">Our Philosophy</h2>

          <div className="grid md:grid-cols-2 gap-8 mb-16">
            <Card className="bg-[#1a1040]/50 border-[#8b7eff]/30 p-8 backdrop-blur-sm">
              <div className="mb-4 p-3 rounded-full bg-[#c4b5fd]/10 w-fit">
                <Target className="w-6 h-6 text-[#c4b5fd]" />
              </div>
              <h3 className="text-2xl font-light mb-4 text-[#c4b5fd]">Why We Exist</h3>
              <p className="text-[#d4c5ff] leading-relaxed">
                Modern organizations operate inside systems that are highly interconnected, non-linear, and constrained
                by regulation. Most AI fails because it treats these systems as static. We model reality as it actually
                behaves.
              </p>
            </Card>

            <Card className="bg-[#1a1040]/50 border-[#8b7eff]/30 p-8 backdrop-blur-sm">
              <div className="mb-4 p-3 rounded-full bg-[#c4b5fd]/10 w-fit">
                <Shield className="w-6 h-6 text-[#c4b5fd]" />
              </div>
              <h3 className="text-2xl font-light mb-4 text-[#c4b5fd]">What We Believe</h3>
              <ul className="space-y-3 text-[#d4c5ff]">
                <li className="flex items-start">
                  <Sparkles className="w-4 h-4 mr-2 mt-1 text-[#c4b5fd]" />
                  <span>Rigor over hype — models must be explainable and defensible</span>
                </li>
                <li className="flex items-start">
                  <Sparkles className="w-4 h-4 mr-2 mt-1 text-[#c4b5fd]" />
                  <span>Structure before scale — coherence before automation</span>
                </li>
                <li className="flex items-start">
                  <Sparkles className="w-4 h-4 mr-2 mt-1 text-[#c4b5fd]" />
                  <span>Decision support, not replacement — augment human judgment</span>
                </li>
              </ul>
            </Card>
          </div>

          {/* What We Do */}
          <div className="text-center mb-12">
            <h2 className="text-4xl font-light mb-6 text-[#c4b5fd]">What We Do</h2>
            <p className="text-xl text-[#d4c5ff] max-w-3xl mx-auto leading-relaxed">
              We design and deploy applied intelligence for industries where accuracy and trust matter: Healthcare,
              Finance, Energy, and Research.
            </p>
          </div>

          {/* Approach */}
          <Card className="bg-[#1a1040]/50 border-[#8b7eff]/30 p-10 backdrop-blur-sm">
            <h3 className="text-3xl font-light mb-8 text-center text-[#c4b5fd]">How We Work</h3>
            <div className="grid md:grid-cols-2 gap-6">
              <div className="flex items-start space-x-3">
                <Zap className="w-5 h-5 text-[#c4b5fd] mt-1 flex-shrink-0" />
                <div>
                  <p className="font-light text-lg mb-2 text-[#c4b5fd]">Problem First</p>
                  <p className="text-[#d4c5ff] text-sm">We begin with the problem, not the technology</p>
                </div>
              </div>
              <div className="flex items-start space-x-3">
                <Zap className="w-5 h-5 text-[#c4b5fd] mt-1 flex-shrink-0" />
                <div>
                  <p className="font-light text-lg mb-2 text-[#c4b5fd]">Feasibility Assessment</p>
                  <p className="text-[#d4c5ff] text-sm">We assess viability before promising outcomes</p>
                </div>
              </div>
              <div className="flex items-start space-x-3">
                <Zap className="w-5 h-5 text-[#c4b5fd] mt-1 flex-shrink-0" />
                <div>
                  <p className="font-light text-lg mb-2 text-[#c4b5fd]">Expert Validation</p>
                  <p className="text-[#d4c5ff] text-sm">We validate models with domain experts</p>
                </div>
              </div>
              <div className="flex items-start space-x-3">
                <Zap className="w-5 h-5 text-[#c4b5fd] mt-1 flex-shrink-0" />
                <div>
                  <p className="font-light text-lg mb-2 text-[#c4b5fd]">Sustainable Systems</p>
                  <p className="text-[#d4c5ff] text-sm">We deploy systems that can be monitored and improved</p>
                </div>
              </div>
            </div>
          </Card>

          {/* What We Are Not */}
          <div className="mt-16 text-center">
            <h2 className="text-3xl font-light mb-6 text-[#c4b5fd]">What We Are Not</h2>
            <div className="max-w-2xl mx-auto space-y-3 text-[#d4c5ff]">
              <p>We are not a generic AI services firm</p>
              <p>We do not sell "magic" or black-box models</p>
              <p>We do not optimize vanity metrics</p>
              <p className="text-lg font-light text-[#c4b5fd] mt-6">
                If a problem cannot be solved responsibly, we say so.
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="py-12 border-t border-[#8b7eff]/20">
        <div className="container mx-auto px-6 text-center text-[#d4c5ff]">
          <p className="text-sm">&copy; 2025 Nabla-X. Let's build something meaningful.</p>
          <div className="mt-4">
            <Link
              href="/careers"
              className="text-xs text-[#8b7eff] hover:text-[#c4b5fd] transition-colors opacity-70 hover:opacity-100"
            >
              Careers
            </Link>
            
          </div>
        </div>
      </footer>

      <style jsx>{`
        .stars-container {
          position: fixed;
          top: 0;
          left: 0;
          width: 100%;
          height: 100%;
          pointer-events: none;
          z-index: 0;
        }

        .star {
          position: absolute;
          width: 2px;
          height: 2px;
          background: #c4b5fd;
          border-radius: 50%;
          animation: twinkle 3s ease-in-out infinite;
          box-shadow: 0 0 4px #c4b5fd;
        }

        @keyframes twinkle {
          0%, 100% { opacity: 0.3; transform: scale(1); }
          50% { opacity: 1; transform: scale(1.5); }
        }

        @keyframes x-orbit {
          0% { transform: translateY(0) rotate(0deg); }
          50% { transform: translateY(-10px) rotate(180deg); }
          100% { transform: translateY(0) rotate(360deg); }
        }

        @keyframes x-float {
          0%, 100% { transform: translateY(0); }
          50% { transform: translateY(-5px); }
        }

        .animate-x-orbit {
          animation: x-orbit 4s ease-in-out infinite;
          display: inline-block;
        }

        .animate-x-float {
          animation: x-float 3s ease-in-out infinite;
          display: inline-block;
        }

        .cosmic-glow {
          text-shadow: 0 0 20px rgba(196, 181, 253, 0.5),
                       0 0 40px rgba(139, 126, 255, 0.3);
        }
      `}</style>
    </div>
  )
}
