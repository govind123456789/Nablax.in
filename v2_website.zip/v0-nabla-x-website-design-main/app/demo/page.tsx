"use client"

import { useState, Suspense } from "react"
import Link from "next/link"
import {
  Play,
  Check,
  AlertCircle,
  Database,
  Sparkles,
  ArrowRight,
  Shield,
  Search,
  Activity,
  Brain,
  BookOpen,
  AlertTriangle,
  Clock,
  Users,
  BarChart3,
} from "lucide-react"
import { Card } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { trackEvent, AnalyticsEvents } from "@/lib/analytics"
import {
  LineChart,
  Line,
  BarChart,
  Bar,
  AreaChart,
  Area,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  Legend,
  ResponsiveContainer,
} from "recharts"

type DemoResult = {
  sql?: string
  explanation?: string
  insights?: string[]
  warnings?: string[]
  anomalies?: Array<{ type: string; severity: string; description: string; timestamp: string }>
  rootCause?: {
    prediction: string
    confidence: number
    factors: Array<{ feature: string; impact: number; direction: string }>
    similarCases: Array<{ id: string; similarity: number; outcome: string }>
  }
  eduContent?: {
    topic: string
    summary: string
    keyPoints: string[]
    resources: Array<{ title: string; type: string; url?: string }>
  }
  graphRecommendations?: Array<{ type: string; description: string; axes: { x: string; y: string }; groupBy?: string }>
  chartData?: Array<{ month: string; Sales: number; Marketing: number; Engineering: number }>
}

function DemoPageContent() {
  const [activeTab, setActiveTab] = useState("querymind")
  const [query, setQuery] = useState("")
  const [isProcessing, setIsProcessing] = useState(false)
  const [result, setResult] = useState<DemoResult | null>(null)

  const queryMindScenarios = [
    "Show me revenue trends by department",
    "Which customers have the highest churn risk?",
    "Analyze anomalies in transaction data",
  ]

  const dataSentinelScenarios = [
    "Monitor payment processing pipeline",
    "Check data quality for customer records",
    "Detect unusual patterns in API logs",
  ]

  const rootSenseScenarios = [
    "Why was this loan application rejected?",
    "Explain this fraud detection decision",
    "What caused this customer churn prediction?",
  ]

  const eduverseScenarios = [
    "Explain neural networks for beginners",
    "How does gradient descent work?",
    "What is transfer learning?",
  ]

  const handleQueryMindDemo = async () => {
    if (!query.trim()) return
    setIsProcessing(true)
    setResult(null)

    trackEvent(AnalyticsEvents.DEMO_QUERY_SUBMITTED, {
      product: "QueryMind",
      query: query.substring(0, 100),
    })

    await new Promise((resolve) => setTimeout(resolve, 2000))

    const sampleChartData = [
      { month: "Jan", Sales: 45000, Marketing: 32000, Engineering: 58000 },
      { month: "Feb", Sales: 52000, Marketing: 38000, Engineering: 61000 },
      { month: "Mar", Sales: 48000, Marketing: 35000, Engineering: 64000 },
      { month: "Apr", Sales: 61000, Marketing: 42000, Engineering: 67000 },
      { month: "May", Sales: 55000, Marketing: 45000, Engineering: 70000 },
      { month: "Jun", Sales: 67000, Marketing: 48000, Engineering: 73000 },
      { month: "Jul", Sales: 72000, Marketing: 52000, Engineering: 76000 },
      { month: "Aug", Sales: 68000, Marketing: 50000, Engineering: 78000 },
      { month: "Sep", Sales: 75000, Marketing: 54000, Engineering: 81000 },
      { month: "Oct", Sales: 80000, Marketing: 58000, Engineering: 84000 },
      { month: "Nov", Sales: 77000, Marketing: 56000, Engineering: 82000 },
      { month: "Dec", Sales: 85000, Marketing: 62000, Engineering: 88000 },
    ]

    setResult({
      sql: `SELECT department, 
  DATE_TRUNC('month', transaction_date) as month,
  SUM(revenue) as total_revenue,
  COUNT(DISTINCT customer_id) as unique_customers
FROM transactions
WHERE transaction_date >= CURRENT_DATE - INTERVAL '12 months'
  AND revenue > 0
GROUP BY department, month
ORDER BY month DESC, total_revenue DESC
LIMIT 100;`,
      explanation:
        "This query aggregates revenue data by department over the last 12 months, grouping by month to show trends. The query includes a filter for positive revenue and limits results to prevent performance issues.",
      insights: [
        "Query scope limited to 100 rows for safe execution",
        "Time range constrained to prevent full table scan",
        "Aggregation includes proper grouping for trend analysis",
        "Filter excludes invalid revenue values (negative amounts)",
        "Peak revenue detected in Q3 - consider seasonal analysis",
        "Department variance suggests segmented strategy opportunities",
      ],
      graphRecommendations: [
        {
          type: "Line Chart",
          description: "Revenue trends over time by department",
          axes: { x: "Month", y: "Total Revenue" },
          groupBy: "Department",
        },
        {
          type: "Bar Chart",
          description: "Department comparison for latest month",
          axes: { x: "Department", y: "Total Revenue" },
        },
        {
          type: "Stacked Area",
          description: "Cumulative revenue contribution by department",
          axes: { x: "Month", y: "Cumulative Revenue" },
          groupBy: "Department",
        },
      ],
      chartData: sampleChartData,
      warnings: ["Data freshness: Last updated 2 hours ago", "Timezone: UTC (may need adjustment for local analysis)"],
    })

    setIsProcessing(false)
  }

  const handleDataSentinelDemo = async () => {
    if (!query.trim()) return
    setIsProcessing(true)
    setResult(null)

    trackEvent(AnalyticsEvents.DEMO_QUERY_SUBMITTED, {
      product: "DataSentinel",
      query: query.substring(0, 100),
    })

    await new Promise((resolve) => setTimeout(resolve, 2000))

    setResult({
      anomalies: [
        {
          type: "Data Quality",
          severity: "high",
          description: "Spike in NULL values for email field (18% vs baseline 2%)",
          timestamp: "2 minutes ago",
        },
        {
          type: "Volume Anomaly",
          severity: "medium",
          description: "Transaction volume 43% below 7-day average",
          timestamp: "15 minutes ago",
        },
        {
          type: "Schema Drift",
          severity: "low",
          description: "New optional field 'customer_tier' detected in 12% of records",
          timestamp: "1 hour ago",
        },
        {
          type: "Latency Alert",
          severity: "medium",
          description: "API response time increased from 120ms to 890ms",
          timestamp: "5 minutes ago",
        },
      ],
      insights: [
        "Real-time monitoring detected 4 anomalies in the last hour",
        "Data quality issue requires immediate attention",
        "Volume anomaly may indicate upstream system issues",
        "Schema changes suggest ongoing deployment",
      ],
      warnings: [
        "High severity alerts trigger automated notifications",
        "Historical baseline calculated from 30-day rolling window",
      ],
    })

    setIsProcessing(false)
  }

  const handleRootSenseDemo = async () => {
    if (!query.trim()) return
    setIsProcessing(true)
    setResult(null)

    trackEvent(AnalyticsEvents.DEMO_QUERY_SUBMITTED, {
      product: "RootSense",
      query: query.substring(0, 100),
    })

    await new Promise((resolve) => setTimeout(resolve, 2500))

    setResult({
      rootCause: {
        prediction: "Loan Application Rejected",
        confidence: 87.3,
        factors: [
          { feature: "Debt-to-Income Ratio", impact: 42, direction: "negative" },
          { feature: "Credit Score", impact: 28, direction: "negative" },
          { feature: "Employment History", impact: 15, direction: "negative" },
          { feature: "Loan Amount", impact: 10, direction: "negative" },
          { feature: "Existing Accounts", impact: 5, direction: "positive" },
        ],
        similarCases: [
          { id: "LC-28491", similarity: 94, outcome: "Rejected - High DTI" },
          { id: "LC-19203", similarity: 89, outcome: "Rejected - Credit Score" },
          { id: "LC-34567", similarity: 85, outcome: "Approved with conditions" },
        ],
      },
      explanation:
        "The application was rejected primarily due to a debt-to-income ratio of 58% (threshold: 43%) combined with a below-average credit score of 612. Employment history shows 3 job changes in 18 months, contributing to risk assessment.",
      insights: [
        "Primary factor: DTI ratio exceeds acceptable threshold by 35%",
        "Credit score 88 points below preferred minimum of 700",
        "Similar cases show 94% rejection rate with these characteristics",
        "Nearest approved case had DTI of 39% and credit score of 720",
      ],
      warnings: [
        "Explanation based on training data from 2022-2024",
        "Individual circumstances may justify manual review",
      ],
    })

    setIsProcessing(false)
  }

  const handleEduverseDemo = async () => {
    if (!query.trim()) return
    setIsProcessing(true)
    setResult(null)

    trackEvent(AnalyticsEvents.DEMO_QUERY_SUBMITTED, {
      product: "Eduverse",
      query: query.substring(0, 100),
    })

    await new Promise((resolve) => setTimeout(resolve, 2200))

    const topics = {
      neural: {
        topic: "Neural Networks",
        summary:
          "Neural networks are computational models inspired by the human brain, consisting of interconnected nodes (neurons) organized in layers that learn to recognize patterns through training.",
        keyPoints: [
          "Architecture: Input layer receives data, hidden layers process it, output layer produces results",
          "Learning: Networks adjust connection weights through backpropagation to minimize error",
          "Activation Functions: Non-linear functions (ReLU, sigmoid) enable networks to learn complex patterns",
          "Applications: Image recognition, natural language processing, game playing, and more",
        ],
        resources: [
          {
            title: "Neural Networks and Deep Learning (Nielsen)",
            type: "Free Book",
            url: "http://neuralnetworksanddeeplearning.com/",
          },
          {
            title: "3Blue1Brown - Neural Network Series",
            type: "Video Course",
            url: "https://www.youtube.com/playlist?list=PLZHQObOWTQDNU6R1_67000Dx_ZCJB-3pi",
          },
          { title: "TensorFlow Playground", type: "Interactive Demo", url: "https://playground.tensorflow.org/" },
          {
            title: "MIT 6.S191: Intro to Deep Learning",
            type: "Video Lecture",
            url: "https://www.youtube.com/watch?v=QDX-1M5Nj7s",
          },
        ],
      },
      gradient: {
        topic: "Gradient Descent",
        summary:
          "Gradient descent is an optimization algorithm that iteratively adjusts model parameters to minimize the loss function by moving in the direction of steepest decrease.",
        keyPoints: [
          "Process: Calculate gradient of loss function, update parameters opposite to gradient direction",
          "Learning Rate: Controls step size - too large causes overshooting, too small slows convergence",
          "Variants: Batch (full dataset), Stochastic (single sample), Mini-batch (subset)",
          "Momentum: Adds velocity to help escape local minima and speed up training",
        ],
        resources: [
          {
            title: "Stanford CS229 - Optimization",
            type: "Lecture Notes",
            url: "https://cs229.stanford.edu/notes2022fall/main_notes.pdf",
          },
          {
            title: "Distill.pub - Why Momentum Works",
            type: "Visual Guide",
            url: "https://distill.pub/2017/momentum/",
          },
          {
            title: "PyTorch Optimizers Tutorial",
            type: "Code Tutorial",
            url: "https://pytorch.org/tutorials/beginner/basics/optimization_tutorial.html",
          },
          {
            title: "StatQuest: Gradient Descent",
            type: "Video Tutorial",
            url: "https://www.youtube.com/watch?v=sDv4f4s2SB8",
          },
        ],
      },
      transfer: {
        topic: "Transfer Learning",
        summary:
          "Transfer learning leverages knowledge from pre-trained models on large datasets to solve related tasks with less data and training time, especially effective in computer vision and NLP.",
        keyPoints: [
          "Concept: Reuse learned features from one task to bootstrap learning on a new task",
          "Approaches: Feature extraction (freeze layers) or fine-tuning (adjust all layers)",
          "Benefits: Requires less data, faster training, often better performance than training from scratch",
          "Common Models: ResNet, BERT, GPT for various domains and applications",
        ],
        resources: [
          {
            title: "Transfer Learning Guide - Stanford",
            type: "Tutorial",
            url: "https://cs231n.github.io/transfer-learning/",
          },
          {
            title: "Hugging Face Transformers",
            type: "Library & Models",
            url: "https://huggingface.co/docs/transformers/",
          },
          { title: "Fast.ai Course - Practical Deep Learning", type: "Video Course", url: "https://course.fast.ai/" },
          {
            title: "Google: Transfer Learning in TensorFlow",
            type: "Video Tutorial",
            url: "https://www.youtube.com/watch?v=5T-iXNNiwIs",
          },
        ],
      },
    }

    const lowerQuery = query.toLowerCase()
    let selectedTopic = topics.neural

    if (lowerQuery.includes("gradient") || lowerQuery.includes("descent") || lowerQuery.includes("optim")) {
      selectedTopic = topics.gradient
    } else if (lowerQuery.includes("transfer") || lowerQuery.includes("pretrain") || lowerQuery.includes("fine-tun")) {
      selectedTopic = topics.transfer
    }

    setResult({
      eduContent: selectedTopic,
      explanation: `Eduverse has curated comprehensive learning materials on ${selectedTopic.topic} from trusted sources, including interactive demos, video courses, and academic resources. Start with the video content for intuitive understanding, then explore the interactive demos for hands-on practice.`,
      insights: [
        "Video content provides visual intuition for complex concepts",
        "Interactive demos allow experimentation with parameters in real-time",
        "Academic resources offer rigorous mathematical foundations",
        "Recommended learning path: Video → Interactive → Deep Dive",
      ],
    })

    setIsProcessing(false)
  }

  const handleRunDemo = () => {
    switch (activeTab) {
      case "querymind":
        return handleQueryMindDemo()
      case "datasentinel":
        return handleDataSentinelDemo()
      case "rootsense":
        return handleRootSenseDemo()
      case "eduverse":
        return handleEduverseDemo()
    }
  }

  const getCurrentScenarios = () => {
    switch (activeTab) {
      case "querymind":
        return queryMindScenarios
      case "datasentinel":
        return dataSentinelScenarios
      case "rootsense":
        return rootSenseScenarios
      case "eduverse":
        return eduverseScenarios
      default:
        return []
    }
  }

  const getCurrentPlaceholder = () => {
    switch (activeTab) {
      case "querymind":
        return "e.g., Show me revenue trends by department"
      case "datasentinel":
        return "e.g., Monitor payment processing pipeline"
      case "rootsense":
        return "e.g., Why was this loan application rejected?"
      case "eduverse":
        return "e.g., Explain neural networks for beginners"
      default:
        return "Ask a question..."
    }
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-[#0a0a0a] via-[#1a1a1a] to-[#0f0f0f] text-[#e8e8e8]">
      {/* Header */}
      <header className="fixed top-0 w-full z-40 border-b border-[#d4af37]/20 bg-[#0a0a0a]/80 backdrop-blur-md">
        <nav className="container mx-auto px-6 py-4 flex items-center justify-between">
          <Link href="/" className="flex items-center gap-2 md:gap-3 hover:opacity-80 transition-opacity group">
            <span className="text-2xl md:text-3xl font-light text-[#d4af37] tracking-wider">
              ∇<sup className="text-base md:text-xl animate-x-rotate inline-block">x</sup>
            </span>
            <span className="text-lg md:text-2xl font-light tracking-wide">
              <span className="text-[#e8e8e8]">Nabla-</span>
              <span className="bg-gradient-to-r from-[#d4af37] via-[#f4cf47] to-[#d4af37] bg-clip-text text-transparent font-medium">
                X
              </span>
            </span>
          </Link>
          <div className="hidden md:flex items-center gap-8">
            <Link href="/about" className="text-sm tracking-wide hover:text-[#d4af37] transition-colors">
              About
            </Link>
            <Link href="/services" className="text-sm tracking-wide hover:text-[#d4af37] transition-colors">
              Services
            </Link>
            <Link href="/contact" className="text-sm tracking-wide hover:text-[#d4af37] transition-colors">
              Contact
            </Link>
          </div>
        </nav>
      </header>

      {/* Main Content */}
      <section className="pt-32 pb-20 container mx-auto px-6">
        <div className="max-w-6xl mx-auto">
          {/* Hero */}
          <div className="text-center mb-12">
            <div className="inline-flex items-center gap-2 px-4 py-2 rounded-full bg-[#d4af37]/10 border border-[#d4af37]/20 mb-6">
              <Sparkles className="w-4 h-4 text-[#d4af37]" />
              <span className="text-sm text-[#d4af37] font-medium">Interactive Demos</span>
            </div>
            <h1 className="text-5xl md:text-6xl font-light mb-6 tracking-tight text-balance">
              Experience <span className="text-[#d4af37]">Nabla-X Products</span>
            </h1>
            <p className="text-xl text-[#b8b8b8] leading-relaxed max-w-3xl mx-auto text-pretty">
              Try our intelligent systems in action. Each demo showcases real capabilities with simulated data.
            </p>
          </div>

          <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full">
            <TabsList className="grid w-full grid-cols-4 bg-[#1a1a1a]/50 border border-[#d4af37]/20 p-1 rounded-lg mb-8">
              <TabsTrigger
                value="querymind"
                className="data-[state=active]:bg-[#d4af37] data-[state=active]:text-[#0a0a0a] text-[#b8b8b8]"
              >
                <Database className="w-4 h-4 mr-2" />
                QueryMind
              </TabsTrigger>
              <TabsTrigger
                value="datasentinel"
                className="data-[state=active]:bg-[#d4af37] data-[state=active]:text-[#0a0a0a] text-[#b8b8b8]"
              >
                <Shield className="w-4 h-4 mr-2" />
                DataSentinel
              </TabsTrigger>
              <TabsTrigger
                value="rootsense"
                className="data-[state=active]:bg-[#d4af37] data-[state=active]:text-[#0a0a0a] text-[#b8b8b8]"
              >
                <Search className="w-4 h-4 mr-2" />
                RootSense
              </TabsTrigger>
              <TabsTrigger
                value="eduverse"
                className="data-[state=active]:bg-[#d4af37] data-[state=active]:text-[#0a0a0a] text-[#b8b8b8]"
              >
                <BookOpen className="w-4 h-4 mr-2" />
                Eduverse
              </TabsTrigger>
            </TabsList>

            {/* Demo Interface */}
            <TabsContent value={activeTab} className="mt-0">
              <Card className="bg-[#1a1a1a]/50 border-[#d4af37]/30 p-8 mb-8">
                <div className="space-y-4 mb-6">
                  <label className="block text-sm text-[#b8b8b8]">
                    {activeTab === "querymind" && "Ask a question about your data"}
                    {activeTab === "datasentinel" && "Specify what system or data to monitor"}
                    {activeTab === "rootsense" && "Ask why a model made a specific prediction"}
                    {activeTab === "eduverse" && "What would you like to learn about?"}
                  </label>
                  <div className="flex gap-3">
                    <Input
                      value={query}
                      onChange={(e) => setQuery(e.target.value)}
                      onKeyDown={(e) => e.key === "Enter" && handleRunDemo()}
                      className="flex-1 bg-[#0a0a0a]/50 border-[#d4af37]/30 text-[#e8e8e8] focus:border-[#d4af37] text-lg"
                      placeholder={getCurrentPlaceholder()}
                    />
                    <Button
                      onClick={handleRunDemo}
                      disabled={!query.trim() || isProcessing}
                      className="bg-[#d4af37] text-[#0a0a0a] hover:bg-[#c4a037] px-6"
                    >
                      {isProcessing ? (
                        <div className="w-5 h-5 border-2 border-[#0a0a0a] border-t-transparent rounded-full animate-spin" />
                      ) : (
                        <>
                          <Play className="w-4 h-4 mr-2" />
                          Run
                        </>
                      )}
                    </Button>
                  </div>

                  {/* Quick scenarios */}
                  <div className="flex flex-wrap gap-2">
                    <span className="text-xs text-[#8a8a8a]">Try:</span>
                    {getCurrentScenarios().map((scenario) => (
                      <button
                        key={scenario}
                        onClick={() => {
                          setQuery(scenario)
                          trackEvent(AnalyticsEvents.DEMO_SCENARIO_SELECTED, { scenario, product: activeTab })
                        }}
                        className="text-xs px-3 py-1 rounded-full bg-[#d4af37]/10 text-[#d4af37] hover:bg-[#d4af37]/20 transition-colors border border-[#d4af37]/20"
                      >
                        {scenario}
                      </button>
                    ))}
                  </div>
                </div>

                {result && (
                  <div className="space-y-6 animate-in fade-in duration-500">
                    {/* QueryMind Results */}
                    {result.sql && (
                      <>
                        <div>
                          <div className="flex items-center gap-2 mb-3">
                            <Database className="w-4 h-4 text-[#d4af37]" />
                            <h3 className="text-sm font-medium text-[#d4af37]">Generated SQL</h3>
                          </div>
                          <pre className="bg-[#0a0a0a] border border-[#d4af37]/20 rounded-lg p-4 overflow-x-auto text-sm text-[#e8e8e8] font-mono">
                            {result.sql}
                          </pre>
                        </div>

                        {result.graphRecommendations && (
                          <div>
                            <div className="flex items-center gap-2 mb-4">
                              <BarChart3 className="w-4 h-4 text-[#d4af37]" />
                              <h3 className="text-sm font-medium text-[#d4af37]">Recommended Visualizations</h3>
                            </div>
                            <div className="space-y-3">
                              {result.graphRecommendations.map((graph, i) => (
                                <div key={i} className="bg-[#0a0a0a] border border-[#d4af37]/20 rounded-lg p-4">
                                  <div className="flex items-start justify-between mb-2">
                                    <span className="text-sm font-medium text-[#d4af37]">{graph.type}</span>
                                    {graph.groupBy && (
                                      <span className="text-xs text-[#8a8a8a] bg-[#d4af37]/10 px-2 py-1 rounded">
                                        Group: {graph.groupBy}
                                      </span>
                                    )}
                                  </div>
                                  <p className="text-sm text-[#b8b8b8] mb-2">{graph.description}</p>
                                  <div className="flex gap-4 text-xs text-[#8a8a8a]">
                                    <span>X-axis: {graph.axes.x}</span>
                                    <span>Y-axis: {graph.axes.y}</span>
                                  </div>
                                </div>
                              ))}
                            </div>
                          </div>
                        )}

                        {result.chartData && (
                          <div className="space-y-6">
                            <div className="flex items-center gap-2 mb-4">
                              <BarChart3 className="w-4 h-4 text-[#d4af37]" />
                              <h3 className="text-sm font-medium text-[#d4af37]">Data Visualizations</h3>
                            </div>

                            {/* Line Chart */}
                            <div className="bg-[#0a0a0a] border border-[#d4af37]/20 rounded-lg p-6">
                              <h4 className="text-sm font-medium text-[#d4af37] mb-4">Revenue Trends by Department</h4>
                              <ResponsiveContainer width="100%" height={300}>
                                <LineChart data={result.chartData}>
                                  <CartesianGrid strokeDasharray="3 3" stroke="#333" />
                                  <XAxis dataKey="month" stroke="#8a8a8a" />
                                  <YAxis stroke="#8a8a8a" />
                                  <Tooltip
                                    contentStyle={{ backgroundColor: "#1a1a1a", border: "1px solid #d4af37" }}
                                    labelStyle={{ color: "#e8e8e8" }}
                                  />
                                  <Legend />
                                  <Line type="monotone" dataKey="Sales" stroke="#d4af37" strokeWidth={2} />
                                  <Line type="monotone" dataKey="Marketing" stroke="#60a5fa" strokeWidth={2} />
                                  <Line type="monotone" dataKey="Engineering" stroke="#34d399" strokeWidth={2} />
                                </LineChart>
                              </ResponsiveContainer>
                            </div>

                            {/* Bar Chart */}
                            <div className="bg-[#0a0a0a] border border-[#d4af37]/20 rounded-lg p-6">
                              <h4 className="text-sm font-medium text-[#d4af37] mb-4">
                                Department Comparison (Latest Month)
                              </h4>
                              <ResponsiveContainer width="100%" height={300}>
                                <BarChart data={result.chartData.slice(-1)}>
                                  <CartesianGrid strokeDasharray="3 3" stroke="#333" />
                                  <XAxis dataKey="month" stroke="#8a8a8a" />
                                  <YAxis stroke="#8a8a8a" />
                                  <Tooltip
                                    contentStyle={{ backgroundColor: "#1a1a1a", border: "1px solid #d4af37" }}
                                    labelStyle={{ color: "#e8e8e8" }}
                                  />
                                  <Legend />
                                  <Bar dataKey="Sales" fill="#d4af37" />
                                  <Bar dataKey="Marketing" fill="#60a5fa" />
                                  <Bar dataKey="Engineering" fill="#34d399" />
                                </BarChart>
                              </ResponsiveContainer>
                            </div>

                            {/* Stacked Area Chart */}
                            <div className="bg-[#0a0a0a] border border-[#d4af37]/20 rounded-lg p-6">
                              <h4 className="text-sm font-medium text-[#d4af37] mb-4">
                                Cumulative Revenue Contribution
                              </h4>
                              <ResponsiveContainer width="100%" height={300}>
                                <AreaChart data={result.chartData}>
                                  <CartesianGrid strokeDasharray="3 3" stroke="#333" />
                                  <XAxis dataKey="month" stroke="#8a8a8a" />
                                  <YAxis stroke="#8a8a8a" />
                                  <Tooltip
                                    contentStyle={{ backgroundColor: "#1a1a1a", border: "1px solid #d4af37" }}
                                    labelStyle={{ color: "#e8e8e8" }}
                                  />
                                  <Legend />
                                  <Area
                                    type="monotone"
                                    dataKey="Sales"
                                    stackId="1"
                                    stroke="#d4af37"
                                    fill="#d4af37"
                                    fillOpacity={0.6}
                                  />
                                  <Area
                                    type="monotone"
                                    dataKey="Marketing"
                                    stackId="1"
                                    stroke="#60a5fa"
                                    fill="#60a5fa"
                                    fillOpacity={0.6}
                                  />
                                  <Area
                                    type="monotone"
                                    dataKey="Engineering"
                                    stackId="1"
                                    stroke="#34d399"
                                    fill="#34d399"
                                    fillOpacity={0.6}
                                  />
                                </AreaChart>
                              </ResponsiveContainer>
                            </div>
                          </div>
                        )}
                      </>
                    )}

                    {/* DataSentinel Results */}
                    {result.anomalies && (
                      <div>
                        <div className="flex items-center gap-2 mb-4">
                          <Activity className="w-4 h-4 text-[#d4af37]" />
                          <h3 className="text-sm font-medium text-[#d4af37]">Detected Anomalies</h3>
                        </div>
                        <div className="space-y-3">
                          {result.anomalies.map((anomaly, i) => (
                            <div
                              key={i}
                              className={`bg-[#0a0a0a] border rounded-lg p-4 ${
                                anomaly.severity === "high"
                                  ? "border-red-500/30"
                                  : anomaly.severity === "medium"
                                    ? "border-amber-500/30"
                                    : "border-blue-500/30"
                              }`}
                            >
                              <div className="flex items-start justify-between mb-2">
                                <div className="flex items-center gap-2">
                                  <AlertTriangle
                                    className={`w-4 h-4 ${
                                      anomaly.severity === "high"
                                        ? "text-red-500"
                                        : anomaly.severity === "medium"
                                          ? "text-amber-500"
                                          : "text-blue-500"
                                    }`}
                                  />
                                  <span className="text-sm font-medium text-[#e8e8e8]">{anomaly.type}</span>
                                </div>
                                <span className="text-xs text-[#8a8a8a] flex items-center gap-1">
                                  <Clock className="w-3 h-3" />
                                  {anomaly.timestamp}
                                </span>
                              </div>
                              <p className="text-sm text-[#b8b8b8]">{anomaly.description}</p>
                            </div>
                          ))}
                        </div>
                      </div>
                    )}

                    {/* RootSense Results */}
                    {result.rootCause && (
                      <>
                        <div>
                          <div className="flex items-center gap-2 mb-4">
                            <Brain className="w-4 h-4 text-[#d4af37]" />
                            <h3 className="text-sm font-medium text-[#d4af37]">Prediction Analysis</h3>
                          </div>
                          <div className="bg-[#0a0a0a] border border-[#d4af37]/20 rounded-lg p-4">
                            <div className="flex items-center justify-between mb-4">
                              <span className="text-lg font-light text-[#e8e8e8]">{result.rootCause.prediction}</span>
                              <span className="text-sm text-[#d4af37]">{result.rootCause.confidence}% confidence</span>
                            </div>
                            <div className="space-y-2">
                              {result.rootCause.factors.map((factor, i) => (
                                <div key={i} className="flex items-center gap-3">
                                  <span className="text-sm text-[#b8b8b8] flex-1">{factor.feature}</span>
                                  <div className="flex items-center gap-2 flex-1">
                                    <div className="flex-1 bg-[#1a1a1a] rounded-full h-2 overflow-hidden">
                                      <div
                                        className={`h-full ${factor.direction === "negative" ? "bg-red-500" : "bg-green-500"}`}
                                        style={{ width: `${factor.impact}%` }}
                                      />
                                    </div>
                                    <span className="text-xs text-[#8a8a8a] w-12 text-right">{factor.impact}%</span>
                                  </div>
                                </div>
                              ))}
                            </div>
                          </div>
                        </div>

                        <div>
                          <div className="flex items-center gap-2 mb-3">
                            <Users className="w-4 h-4 text-[#d4af37]" />
                            <h3 className="text-sm font-medium text-[#d4af37]">Similar Cases</h3>
                          </div>
                          <div className="space-y-2">
                            {result.rootCause.similarCases.map((case_item, i) => (
                              <div
                                key={i}
                                className="bg-[#0a0a0a] border border-[#d4af37]/20 rounded-lg p-3 flex items-center justify-between"
                              >
                                <span className="text-sm text-[#b8b8b8]">Case {case_item.id}</span>
                                <div className="flex items-center gap-4">
                                  <span className="text-xs text-[#8a8a8a]">{case_item.similarity}% similar</span>
                                  <span className="text-xs text-[#d4af37]">{case_item.outcome}</span>
                                </div>
                              </div>
                            ))}
                          </div>
                        </div>
                      </>
                    )}

                    {/* Eduverse Results */}
                    {result.eduContent && (
                      <>
                        <div>
                          <div className="flex items-center gap-2 mb-4">
                            <BookOpen className="w-4 h-4 text-[#d4af37]" />
                            <h3 className="text-lg font-light text-[#d4af37]">{result.eduContent.topic}</h3>
                          </div>
                          <p className="text-[#b8b8b8] leading-relaxed mb-6">{result.eduContent.summary}</p>

                          <h4 className="text-sm font-medium text-[#d4af37] mb-3">Key Concepts</h4>
                          <ul className="space-y-3 mb-6">
                            {result.eduContent.keyPoints.map((point, i) => (
                              <li key={i} className="flex items-start gap-2">
                                <Check className="w-4 h-4 text-[#d4af37] flex-shrink-0 mt-0.5" />
                                <span className="text-sm text-[#b8b8b8]">{point}</span>
                              </li>
                            ))}
                          </ul>

                          <h4 className="text-sm font-medium text-[#d4af37] mb-3">Recommended Resources</h4>
                          <div className="grid gap-3">
                            {result.eduContent.resources.map((resource, i) => (
                              <a
                                key={i}
                                href={resource.url}
                                target="_blank"
                                rel="noopener noreferrer"
                                className="bg-[#0a0a0a] border border-[#d4af37]/20 hover:border-[#d4af37] rounded-lg p-3 flex items-center justify-between transition-all group"
                              >
                                <div className="flex items-center gap-3">
                                  {resource.type.includes("Video") && <Play className="w-4 h-4 text-[#d4af37]" />}
                                  <span className="text-sm text-[#e8e8e8] group-hover:text-[#d4af37] transition-colors">
                                    {resource.title}
                                  </span>
                                </div>
                                <span className="text-xs text-[#d4af37] bg-[#d4af37]/10 px-2 py-1 rounded">
                                  {resource.type}
                                </span>
                              </a>
                            ))}
                          </div>
                        </div>
                      </>
                    )}

                    {/* Common: Explanation */}
                    {result.explanation && (
                      <div>
                        <div className="flex items-center gap-2 mb-3">
                          <Sparkles className="w-4 h-4 text-[#d4af37]" />
                          <h3 className="text-sm font-medium text-[#d4af37]">
                            {result.eduContent ? "About This Content" : "Explanation"}
                          </h3>
                        </div>
                        <p className="text-[#b8b8b8] leading-relaxed">{result.explanation}</p>
                      </div>
                    )}

                    {/* Common: Insights */}
                    {result.insights && result.insights.length > 0 && (
                      <div>
                        <div className="flex items-center gap-2 mb-3">
                          <Check className="w-4 h-4 text-green-500" />
                          <h3 className="text-sm font-medium text-green-500">
                            {activeTab === "datasentinel"
                              ? "Analysis Summary"
                              : activeTab === "eduverse"
                                ? "Learning Guide"
                                : "Safety Guardrails"}
                          </h3>
                        </div>
                        <ul className="space-y-2">
                          {result.insights.map((insight, i) => (
                            <li key={i} className="flex items-start gap-2 text-sm text-[#b8b8b8]">
                              <Check className="w-4 h-4 text-green-500 flex-shrink-0 mt-0.5" />
                              <span>{insight}</span>
                            </li>
                          ))}
                        </ul>
                      </div>
                    )}

                    {/* Common: Warnings */}
                    {result.warnings && result.warnings.length > 0 && (
                      <div>
                        <div className="flex items-center gap-2 mb-3">
                          <AlertCircle className="w-4 h-4 text-amber-500" />
                          <h3 className="text-sm font-medium text-amber-500">Considerations</h3>
                        </div>
                        <ul className="space-y-2">
                          {result.warnings.map((warning, i) => (
                            <li key={i} className="flex items-start gap-2 text-sm text-[#b8b8b8]">
                              <AlertCircle className="w-4 h-4 text-amber-500 flex-shrink-0 mt-0.5" />
                              <span>{warning}</span>
                            </li>
                          ))}
                        </ul>
                      </div>
                    )}
                  </div>
                )}
              </Card>
            </TabsContent>
          </Tabs>

          {/* CTA Section */}
          <div className="grid md:grid-cols-2 gap-6">
            <Card className="bg-[#1a1a1a]/50 border-[#d4af37]/30 p-8 hover:border-[#d4af37] transition-all">
              <h3 className="text-2xl font-light mb-3 text-[#d4af37]">Ready for More?</h3>
              <p className="text-[#b8b8b8] mb-6 leading-relaxed">
                These are simplified demos. Full products include enterprise features like schema understanding,
                real-time validation, custom governance rules, and seamless integrations.
              </p>
              <Link
                href="/contact"
                onClick={() => trackEvent(AnalyticsEvents.DEMO_REQUEST_FULL, { source: "demo_page" })}
              >
                <Button className="bg-[#d4af37] text-[#0a0a0a] hover:bg-[#c4a037] w-full">
                  Request Full Demo
                  <ArrowRight className="w-4 h-4 ml-2" />
                </Button>
              </Link>
            </Card>

            <Card className="bg-[#1a1a1a]/50 border-[#d4af37]/30 p-8 hover:border-[#d4af37] transition-all">
              <h3 className="text-2xl font-light mb-3 text-[#d4af37]">Explore Our Services</h3>
              <p className="text-[#b8b8b8] mb-6 leading-relaxed">
                See how these products work together in the complete Nabla-X Intelligence Suite for regulated
                industries.
              </p>
              <Link href="/services">
                <Button
                  variant="outline"
                  className="border-[#d4af37] text-[#d4af37] hover:bg-[#d4af37]/10 bg-transparent w-full"
                >
                  View All Services
                  <ArrowRight className="w-4 h-4 ml-2" />
                </Button>
              </Link>
            </Card>
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="py-12 border-t border-[#d4af37]/20">
        <div className="container mx-auto px-6 text-center text-[#b8b8b8]">
          <p className="text-sm">&copy; 2025 Nabla-X. Intelligence for complex systems.</p>
        </div>
      </footer>

      <style jsx>{`
        @keyframes x-rotate {
          0%, 100% { transform: rotate(0deg); }
          25% { transform: rotate(90deg); }
          50% { transform: rotate(180deg); }
          75% { transform: rotate(270deg); }
        }

        .animate-x-rotate {
          animation: x-rotate 8s linear infinite;
          display: inline-block;
          transform-origin: center;
        }
      `}</style>
    </div>
  )
}

export default function DemoPage() {
  return (
    <Suspense fallback={null}>
      <DemoPageContent />
    </Suspense>
  )
}
