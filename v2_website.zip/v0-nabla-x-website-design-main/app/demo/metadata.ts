import type { Metadata } from "next"

export const metadata: Metadata = {
  title: "Try QueryMind Demo | Interactive AI Analytics Demo | Nabla-X",
  description:
    "Experience QueryMind in action. Ask questions in plain English and see how it generates safe, explainable SQL with built-in guardrails for enterprise data analytics.",
  keywords: [
    "QueryMind demo",
    "AI analytics demo",
    "text to SQL",
    "AI data analytics",
    "interactive demo",
    "safe SQL generation",
  ],
  openGraph: {
    title: "Try QueryMind Demo | Interactive AI Analytics Demo | Nabla-X",
    description:
      "Experience QueryMind in action. Ask questions in plain English and see how it generates safe, explainable SQL with built-in guardrails.",
    url: "https://nabla-x.ai/demo",
    siteName: "Nabla-X",
    type: "website",
    images: [
      {
        url: "/og-image-demo.png",
        width: 1200,
        height: 630,
        alt: "Try QueryMind Interactive Demo",
      },
    ],
  },
  twitter: {
    card: "summary_large_image",
    title: "Try QueryMind Demo | Interactive AI Analytics Demo | Nabla-X",
    description:
      "Experience QueryMind in action. Ask questions in plain English and see how it generates safe, explainable SQL.",
    images: ["/og-image-demo.png"],
  },
}
