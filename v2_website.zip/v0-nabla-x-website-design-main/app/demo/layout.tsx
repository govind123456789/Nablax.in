import type React from "react"
import { metadata } from "./metadata"

export { metadata }

export default function DemoLayout({ children }: { children: React.ReactNode }) {
  return <>{children}</>
}
