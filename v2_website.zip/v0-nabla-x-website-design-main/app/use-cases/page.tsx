export default function UseCasesPage() {
  return (
    <main className="min-h-screen bg-black text-white">
      {/* Hero */}
      <section className="px-6 py-24 text-center max-w-5xl mx-auto">
        <h1 className="text-4xl md:text-5xl font-semibold tracking-tight">
          Use Cases
        </h1>
        <p className="mt-6 text-lg text-neutral-400">
          Practical applications of Nabla-X across regulated and complex
          environments.
        </p>
      </section>

      {/* Use Case Cards */}
      <section className="px-6 pb-24 max-w-6xl mx-auto grid md:grid-cols-3 gap-8">
        {/* Finance */}
        <div className="border border-neutral-800 rounded-xl p-6">
          <h3 className="text-xl font-semibold mb-2">
            Finance — Credit Risk Monitoring
          </h3>
          <p className="text-neutral-400 text-sm mb-4">
            A lending institution struggled with delayed detection of portfolio
            risk.
          </p>
          <p className="text-neutral-300 text-sm">
            Nabla-X deployed anomaly detection, explainable risk drivers, and
            continuous monitoring to surface early warning signals.
          </p>
          <p className="mt-4 text-neutral-400 text-sm">
            Outcome: Faster risk visibility and audit-ready insights.
          </p>
        </div>

        {/* Healthcare */}
        <div className="border border-neutral-800 rounded-xl p-6">
          <h3 className="text-xl font-semibold mb-2">
            Healthcare — Readmission Risk Prediction
          </h3>
          <p className="text-neutral-400 text-sm mb-4">
            A hospital needed better visibility into preventable readmissions.
          </p>
          <p className="text-neutral-300 text-sm">
            We built predictive models with transparent drivers, integrated into
            clinical workflows for proactive intervention.
          </p>
          <p className="mt-4 text-neutral-400 text-sm">
            Outcome: Improved patient outcomes and reduced operational strain.
          </p>
        </div>

        {/* Data Quality */}
        <div className="border border-neutral-800 rounded-xl p-6">
          <h3 className="text-xl font-semibold mb-2">
            Enterprise Data — Data Trust & Quality
          </h3>
          <p className="text-neutral-400 text-sm mb-4">
            An analytics team faced frequent data breaks and silent failures.
          </p>
          <p className="text-neutral-300 text-sm">
            Nabla-X deployed DataSentinel to monitor pipelines, detect anomalies,
            and trace root causes before business impact.
          </p>
          <p className="mt-4 text-neutral-400 text-sm">
            Outcome: Reliable data, fewer incidents, higher stakeholder trust.
          </p>
        </div>
      </section>
    </main>
  );
}
